import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  ClinicContent,
  MediaItem,
  Booking,
  BookingSettings,
  ActivityLog,
  AdminUser
} from '../types';
import * as api from '../services/api';

interface ClinicContextType {
  // Published Content for Public Site
  content: ClinicContent | null;
  isLoadingContent: boolean;
  refreshContent: () => Promise<void>;

  // Draft Content for Live Editor
  draft: ClinicContent | null;
  isLoadingDraft: boolean;
  isSavingDraft: boolean;
  hasUnsavedDraft: boolean;
  updateDraft: (updates: Partial<ClinicContent>) => void;
  saveDraft: () => Promise<void>;
  publishDraft: () => Promise<void>;
  revertDraft: () => Promise<void>;

  // Media
  mediaList: MediaItem[];
  isLoadingMedia: boolean;
  refreshMedia: () => Promise<void>;

  // Bookings
  bookings: Booking[];
  isLoadingBookings: boolean;
  refreshBookings: (filter?: string, search?: string) => Promise<void>;

  // Settings
  settings: BookingSettings | null;
  refreshSettings: () => Promise<void>;

  // Activity
  activityLogs: ActivityLog[];
  refreshActivityLogs: () => Promise<void>;

  // Auth
  adminUser: AdminUser | null;
  isAdminAuthenticated: boolean;
  isCheckingAuth: boolean;
  login: (u: string, p: string) => Promise<void>;
  logout: () => Promise<void>;
  changeCredentials: (currentPassword: string, newUsername?: string, newPassword?: string) => Promise<void>;

  // Toast
  toast: { message: string; type: 'success' | 'error' | 'info'; details?: string } | null;
  showToast: (message: string, type?: 'success' | 'error' | 'info', details?: string) => void;
  clearToast: () => void;
}

const ClinicContext = createContext<ClinicContextType | undefined>(undefined);

export function ClinicProvider({ children }: { children: ReactNode }) {
  const [content, setContent] = useState<ClinicContent | null>(null);
  const [isLoadingContent, setIsLoadingContent] = useState(true);

  const [draft, setDraft] = useState<ClinicContent | null>(null);
  const [isLoadingDraft, setIsLoadingDraft] = useState(false);
  const [isSavingDraft, setIsSavingDraft] = useState(false);
  const [hasUnsavedDraft, setHasUnsavedDraft] = useState(false);

  const [mediaList, setMediaList] = useState<MediaItem[]>([]);
  const [isLoadingMedia, setIsLoadingMedia] = useState(false);

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [isLoadingBookings, setIsLoadingBookings] = useState(false);

  const [settings, setSettings] = useState<BookingSettings | null>(null);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);

  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);

  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info'; details?: string } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info', details?: string) => {
    setToast({ message, type, details });
    setTimeout(() => {
      setToast(prev => (prev?.message === message ? null : prev));
    }, 5000);
  };

  const clearToast = () => setToast(null);

  // Initial Content Load
  const refreshContent = async () => {
    try {
      setIsLoadingContent(true);
      const data = await api.getPublishedContent();
      setContent(data);
    } catch (err: any) {
      console.error('Failed to load published content:', err);
    } finally {
      setIsLoadingContent(false);
    }
  };

  // Initial Media Load
  const refreshMedia = async () => {
    try {
      setIsLoadingMedia(true);
      const items = await api.getMediaList();
      setMediaList(items);
    } catch (err) {
      console.error('Failed to load media:', err);
    } finally {
      setIsLoadingMedia(false);
    }
  };

  // Settings Load
  const refreshSettings = async () => {
    try {
      const data = await api.getBookingSettings();
      setSettings(data);
    } catch (err) {
      console.error('Failed to load booking settings:', err);
    }
  };

  // Bookings Load (if admin)
  const refreshBookings = async (filter?: string, search?: string) => {
    if (!isAdminAuthenticated) return;
    try {
      setIsLoadingBookings(true);
      const list = await api.getBookingsList(filter, search);
      setBookings(list);
    } catch (err) {
      console.error('Failed to load bookings:', err);
    } finally {
      setIsLoadingBookings(false);
    }
  };

  // Activity Logs
  const refreshActivityLogs = async () => {
    if (!isAdminAuthenticated) return;
    try {
      const logs = await api.getActivityLogs();
      setActivityLogs(logs);
    } catch (err) {
      console.error('Failed to load activity logs:', err);
    }
  };

  // Auth Verification
  useEffect(() => {
    async function checkAuth() {
      const token = api.getStoredToken();
      if (!token) {
        setIsCheckingAuth(false);
        setIsAdminAuthenticated(false);
        setAdminUser(null);
        return;
      }
      try {
        const res = await api.adminGetMe();
        if (res.authenticated && res.user) {
          setAdminUser(res.user);
          setIsAdminAuthenticated(true);
        } else {
          api.clearStoredToken();
          setIsAdminAuthenticated(false);
          setAdminUser(null);
        }
      } catch {
        api.clearStoredToken();
        setIsAdminAuthenticated(false);
        setAdminUser(null);
      } finally {
        setIsCheckingAuth(false);
      }
    }

    checkAuth();
    refreshContent();
    refreshMedia();
    refreshSettings();
  }, []);

  // When admin logs in, load draft and bookings
  useEffect(() => {
    if (isAdminAuthenticated) {
      (async () => {
        try {
          setIsLoadingDraft(true);
          const d = await api.getDraftContent();
          setDraft(d);
        } catch (err) {
          console.error('Failed to load draft:', err);
        } finally {
          setIsLoadingDraft(false);
        }
        refreshBookings();
        refreshActivityLogs();
      })();
    }
  }, [isAdminAuthenticated]);

  // Auth actions
  const login = async (u: string, p: string) => {
    const res = await api.adminLogin(u, p);
    setAdminUser(res.user);
    setIsAdminAuthenticated(true);
    showToast(`Welcome Dr. Chouhan! Admin mode active.`, 'success');
  };

  const logout = async () => {
    await api.adminLogout();
    setAdminUser(null);
    setIsAdminAuthenticated(false);
    setDraft(null);
    showToast('Logged out of admin panel.', 'info');
  };

  const changeCredentials = async (currentPassword: string, newUsername?: string, newPassword?: string) => {
    const res = await api.adminChangeCredentials(currentPassword, newUsername, newPassword);
    if (newUsername) {
      setAdminUser(prev => prev ? { ...prev, username: newUsername } : null);
    }
    showToast(res.message, 'success');
  };

  // Draft editing
  const updateDraft = (updates: Partial<ClinicContent>) => {
    setDraft(prev => prev ? { ...prev, ...updates } : null);
    setHasUnsavedDraft(true);
  };

  const saveDraft = async () => {
    if (!draft) return;
    try {
      setIsSavingDraft(true);
      await api.saveDraftContent(draft);
      setHasUnsavedDraft(false);
      showToast('Draft changes saved successfully.', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to save draft', 'error');
    } finally {
      setIsSavingDraft(false);
    }
  };

  const publishDraft = async () => {
    if (!draft) return;
    try {
      setIsSavingDraft(true);
      // Save any pending edits first
      if (hasUnsavedDraft) {
        await api.saveDraftContent(draft);
      }
      const res = await api.publishContent();
      setContent(res.published);
      setDraft(res.published);
      setHasUnsavedDraft(false);
      showToast('Live website updated successfully! Changes are visible to patients.', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to publish changes', 'error');
    } finally {
      setIsSavingDraft(false);
    }
  };

  const revertDraft = async () => {
    try {
      const res = await api.revertDraftContent();
      setDraft(res.draft);
      setHasUnsavedDraft(false);
      showToast('Draft reverted to currently published live version.', 'info');
    } catch (err: any) {
      showToast(err.message || 'Failed to revert draft', 'error');
    }
  };

  return (
    <ClinicContext.Provider
      value={{
        content,
        isLoadingContent,
        refreshContent,
        draft,
        isLoadingDraft,
        isSavingDraft,
        hasUnsavedDraft,
        updateDraft,
        saveDraft,
        publishDraft,
        revertDraft,
        mediaList,
        isLoadingMedia,
        refreshMedia,
        bookings,
        isLoadingBookings,
        refreshBookings,
        settings,
        refreshSettings,
        activityLogs,
        refreshActivityLogs,
        adminUser,
        isAdminAuthenticated,
        isCheckingAuth,
        login,
        logout,
        changeCredentials,
        toast,
        showToast,
        clearToast
      }}
    >
      {children}
    </ClinicContext.Provider>
  );
}

export function useClinic() {
  const context = useContext(ClinicContext);
  if (!context) {
    throw new Error('useClinic must be used within ClinicProvider');
  }
  return context;
}
