import React, { useState, useEffect } from 'react';
import { ClinicProvider, useClinic } from './context/ClinicContext';
import { PublicWebsite } from './components/public/PublicWebsite';
import { AdminLogin } from './components/admin/AdminLogin';
import { AdminPanel } from './components/admin/AdminPanel';

function MainApp() {
  const { isAdminAuthenticated, isCheckingAuth, toast, clearToast } = useClinic();
  const [route, setRoute] = useState<'public' | 'admin'>('public');

  // Sync hash routing
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash.startsWith('#/admin')) {
        setRoute('admin');
      } else {
        setRoute('public');
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigateToAdmin = () => {
    window.location.hash = '#/admin';
  };

  const navigateToWebsite = () => {
    window.location.hash = '#/';
  };

  if (isCheckingAuth) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-3 border-sky-800 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-semibold text-slate-500">Checking clinic credentials...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Toast Notification Container */}
      {toast && (
        <div className="fixed top-5 right-5 z-50 max-w-sm w-full transition-all animate-in fade-in duration-200">
          <div
            className={`p-4 rounded-2xl shadow-lg border text-xs font-medium flex items-start justify-between gap-3 ${
              toast.type === 'success'
                ? 'bg-emerald-900 text-white border-emerald-800'
                : toast.type === 'error'
                ? 'bg-rose-900 text-white border-rose-800'
                : 'bg-slate-900 text-white border-slate-800'
            }`}
          >
            <div className="flex-1 space-y-1">
              <span className="leading-snug block">{toast.message}</span>
              {toast.details && (
                <div className="text-[10px] text-white/80 font-mono break-all pt-1 border-t border-white/15">
                  <span className="font-semibold text-white">Details: </span>
                  {toast.details}
                </div>
              )}
            </div>
            <button
              onClick={clearToast}
              className="text-white/60 hover:text-white p-0.5 rounded"
              aria-label="Close notification"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Main View Router */}
      {route === 'admin' ? (
        isAdminAuthenticated ? (
          <AdminPanel onBackToWebsite={navigateToWebsite} />
        ) : (
          <AdminLogin onBackToWebsite={navigateToWebsite} onSuccess={() => setRoute('admin')} />
        )
      ) : (
        <PublicWebsite onOpenAdmin={navigateToAdmin} />
      )}
    </div>
  );
}

export default function App() {
  return (
    <ClinicProvider>
      <MainApp />
    </ClinicProvider>
  );
}
