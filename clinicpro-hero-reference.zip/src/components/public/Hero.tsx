import React from 'react';
import { Calendar, Phone, MessageCircle, ShieldCheck, Award, CheckCircle2, Stethoscope, Droplet, Monitor, HeartPulse, ArrowRight } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';

interface HeroProps {
  onBookClick: () => void;
}

export function Hero({ onBookClick }: HeroProps) {
  const { content } = useClinic();

  const heroHeading = content?.heroHeading || 'Your Health in Experienced Hands';
  const heroSubtitle = content?.heroSubtitle || 'Dedicated, timely and evidence-based care for a healthier tomorrow.';
  const heroBadge = content?.heroBadge || '16+ Years of Clinical Excellence';
  const heroImageUrl = content?.heroImageUrl || content?.doctorPhotoUrl || 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1400&q=90';
  const doctorName = content?.doctorName || 'Dr. R. K. Chouhan';
  const doctorQualifications = content?.doctorQualifications || 'MBBS, MD (General Medicine)';
  const phone = content?.phone || '+91 98260 12345';
  const whatsapp = content?.whatsapp || '+91 98260 12345';
  const bgType = content?.heroBgType || 'none';
  const bgUrl = content?.heroBgUrl || '';
  const useVideo = bgType === 'video' && !!bgUrl;
  const visualUrl = (bgType === 'image' && bgUrl) ? bgUrl : heroImageUrl;
  const phoneHref = phone.replace(/[^\d+]/g, '');
  const whatsappNumber = whatsapp.replace(/\D/g, '');
  const fee = content?.consultationFeeText || '₹600';

  const services = [
    { icon: Stethoscope, title: 'Comprehensive', subtitle: 'Medical Consultations' },
    { icon: Droplet, title: 'Chronic Disease', subtitle: 'Management' },
    { icon: Monitor, title: 'Diabetes Control', subtitle: '& Monitoring' },
    { icon: HeartPulse, title: 'Preventive', subtitle: 'Cardiology Care' },
  ];

  return (
    <section id="hero" className="clinic-hero relative isolate overflow-hidden bg-white">
      {/* Use the supplied clinic/doctor photo as a clear, full-bleed visual. The soft white gradient protects text legibility. */}
      <div className="clinic-hero-visual" aria-hidden="true">
        {useVideo ? (
          <video
            key={bgUrl}
            src={bgUrl}
            poster={content?.heroBgPosterUrl || undefined}
            autoPlay muted loop playsInline preload="metadata"
            className="clinic-hero-media"
          />
        ) : (
          <img src={visualUrl} alt="" className="clinic-hero-media" fetchPriority="high" />
        )}
        <div className="clinic-hero-wash" />
      </div>

      <div className="clinic-hero-inner relative z-10 mx-auto w-full max-w-7xl px-5 sm:px-7 lg:px-8">
        <div className="clinic-hero-copy">
          {heroBadge && (
            <div className="clinic-hero-badge">
              <Award size={18} strokeWidth={2.2} />
              <span>{heroBadge}</span>
            </div>
          )}

          <h1 className="clinic-hero-title">
            {heroHeading}
          </h1>
          <div className="clinic-hero-underline" />

          <p className="clinic-hero-subtitle">{heroSubtitle}</p>

          <div className="clinic-hero-services">
            {services.map(({ icon: Icon, title, subtitle }) => (
              <div className="clinic-hero-service" key={title}>
                <span className="clinic-hero-service-icon"><Icon size={25} strokeWidth={2.1} /></span>
                <span className="clinic-hero-service-text">
                  <strong>{title}</strong>
                  <span>{subtitle}</span>
                </span>
              </div>
            ))}
          </div>

          <div className="clinic-hero-actions">
            <button type="button" onClick={onBookClick} className="clinic-hero-book">
              <Calendar size={23} />
              <span>Book Priority Appointment</span>
              <ArrowRight size={23} className="clinic-hero-arrow" />
            </button>
            <div className="clinic-hero-contact-actions">
              <a href={`tel:${phoneHref}`} className="clinic-hero-call">
                <Phone size={22} />
                <span>Call {phone}</span>
              </a>
              <a
                href={`https://wa.me/${whatsappNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                className="clinic-hero-whatsapp"
              >
                <MessageCircle size={22} />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>

          <div className="clinic-hero-fee">
            <span className="clinic-hero-fee-icon"><ShieldCheck size={30} /></span>
            <span className="clinic-hero-fee-copy">
              <span>Consultation Fee: <strong>{fee}</strong></span>
              <small>(Follow-up valid for 7 days)</small>
            </span>
            <span className="clinic-hero-fee-note">Your Health<br />Our Priority</span>
          </div>

          <div className="clinic-hero-doctor-caption">
            <strong>{doctorName}</strong>
            <span>{doctorQualifications}</span>
          </div>
        </div>
      </div>
    </section>
  );
}
