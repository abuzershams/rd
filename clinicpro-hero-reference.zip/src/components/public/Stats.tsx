import React from 'react';
import { useClinic } from '../../context/ClinicContext';
import { ClinicStat } from '../../types';

export function Stats() {
  const { content } = useClinic();

  let stats: ClinicStat[] = [
    { label: 'Years Experience', value: '16+', suffix: 'Years of Practice' },
    { label: 'Patients Treated', value: '25,000+', suffix: 'Happy Recoveries' },
    { label: 'Google Rating', value: '4.9', suffix: '★ Star Reviews' },
    { label: 'Clinical Accuracy', value: '99%', suffix: 'Diagnostic Satisfaction' }
  ];

  if (content?.statsJson) {
    try {
      stats = JSON.parse(content.statsJson);
    } catch {
      // fallback
    }
  }

  return (
    <section className="bg-sky-950 text-white py-10 border-y border-sky-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {stats.map((stat, i) => (
            <div key={i} className="space-y-1">
              <div className="text-3xl sm:text-4xl font-extrabold tracking-tight text-sky-400">
                {stat.value}
              </div>
              <div className="text-xs sm:text-sm font-semibold text-slate-200">
                {stat.label}
              </div>
              {stat.suffix && (
                <div className="text-[11px] text-slate-400 font-medium">
                  {stat.suffix}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
