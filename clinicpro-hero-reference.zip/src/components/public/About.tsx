import React from 'react';
import { Award, ShieldCheck, CheckCircle, Stethoscope } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';

export function About() {
  const { content } = useClinic();

  const doctorName = content?.doctorName || 'Dr. R. K. Chouhan';
  const qualifications = content?.doctorQualifications || 'MBBS, MD (General Medicine), FICP';
  const regNumber = content?.doctorRegistrationNumber || 'MCI-REG-48921-DEL';
  const experienceYears = content?.doctorExperienceYears || 16;
  const specialty = content?.doctorSpecialty || 'Senior Consultant Physician & Internal Medicine Specialist';
  const heading = content?.aboutHeading || 'Committed to Clinical Excellence & Patient Wellness';
  const bio = content?.aboutBio || `Dr. R. K. Chouhan is a highly distinguished Senior Consultant Physician with over ${experienceYears} years of clinical practice. Having served at premier medical institutes, Dr. Chouhan specializes in early diagnosis, metabolic health, hypertension, diabetes mellitus, cardiovascular risk management, and acute infection therapies.\n\nOur clinic is built on the core principle of listening deeply to patients, explaining diagnoses clearly, and designing individualized, ethical treatment plans without unnecessary investigations.`;

  let highlights: string[] = [
    'Member of Association of Physicians of India (API)',
    'Certified in Advanced Diabetes Management & Glycemic Control',
    'Specialized in Preventive Cardiology & Hypertension Protocol',
    'State-of-the-Art In-Clinic Vitals & Diagnostic Screening'
  ];

  if (content?.aboutHighlights) {
    try {
      highlights = JSON.parse(content.aboutHighlights);
    } catch {
      // fallback
    }
  }

  return (
    <section id="about" className="py-16 md:py-24 bg-white border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Column: Doctor Profile Card */}
          <div className="lg:col-span-5 bg-slate-50 border border-slate-200 rounded-3xl p-6 sm:p-8 space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-sky-900 to-teal-800 text-white flex items-center justify-center font-bold text-xl shadow-md">
                <Stethoscope className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">{doctorName}</h3>
                <p className="text-xs text-sky-800 font-semibold">{qualifications}</p>
                <p className="text-[11px] text-slate-500 mt-0.5">{specialty}</p>
              </div>
            </div>

            {/* Official Registration & Credentials */}
            <div className="space-y-3 pt-2 border-t border-slate-200">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-500 font-medium">Council Registration:</span>
                <span className="font-mono font-bold text-slate-800">{regNumber}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-500 font-medium">Clinical Experience:</span>
                <span className="font-bold text-slate-800">{experienceYears}+ Years</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-500 font-medium">Practice Ethos:</span>
                <span className="font-semibold text-emerald-700">Evidence-Based & Compassionate</span>
              </div>
            </div>

            {/* Verified Trust Badges */}
            <div className="space-y-2 pt-2">
              {highlights.map((h, idx) => (
                <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-700">
                  <CheckCircle className="w-4 h-4 text-sky-700 shrink-0 mt-0.5" />
                  <span className="leading-snug">{h}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Bio & Clinical Philosophy */}
          <div className="lg:col-span-7 space-y-6">
            <div>
              <span className="text-xs font-bold text-sky-700 tracking-wider uppercase">
                About the Physician
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1.5">
                {heading}
              </h2>
            </div>

            <div className="space-y-4 text-sm text-slate-600 leading-relaxed">
              {bio.split('\n\n').map((paragraph, index) => (
                <p key={index}>{paragraph}</p>
              ))}
            </div>

            {/* Doctor's Quote Block */}
            <div className="p-5 bg-sky-50/70 border-l-4 border-sky-800 rounded-r-2xl space-y-2">
              <p className="text-xs italic text-slate-700 font-medium leading-relaxed">
                "A doctor's true success is not merely in prescribing medicine, but in giving the patient clarity, confidence, and peace of mind through empathetic listening."
              </p>
              <div className="text-xs font-bold text-slate-900">
                — {doctorName}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
