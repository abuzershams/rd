import React from 'react';
import { Clock, Calendar, AlertTriangle } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';

export function WorkingHours() {
  const { content, settings } = useClinic();

  const morningStart = settings?.morningStart || '09:30';
  const morningEnd = settings?.morningEnd || '13:30';
  const eveningStart = settings?.eveningStart || '17:00';
  const eveningEnd = settings?.eveningEnd || '21:00';

  const formatTime = (timeStr: string) => {
    const [h, m] = timeStr.split(':').map(Number);
    const period = h >= 12 ? 'PM' : 'AM';
    const displayH = h % 12 === 0 ? 12 : h % 12;
    const displayM = m < 10 ? `0${m}` : m;
    return `${displayH}:${displayM} ${period}`;
  };

  return (
    <section id="schedule" className="py-16 bg-slate-900 text-white border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-5 space-y-3">
            <span className="text-xs font-bold text-sky-400 tracking-wider uppercase">
              Clinic Consultation Timings
            </span>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Visiting Hours & Weekly Schedule
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed font-normal">
              Dr. Chouhan is available for in-clinic consultations during morning and evening shifts. Prior booking ensures zero waiting time.
            </p>
          </div>

          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Morning Shift */}
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-5 space-y-2">
              <span className="text-[11px] font-bold text-sky-400 uppercase tracking-wider">Morning Shift</span>
              <h3 className="text-sm font-bold text-white">Monday to Saturday</h3>
              <div className="text-base font-extrabold text-sky-300">
                {formatTime(morningStart)} – {formatTime(morningEnd)}
              </div>
              <p className="text-[11px] text-slate-400">Regular clinic consultations</p>
            </div>

            {/* Evening Shift */}
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-5 space-y-2">
              <span className="text-[11px] font-bold text-teal-400 uppercase tracking-wider">Evening Shift</span>
              <h3 className="text-sm font-bold text-white">Monday to Saturday</h3>
              <div className="text-base font-extrabold text-teal-300">
                {formatTime(eveningStart)} – {formatTime(eveningEnd)}
              </div>
              <p className="text-[11px] text-slate-400">Specialist checkups & reports</p>
            </div>

            {/* Sunday Shift */}
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-5 space-y-2">
              <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">Sunday Hours</span>
              <h3 className="text-sm font-bold text-white">Pre-Booked Only</h3>
              <div className="text-base font-extrabold text-amber-300">
                10:00 AM – 01:00 PM
              </div>
              <p className="text-[11px] text-slate-400">Emergency & follow-ups</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
