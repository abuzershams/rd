import React from 'react';
import {
  Stethoscope,
  Activity,
  HeartPulse,
  Wind,
  ShieldAlert,
  Users,
  Clock,
  ArrowRight
} from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';
import { ServiceItem } from '../../types';

interface ServicesProps {
  onSelectService: (serviceName: string, serviceId: string) => void;
}

export function Services({ onSelectService }: ServicesProps) {
  const { content } = useClinic();

  let services: ServiceItem[] = [
    {
      id: 'srv-general-checkup',
      title: 'Comprehensive Health & Vitals Check',
      description: 'Thorough clinical examination, symptom evaluation, blood pressure monitoring, systemic checkup, and personalized medical guidance.',
      duration: '20 mins',
      price: '₹600',
      category: 'General Medicine',
      iconName: 'Stethoscope',
      imageUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 'srv-diabetes-care',
      title: 'Diabetes & Glycemic Management',
      description: 'Individualized treatment for Type 1 & Type 2 Diabetes, HbA1c review, insulin adjustment, dietary counseling, and diabetic foot/kidney protection.',
      duration: '30 mins',
      price: '₹800',
      category: 'Endocrinology',
      iconName: 'Activity',
      imageUrl: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 'srv-cardio-hypertension',
      title: 'Hypertension & Preventive Cardiology',
      description: 'Assessment of blood pressure anomalies, ECG evaluation, lipid profile analysis, and cardiovascular risk reduction therapies.',
      duration: '25 mins',
      price: '₹800',
      category: 'Cardiovascular',
      iconName: 'HeartPulse',
      imageUrl: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 'srv-respiratory-infections',
      title: 'Respiratory Care & Chest Infections',
      description: 'Treatment for acute & chronic bronchitis, allergic asthma, persistent cough, seasonal viral fevers, and post-viral recovery care.',
      duration: '20 mins',
      price: '₹600',
      category: 'Pulmonology',
      iconName: 'Wind',
      imageUrl: 'https://images.unsplash.com/photo-1584515933487-779824d29309?auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 'srv-thyroid-metabolic',
      title: 'Thyroid & Metabolic Health',
      description: 'Diagnosis and regulation of Hypothyroidism, Hyperthyroidism, metabolic syndrome, fatty liver grade management, and weight concerns.',
      duration: '25 mins',
      price: '₹700',
      category: 'Metabolism',
      iconName: 'ShieldAlert',
      imageUrl: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 'srv-geriatric-care',
      title: 'Senior Citizen & Geriatric Consultation',
      description: 'Comprehensive care for elderly patients managing multiple chronic ailments, medication reconciliation, and bone/joint wellness.',
      duration: '30 mins',
      price: '₹800',
      category: 'Geriatrics',
      iconName: 'Users',
      imageUrl: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&w=800&q=80'
    }
  ];

  if (content?.servicesJson) {
    try {
      services = JSON.parse(content.servicesJson);
    } catch {
      // fallback
    }
  }

  const getIcon = (name: string) => {
    switch (name) {
      case 'Activity':
        return <Activity className="w-5 h-5 text-sky-700" />;
      case 'HeartPulse':
        return <HeartPulse className="w-5 h-5 text-rose-600" />;
      case 'Wind':
        return <Wind className="w-5 h-5 text-teal-600" />;
      case 'ShieldAlert':
        return <ShieldAlert className="w-5 h-5 text-amber-600" />;
      case 'Users':
        return <Users className="w-5 h-5 text-indigo-600" />;
      default:
        return <Stethoscope className="w-5 h-5 text-sky-700" />;
    }
  };

  return (
    <section id="services" className="py-16 md:py-24 bg-slate-50 border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <span className="text-xs font-bold text-sky-700 tracking-wider uppercase">
            Clinical Services & Treatments
          </span>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight sm:text-4xl">
            Specialized Medical Consultations
          </h2>
          <p className="text-sm text-slate-600 leading-relaxed font-normal">
            Every consultation includes dedicated time with Dr. Chouhan, comprehensive vitals recording, diagnosis explanation, and ongoing follow-up support.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <div
              key={service.id}
              className="bg-white border border-slate-200/90 rounded-2xl p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between group"
            >
              <div className="space-y-4">
                {/* Header Icon & Metadata */}
                <div className="flex items-center justify-between">
                  <div className="w-12 h-12 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center group-hover:scale-105 transition-transform">
                    {getIcon(service.iconName)}
                  </div>
                  <div className="text-right">
                    <span className="text-base font-black text-slate-900">{service.price}</span>
                    <div className="flex items-center gap-1 text-[11px] text-slate-400 font-medium">
                      <Clock className="w-3 h-3" />
                      <span>{service.duration}</span>
                    </div>
                  </div>
                </div>

                {/* Service Title */}
                <div>
                  <h3 className="text-base font-bold text-slate-900 group-hover:text-sky-800 transition-colors">
                    {service.title}
                  </h3>
                  <span className="text-[11px] text-sky-700 font-semibold">{service.category}</span>
                </div>

                {/* Description */}
                <p className="text-xs text-slate-600 leading-relaxed font-normal">
                  {service.description}
                </p>
              </div>

              {/* Action */}
              <div className="pt-6 mt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => onSelectService(service.title, service.id)}
                  className="w-full py-2.5 px-3 bg-slate-50 hover:bg-sky-900 hover:text-white text-slate-800 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2 group/btn"
                >
                  <span>Book This Consultation</span>
                  <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover/btn:translate-x-1" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
