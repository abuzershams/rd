import React from 'react';
import { Star, Quote, CheckCircle } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';
import { TestimonialItem } from '../../types';

export function Testimonials() {
  const { content } = useClinic();

  let testimonials: TestimonialItem[] = [
    {
      id: 'test-1',
      name: 'Rajendra Sharma',
      age: '54 yrs',
      city: 'Jaipur',
      comment: 'Dr. Chouhan accurately diagnosed my uncontrolled blood pressure after two other clinics failed to stabilize it. Within 3 weeks of his tailored plan, my readings are steady 120/80. His patience in explaining everything is rare.',
      rating: 5,
      date: 'August 2026',
      condition: 'Hypertension & Vitals Care'
    },
    {
      id: 'test-2',
      name: 'Sunita Verma',
      age: '42 yrs',
      city: 'Jaipur',
      comment: 'My HbA1c came down from 9.4 to 6.8 under Dr. Chouhan\'s guidance without burdensome heavy dosages. He emphasizes lifestyle corrections along with right medicines. The clinic atmosphere is very neat and calming.',
      rating: 5,
      date: 'September 2026',
      condition: 'Type 2 Diabetes Reversal'
    },
    {
      id: 'test-3',
      name: 'Deepak Meena',
      age: '31 yrs',
      city: 'Jaipur',
      comment: 'Had severe respiratory allergy and recurrent throat infections for months. Dr. Chouhan\'s targeted treatment cured it in 10 days. Online booking was very smooth and was attended to on time.',
      rating: 5,
      date: 'October 2026',
      condition: 'Chest Allergy & Infection'
    }
  ];

  if (content?.testimonialsJson) {
    try {
      testimonials = JSON.parse(content.testimonialsJson);
    } catch {
      // fallback
    }
  }

  return (
    <section id="testimonials" className="py-16 md:py-24 bg-white border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14 space-y-2">
          <span className="text-xs font-bold text-sky-700 tracking-wider uppercase">
            Patient Stories
          </span>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight sm:text-4xl">
            Verified Patient Experiences
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Real stories from patients diagnosed and successfully managed under Dr. Chouhan's clinical supervision.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <div
              key={t.id}
              className="bg-slate-50 border border-slate-200/90 rounded-2xl p-6 flex flex-col justify-between space-y-4 shadow-xs"
            >
              <div className="space-y-3">
                {/* Star rating */}
                <div className="flex items-center gap-1 text-amber-500">
                  {Array.from({ length: t.rating || 5 }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>

                {/* Comment */}
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-normal italic">
                  "{t.comment}"
                </p>
              </div>

              {/* Patient info */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-between text-xs">
                <div>
                  <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                    <span>{t.name}</span>
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    {t.city} {t.condition && `· ${t.condition}`}
                  </p>
                </div>
                {t.date && <span className="text-[10px] text-slate-400">{t.date}</span>}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
