import React, { useState, useEffect } from 'react';
import {
  Calendar as CalendarIcon,
  Clock,
  User,
  Phone,
  Mail,
  FileText,
  CheckCircle2,
  AlertCircle,
  MessageCircle,
  CalendarPlus,
  RefreshCw
} from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';
import { Booking } from '../../types';
import * as api from '../../services/api';

interface BookingSectionProps {
  selectedServiceName?: string;
  selectedServiceId?: string;
}

export function BookingSection({ selectedServiceName, selectedServiceId }: BookingSectionProps) {
  const { content, settings, showToast } = useClinic();

  // Form states
  const [patientName, setPatientName] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [patientEmail, setPatientEmail] = useState('');
  const [serviceName, setServiceName] = useState(selectedServiceName || 'Comprehensive Health & Vitals Check');
  const [serviceId, setServiceId] = useState(selectedServiceId || 'srv-general-checkup');
  const [preferredDate, setPreferredDate] = useState('');
  const [timeSlot, setTimeSlot] = useState('');
  const [message, setMessage] = useState('');
  const [honeypot, setHoneypot] = useState(''); // Spam honeypot

  // Slot availability
  const [availableSlots, setAvailableSlots] = useState<Array<{ timeSlot: string; isBooked: boolean }>>([]);
  const [isLoadingSlots, setIsLoadingSlots] = useState(false);
  const [slotReason, setSlotReason] = useState<string | null>(null);

  // Submission state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);

  // Update service if prop changes
  useEffect(() => {
    if (selectedServiceName) {
      setServiceName(selectedServiceName);
      setServiceId(selectedServiceId || 'srv-general-checkup');
    }
  }, [selectedServiceName, selectedServiceId]);

  // Set default date to tomorrow or today
  useEffect(() => {
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);
    const dateStr = tomorrow.toISOString().split('T')[0];
    setPreferredDate(dateStr);
  }, []);

  // Fetch slots whenever preferredDate changes
  useEffect(() => {
    if (!preferredDate) return;

    let isMounted = true;
    async function fetchSlots() {
      try {
        setIsLoadingSlots(true);
        setSlotReason(null);
        setTimeSlot('');
        const res = await api.getAvailableSlots(preferredDate);
        if (isMounted) {
          if (res.available) {
            setAvailableSlots(res.slots);
            // Auto select first available slot
            const firstOpen = res.slots.find(s => !s.isBooked);
            if (firstOpen) setTimeSlot(firstOpen.timeSlot);
          } else {
            setAvailableSlots([]);
            setSlotReason(res.reason || 'Clinic closed on this date');
          }
        }
      } catch (err: any) {
        if (isMounted) {
          setAvailableSlots([]);
          setSlotReason('Unable to load slots');
        }
      } finally {
        if (isMounted) setIsLoadingSlots(false);
      }
    }

    fetchSlots();
    return () => {
      isMounted = false;
    };
  }, [preferredDate]);

  // Handle Form Submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Anti-spam honeypot
    if (honeypot.trim() !== '') {
      return; // Silently abort for bots
    }

    // Patient name check
    if (!patientName.trim() || patientName.trim().length < 2) {
      setError('Please enter a valid patient name (at least 2 characters).');
      return;
    }

    // Indian mobile phone check (10 digits starting with 6,7,8,9 or with +91)
    const cleanPhone = patientPhone.replace(/\D/g, '');
    const isValidIndianNumber = cleanPhone.length === 10 || (cleanPhone.length === 12 && cleanPhone.startsWith('91'));
    if (!isValidIndianNumber) {
      setError('Please enter a valid 10-digit Indian mobile number (e.g. 98290 12345).');
      return;
    }

    if (!preferredDate || !timeSlot) {
      setError('Please choose a preferred consultation date and available time slot.');
      return;
    }

    try {
      setIsSubmitting(true);
      const res = await api.createBooking({
        patientName: patientName.trim(),
        patientPhone: cleanPhone,
        patientEmail: patientEmail.trim() || undefined,
        serviceId,
        serviceName,
        preferredDate,
        timeSlot,
        message: message.trim() || undefined,
        honeypot
      });

      setConfirmedBooking(res.booking);
      showToast('Appointment booked successfully! Confirmation created.', 'success');
    } catch (err: any) {
      setError(err.message || 'Unable to book appointment. Please try a different slot or call reception.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Add to Calendar (.ics download)
  const handleAddToCalendar = () => {
    if (!confirmedBooking) return;
    const { bookingNumber, preferredDate, timeSlot, serviceName } = confirmedBooking;
    const doctor = content?.doctorName || 'Dr. R. K. Chouhan';
    const address = content?.address || 'Dr. Chouhan Clinic, Jaipur';

    const icsData = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Dr Chouhan Clinic//Appointment//EN',
      'BEGIN:VEVENT',
      `SUMMARY:Doctor Appointment with ${doctor}`,
      `DESCRIPTION:Appointment Reference: ${bookingNumber}\\nConsultation: ${serviceName}\\nLocation: ${address}`,
      `LOCATION:${address}`,
      `DTSTART:${preferredDate.replace(/-/g, '')}T093000Z`,
      `DTEND:${preferredDate.replace(/-/g, '')}T100000Z`,
      'STATUS:CONFIRMED',
      'END:VEVENT',
      'END:VCALENDAR'
    ].join('\r\n');

    const blob = new Blob([icsData], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `dr-chouhan-appointment-${bookingNumber}.ics`;
    link.click();
  };

  // Min date string (today)
  const minDateStr = new Date().toISOString().split('T')[0];

  return (
    <section id="booking" className="py-16 md:py-24 bg-white border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-2">
          <span className="text-xs font-bold text-sky-700 tracking-wider uppercase">
            Online Appointments
          </span>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight sm:text-4xl">
            Book Doctor Consultation
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Select your preferred consultation date and guaranteed time slot. Realtime slot reservation with instant confirmation.
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          {!confirmedBooking ? (
            /* Booking Form */
            <form
              onSubmit={handleSubmit}
              className="bg-slate-50 border border-slate-200/90 rounded-3xl p-6 sm:p-10 shadow-sm space-y-5"
            >
              {error && (
                <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-3 text-rose-800 text-xs">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span className="font-semibold leading-relaxed">{error}</span>
                </div>
              )}

              {/* Honeypot hidden input for anti-spam */}
              <input
                type="text"
                name="website_url_check"
                value={honeypot}
                onChange={(e) => setHoneypot(e.target.value)}
                tabIndex={-1}
                autoComplete="off"
                className="hidden"
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Patient Name */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Patient Full Name *
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      required
                      value={patientName}
                      onChange={(e) => setPatientName(e.target.value)}
                      placeholder="e.g. Rahul Sharma"
                      className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-600"
                    />
                  </div>
                </div>

                {/* Patient Mobile */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Mobile Phone (10-Digit) *
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="tel"
                      required
                      value={patientPhone}
                      onChange={(e) => setPatientPhone(e.target.value)}
                      placeholder="e.g. 98260 12345"
                      className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-600"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Optional Email */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Email Address (Optional)
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="email"
                      value={patientEmail}
                      onChange={(e) => setPatientEmail(e.target.value)}
                      placeholder="e.g. rahul@example.com"
                      className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-600"
                    />
                  </div>
                </div>

                {/* Service Selection */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Clinical Consultation
                  </label>
                  <input
                    type="text"
                    value={serviceName}
                    onChange={(e) => setServiceName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-600 font-medium"
                  />
                </div>
              </div>

              {/* Date and Slot selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Date */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Preferred Date *
                  </label>
                  <div className="relative">
                    <CalendarIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="date"
                      required
                      min={minDateStr}
                      value={preferredDate}
                      onChange={(e) => setPreferredDate(e.target.value)}
                      className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-600"
                    />
                  </div>
                </div>

                {/* Slot Selector */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Available Time Slot *
                  </label>
                  <div className="relative">
                    <Clock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <select
                      required
                      value={timeSlot}
                      onChange={(e) => setTimeSlot(e.target.value)}
                      disabled={isLoadingSlots || availableSlots.length === 0}
                      className="w-full pl-10 pr-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-600 disabled:bg-slate-100"
                    >
                      {isLoadingSlots ? (
                        <option value="">Loading available slots...</option>
                      ) : availableSlots.length === 0 ? (
                        <option value="">{slotReason || 'No slots available'}</option>
                      ) : (
                        availableSlots.map((s, idx) => (
                          <option key={idx} value={s.timeSlot} disabled={s.isBooked}>
                            {s.timeSlot} {s.isBooked ? '(Booked)' : '✓ Available'}
                          </option>
                        ))
                      )}
                    </select>
                  </div>
                </div>
              </div>

              {/* Clinical Message / Symptoms */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Symptoms or Health Concern (Optional)
                </label>
                <textarea
                  rows={2}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Describe key symptoms, duration of illness, or previous prescriptions..."
                  className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-600"
                />
              </div>

              {/* Consultation Fee disclosure */}
              <div className="text-[11px] text-slate-500 bg-white p-3 rounded-xl border border-slate-200 flex items-center justify-between">
                <span>Doctor Consultation Fee:</span>
                <span className="font-bold text-slate-900">
                  {content?.consultationFeeText || '₹600'} (Pay at Reception)
                </span>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={isSubmitting || isLoadingSlots || (!timeSlot && availableSlots.length > 0)}
                className="w-full py-3.5 px-4 bg-sky-900 hover:bg-sky-800 active:bg-sky-950 text-white font-bold rounded-xl text-sm shadow-md transition-all hover:shadow-lg flex items-center justify-center gap-2 disabled:opacity-60"
              >
                {isSubmitting ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <span>Confirm Appointment Reservation</span>
                )}
              </button>
            </form>
          ) : (
            /* Confirmation Screen */
            <div className="bg-slate-50 border border-slate-200/90 rounded-3xl p-6 sm:p-10 shadow-sm space-y-6 text-center">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center mx-auto shadow-sm">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div>
                <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
                  Booking Confirmed
                </span>
                <h3 className="text-2xl font-black text-slate-900 mt-1">
                  Appointment Reserved!
                </h3>
                <p className="text-xs text-slate-600 mt-1">
                  Thank you, <strong className="text-slate-800">{confirmedBooking.patientName}</strong>. Your consultation has been scheduled with Dr. R. K. Chouhan.
                </p>
              </div>

              {/* Booking Summary Box */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 text-left space-y-3 text-xs">
                <div className="flex items-center justify-between border-b pb-2">
                  <span className="text-slate-500">Booking Reference:</span>
                  <span className="font-mono font-bold text-sky-900 text-sm">{confirmedBooking.bookingNumber}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Scheduled Date:</span>
                  <span className="font-bold text-slate-800">{confirmedBooking.preferredDate}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Time Slot:</span>
                  <span className="font-bold text-slate-800">{confirmedBooking.timeSlot}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Consultation:</span>
                  <span className="font-semibold text-slate-800">{confirmedBooking.serviceName}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Clinic Address:</span>
                  <span className="text-slate-800 truncate max-w-xs">{content?.address || 'Civil Lines, Jaipur'}</span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleAddToCalendar}
                  className="flex-1 py-3 px-4 bg-sky-900 hover:bg-sky-800 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm transition-colors"
                >
                  <CalendarPlus className="w-4 h-4" />
                  <span>Add to Calendar (.ics)</span>
                </button>

                <a
                  href={`https://wa.me/91${(content?.whatsapp || '9826012345').replace(/\D/g, '')}?text=${encodeURIComponent(
                    `Hello Dr. Chouhan Clinic, I have booked an appointment (Ref: ${confirmedBooking.bookingNumber}) for ${confirmedBooking.patientName} on ${confirmedBooking.preferredDate} at ${confirmedBooking.timeSlot}.`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-sm transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>WhatsApp Clinic</span>
                </a>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setConfirmedBooking(null);
                    setPatientName('');
                    setPatientPhone('');
                    setMessage('');
                  }}
                  className="text-xs text-sky-800 font-semibold hover:underline"
                >
                  Book Another Appointment
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
