import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';
import { FaqItem } from '../../types';

export function Faqs() {
  const { content } = useClinic();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  let faqs: FaqItem[] = [
    {
      question: 'How do I book an appointment with Dr. Chouhan?',
      answer: 'You can book directly via the online appointment form on this website by choosing your preferred date and slot. You can also call our reception desk at +91 98260 12345 or send a WhatsApp message.'
    },
    {
      question: "What are the clinic's consultation timings?",
      answer: 'The clinic operates Monday through Saturday in two shifts: Morning 9:30 AM – 1:30 PM and Evening 5:00 PM – 9:00 PM. Sundays are open from 10:00 AM – 1:00 PM for pre-booked cases.'
    },
    {
      question: 'What is the consultation fee and follow-up validity?',
      answer: 'The standard consultation fee is ₹600. A free follow-up review for the same condition is valid within 7 days of the initial visit.'
    },
    {
      question: 'Can I show previous medical reports during the consultation?',
      answer: 'Yes, absolutely. Please bring any recent blood test reports, ECGs, prescriptions, or imaging files to your appointment so Dr. Chouhan can review your full medical history.'
    },
    {
      question: 'Is walk-in consultation allowed without prior booking?',
      answer: 'Walk-ins are accommodated between scheduled slots; however, patients with prior online appointments receive first priority to avoid prolonged waiting.'
    }
  ];

  if (content?.faqsJson) {
    try {
      faqs = JSON.parse(content.faqsJson);
    } catch {
      // fallback
    }
  }

  const toggle = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-16 md:py-24 bg-slate-50 border-b border-slate-100">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-2">
          <span className="text-xs font-bold text-sky-700 tracking-wider uppercase">
            Patient Support
          </span>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">
            Frequently Asked Questions
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Clear answers regarding consultation procedures, fees, timings, and reports.
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="bg-white border border-slate-200/90 rounded-2xl overflow-hidden shadow-xs transition-colors"
              >
                <button
                  type="button"
                  onClick={() => toggle(idx)}
                  className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 font-bold text-xs sm:text-sm text-slate-900 hover:text-sky-900 transition-colors"
                >
                  <span className="leading-snug">{faq.question}</span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-400 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-sky-700' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-4 pb-4 sm:px-5 sm:pb-5 text-xs text-slate-600 leading-relaxed border-t border-slate-100 pt-3">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
