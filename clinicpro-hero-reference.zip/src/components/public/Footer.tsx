import React from 'react';
import { Stethoscope, Shield, Heart } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';

interface FooterProps {
  onOpenAdmin: () => void;
}

export function Footer({ onOpenAdmin }: FooterProps) {
  const { content } = useClinic();

  const clinicName = content?.clinicName || 'Dr. Chouhan Clinic';
  const doctorName = content?.doctorName || 'Dr. R. K. Chouhan';
  const qualifications = content?.doctorQualifications || 'MBBS, MD (General Medicine)';
  const regNumber = content?.doctorRegistrationNumber || 'MCI-REG-48921-DEL';
  const phone = content?.phone || '+91 98260 12345';
  const email = content?.email || 'care@drchouhanclinic.com';
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-950 text-slate-400 text-xs border-t border-slate-900 pb-20 sm:pb-8 pt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Col 1: Clinic & Doctor info */}
          <div className="space-y-3 md:col-span-2">
            <div className="flex items-center gap-2.5 text-white">
              <div className="w-8 h-8 rounded-lg bg-sky-700 flex items-center justify-center font-bold">
                <Stethoscope className="w-4 h-4" />
              </div>
              <span className="text-base font-bold tracking-tight">{clinicName}</span>
            </div>
            <p className="text-slate-400 leading-relaxed max-w-md font-normal">
              Senior Consultant Physician providing ethical, timely, and evidence-based clinical care. Specializing in Internal Medicine, Diabetes Mellitus, Hypertension, and Preventive Healthcare.
            </p>
            <div className="text-[11px] text-slate-500 space-y-0.5 pt-1">
              <p>Consultant: <strong className="text-slate-300">{doctorName}</strong> ({qualifications})</p>
              <p>Registration: <span className="font-mono text-slate-400">{regNumber}</span></p>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <a href="#about" className="hover:text-white transition-colors">About Doctor</a>
              </li>
              <li>
                <a href="#services" className="hover:text-white transition-colors">Services & Fees</a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-white transition-colors">Clinic Gallery</a>
              </li>
              <li>
                <a href="#schedule" className="hover:text-white transition-colors">Visiting Timings</a>
              </li>
              <li>
                <a href="#testimonials" className="hover:text-white transition-colors">Patient Reviews</a>
              </li>
              <li>
                <a href="#booking" className="hover:text-white transition-colors">Book Online</a>
              </li>
            </ul>
          </div>

          {/* Col 3: Direct Contacts & Hours */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Direct Contacts</h4>
            <div className="space-y-2 text-slate-400">
              <p>Phone: <a href={`tel:${phone}`} className="text-slate-300 hover:text-white">{phone}</a></p>
              <p>Email: <a href={`mailto:${email}`} className="text-slate-300 hover:text-white">{email}</a></p>
              <p className="text-slate-500 pt-1">
                Mon - Sat: 9:30 AM – 1:30 PM & 5:00 PM – 9:00 PM
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Bar with Discreet Admin Entry */}
        <div className="border-t border-slate-900 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-[11px]">
          <div>
            © {currentYear} {clinicName}. All medical rights reserved.
          </div>

          <div className="flex items-center gap-6">
            <span>Confidential & Ethical Medical Practice</span>
            {/* Small Admin entry in Footer per Section 2 */}
            <button
              type="button"
              onClick={onOpenAdmin}
              className="hover:text-slate-300 flex items-center gap-1 transition-colors"
              title="Clinic Owner Administration"
            >
              <Shield className="w-3 h-3 text-slate-600" />
              <span>Admin Access</span>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
