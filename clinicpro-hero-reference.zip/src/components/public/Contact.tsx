import React from 'react';
import { MapPin, Phone, Mail, MessageCircle, Clock, Star, ExternalLink } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';

export function Contact() {
  const { content } = useClinic();

  const phone = content?.phone || '+91 98260 12345';
  const whatsapp = content?.whatsapp || '+91 98260 12345';
  const emergencyPhone = content?.emergencyPhone || '+91 98260 12349';
  const email = content?.email || 'care@drchouhanclinic.com';
  const address = content?.address || '14-B, Medical Enclave, Opposite City Civil Hospital, Jaipur, Rajasthan - 302006';
  const mapEmbedUrl = content?.mapEmbedUrl || 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d113911.08479717144!2d75.71764654511674!3d26.91243364941913!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db479f976a161%3A0xb36b0c39f1c7d23a!2sJaipur%2C%20Rajasthan!5e0!3m2!1sen!2sin!4v1700000000000';
  const googleReviewUrl = content?.googleReviewUrl || 'https://g.page/r/drchouhanclinic/review';

  return (
    <section id="contact" className="py-16 md:py-24 bg-white border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Column: Contact Details */}
          <div className="lg:col-span-5 space-y-6">
            <div>
              <span className="text-xs font-bold text-sky-700 tracking-wider uppercase">
                Find Our Clinic
              </span>
              <h2 className="text-3xl font-black text-slate-900 tracking-tight sm:text-4xl mt-1">
                Contact & Visit Dr. Chouhan
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-2 leading-relaxed">
                Conveniently located with dedicated patient parking, wheelchair accessibility, and on-site pharmacy assistance.
              </p>
            </div>

            <div className="space-y-4 text-xs">
              {/* Address */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex items-start gap-3.5">
                <MapPin className="w-5 h-5 text-sky-700 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-slate-900">Clinic Location</h4>
                  <p className="text-slate-600 mt-0.5 leading-relaxed">{address}</p>
                </div>
              </div>

              {/* Phone & WhatsApp */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex items-start gap-3.5">
                <Phone className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-slate-900">Telephone & WhatsApp</h4>
                  <p className="text-slate-600 mt-0.5">
                    Reception: <a href={`tel:${phone}`} className="font-bold text-slate-800 hover:text-sky-800">{phone}</a>
                  </p>
                  <p className="text-slate-600 mt-0.5">
                    Emergency: <a href={`tel:${emergencyPhone}`} className="font-bold text-rose-700">{emergencyPhone}</a>
                  </p>
                  <div className="mt-2">
                    <a
                      href={`https://wa.me/91${whatsapp.replace(/\D/g, '')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-100/80 text-emerald-900 font-semibold rounded-lg hover:bg-emerald-200/80 transition-colors"
                    >
                      <MessageCircle className="w-3.5 h-3.5 text-emerald-700" />
                      <span>Direct WhatsApp Message</span>
                    </a>
                  </div>
                </div>
              </div>

              {/* Email */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex items-start gap-3.5">
                <Mail className="w-5 h-5 text-sky-700 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-slate-900">Inquiries & Reports</h4>
                  <p className="text-slate-600 mt-0.5">
                    <a href={`mailto:${email}`} className="text-sky-800 hover:underline">{email}</a>
                  </p>
                </div>
              </div>

              {/* Google Reviews Button */}
              {googleReviewUrl && (
                <div className="pt-2">
                  <a
                    href={googleReviewUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2.5 px-4 bg-white border border-slate-300 hover:border-slate-400 text-slate-800 font-semibold rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors"
                  >
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <span>Review Dr. Chouhan on Google</span>
                    <ExternalLink className="w-3 h-3 text-slate-400 ml-1" />
                  </a>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Google Maps Embed */}
          <div className="lg:col-span-7">
            <div className="bg-slate-100 rounded-3xl overflow-hidden border border-slate-200 shadow-sm aspect-video sm:aspect-[4/3] w-full">
              <iframe
                src={mapEmbedUrl}
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Dr. Chouhan Clinic Map"
                className="w-full h-full"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
