import React, { useState } from 'react';
import { Image as ImageIcon, Video, Play, X, ZoomIn, Film } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';
import { MediaItem } from '../../types';

export function Gallery() {
  const { mediaList } = useClinic();
  const [filter, setFilter] = useState<'all' | 'photo' | 'video'>('all');
  const [activeMedia, setActiveMedia] = useState<MediaItem | null>(null);

  const filteredMedia = mediaList.filter((m) => {
    if (filter === 'photo') return m.mediaType === 'photo';
    if (filter === 'video') return m.mediaType !== 'photo';
    return true;
  });

  return (
    <section id="gallery" className="py-16 md:py-24 bg-slate-50 border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
          <div>
            <span className="text-xs font-bold text-sky-700 tracking-wider uppercase">
              Facility & Diagnostics
            </span>
            <h2 className="text-3xl font-black text-slate-900 tracking-tight sm:text-4xl mt-1">
              Clinic Photo & Video Gallery
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Take a visual tour of our clean examination rooms, diagnostic equipment, and reception area.
            </p>
          </div>

          {/* Filter Buttons */}
          <div className="flex items-center gap-1 p-1 bg-slate-200/80 rounded-xl self-start sm:self-auto">
            <button
              type="button"
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                filter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Media
            </button>
            <button
              type="button"
              onClick={() => setFilter('photo')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                filter === 'photo' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Photos
            </button>
            <button
              type="button"
              onClick={() => setFilter('video')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                filter === 'video' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Videos
            </button>
          </div>
        </div>

        {/* Gallery Grid */}
        {filteredMedia.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center text-slate-400">
            <ImageIcon className="w-8 h-8 mx-auto text-slate-300 mb-2" />
            <p className="text-xs font-medium text-slate-600">No media available in this category.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMedia.map((item) => {
              const isVideo = item.mediaType === 'video' || item.mediaType === 'youtube' || item.mediaType === 'drive';

              return (
                <div
                  key={item.id}
                  onClick={() => setActiveMedia(item)}
                  className="group bg-white rounded-2xl overflow-hidden border border-slate-200/80 shadow-xs hover:shadow-md cursor-pointer transition-all flex flex-col"
                >
                  <div className="aspect-video bg-slate-900 relative overflow-hidden flex items-center justify-center">
                    {isVideo ? (
                      item.mediaType === 'youtube' || item.mediaType === 'drive' ? (
                        <div className="w-full h-full bg-slate-950 flex flex-col items-center justify-center text-slate-300">
                          <Film className="w-10 h-10 text-rose-500 mb-1" />
                          <span className="text-[11px] font-bold text-slate-200">Watch Video</span>
                        </div>
                      ) : (
                        <>
                          <video
                            src={item.url}
                            poster={item.posterUrl || item.thumbnailUrl}
                            muted
                            playsInline
                            preload="metadata"
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 bg-black/30 group-hover:bg-black/20 flex items-center justify-center transition-colors">
                            <div className="w-10 h-10 bg-white/90 text-sky-900 rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                              <Play className="w-4 h-4 ml-0.5" />
                            </div>
                          </div>
                        </>
                      )
                    ) : (
                      <>
                        <img
                          src={item.thumbnailUrl || item.url}
                          alt={item.altText || item.caption}
                          loading="lazy"
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 flex items-center justify-center transition-colors opacity-0 group-hover:opacity-100">
                          <div className="w-9 h-9 bg-white/90 text-slate-800 rounded-full flex items-center justify-center shadow-sm">
                            <ZoomIn className="w-4 h-4" />
                          </div>
                        </div>
                      </>
                    )}

                    {item.isDemo && (
                      <span className="absolute top-2.5 left-2.5 bg-amber-500 text-white text-[10px] font-black px-2 py-0.5 rounded shadow">
                        DEMO
                      </span>
                    )}

                    <span className="absolute bottom-2 right-2 bg-black/60 backdrop-blur-xs text-white text-[10px] font-semibold px-2 py-0.5 rounded">
                      {isVideo ? 'Video' : 'Photo'}
                    </span>
                  </div>

                  <div className="p-3.5 flex-1 flex flex-col justify-between">
                    <h4 className="text-xs font-bold text-slate-900 line-clamp-1">
                      {item.caption || item.filename}
                    </h4>
                    <p className="text-[11px] text-slate-400 capitalize mt-0.5">
                      {item.category}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Lightbox / Video Modal */}
      {activeMedia && (
        <div
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6"
          onClick={() => setActiveMedia(null)}
        >
          <div
            className="relative max-w-4xl w-full bg-black rounded-2xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setActiveMedia(null)}
              className="absolute top-4 right-4 z-20 w-9 h-9 bg-black/70 hover:bg-black text-white rounded-full flex items-center justify-center transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex flex-col">
              <div className="w-full max-h-[75vh] flex items-center justify-center bg-black">
                {activeMedia.mediaType === 'youtube' || activeMedia.mediaType === 'drive' ? (
                  <iframe
                    src={activeMedia.url}
                    title={activeMedia.caption}
                    className="w-full aspect-video border-0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                ) : activeMedia.mediaType === 'video' ? (
                  <video
                    src={activeMedia.url}
                    controls
                    autoPlay
                    playsInline
                    className="max-h-[75vh] w-full"
                  />
                ) : (
                  <img
                    src={activeMedia.url}
                    alt={activeMedia.altText}
                    className="max-h-[75vh] w-auto max-w-full object-contain"
                  />
                )}
              </div>

              <div className="p-4 bg-slate-950 text-white">
                <h3 className="text-sm font-bold">{activeMedia.caption}</h3>
                {activeMedia.altText && (
                  <p className="text-xs text-slate-400 mt-1">{activeMedia.altText}</p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
