import React from 'react';
import { Phone, MessageCircle, Calendar } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';

interface MobileActionBarProps {
  onBookClick: () => void;
}

export function MobileActionBar({ onBookClick }: MobileActionBarProps) {
  const { content } = useClinic();

  const phone = content?.phone || '+91 98260 12345';
  const whatsapp = content?.whatsapp || '+91 98260 12345';

  return (
    <div className="fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/90 py-2 px-3 sm:hidden shadow-lg">
      <div className="flex items-center gap-2">
        {/* Call Button */}
        <a
          href={`tel:${phone}`}
          className="flex-1 py-2.5 px-2 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
        >
          <Phone className="w-4 h-4 text-emerald-600" />
          <span>Call</span>
        </a>

        {/* WhatsApp Button */}
        <a
          href={`https://wa.me/91${whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(
            `Hello Dr. Chouhan Clinic, I would like to inquire about consultation timings and book an appointment.`
          )}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 py-2.5 px-2 bg-emerald-50 hover:bg-emerald-100 active:bg-emerald-200 text-emerald-800 border border-emerald-200 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
        >
          <MessageCircle className="w-4 h-4 text-emerald-600" />
          <span>WhatsApp</span>
        </a>

        {/* Book Appointment CTA */}
        <button
          type="button"
          onClick={onBookClick}
          className="flex-[1.4] py-2.5 px-2 bg-sky-900 hover:bg-sky-800 active:bg-sky-950 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 shadow-sm transition-colors"
        >
          <Calendar className="w-4 h-4" />
          <span>Book Now</span>
        </button>
      </div>
    </div>
  );
}
