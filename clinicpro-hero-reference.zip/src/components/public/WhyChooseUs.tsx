import React from 'react';
import { Award, CheckCircle, Clock, HeartHandshake } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';
import { WhyChooseUsItem } from '../../types';

export function WhyChooseUs() {
  const { content } = useClinic();

  let items: WhyChooseUsItem[] = [
    {
      title: '16+ Years Experience',
      description: 'Decades of trusted diagnostic expertise solving complex and chronic ailments with patient-centric dedication.',
      icon: 'Award'
    },
    {
      title: 'Zero Unnecessary Tests',
      description: 'Ethical medical practice prioritizing clinical assessment and only requesting essential, high-value laboratory investigations.',
      icon: 'CheckCircle'
    },
    {
      title: 'Minimal Waiting Time',
      description: 'Organized appointment scheduling with reserved time slots to respect your valuable time and comfort.',
      icon: 'Clock'
    },
    {
      title: 'Continuous Patient Care',
      description: 'Direct follow-up consultation window and instant WhatsApp communication for lab reports clarification.',
      icon: 'HeartHandshake'
    }
  ];

  if (content?.whyChooseUsJson) {
    try {
      items = JSON.parse(content.whyChooseUsJson);
    } catch {
      // fallback
    }
  }

  const getIcon = (name: string) => {
    switch (name) {
      case 'Award':
        return <Award className="w-6 h-6 text-sky-700" />;
      case 'CheckCircle':
        return <CheckCircle className="w-6 h-6 text-emerald-600" />;
      case 'Clock':
        return <Clock className="w-6 h-6 text-teal-600" />;
      default:
        return <HeartHandshake className="w-6 h-6 text-sky-700" />;
    }
  };

  return (
    <section className="py-16 md:py-20 bg-white border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-2">
          <span className="text-xs font-bold text-sky-700 tracking-wider uppercase">
            Ethical Medicine
          </span>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">
            Why Patients Trust Dr. Chouhan
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Dedicated to honest diagnoses, patient education, and clear recovery roadmaps.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {items.map((item, idx) => (
            <div
              key={idx}
              className="bg-slate-50 border border-slate-200/80 rounded-2xl p-6 space-y-3"
            >
              <div className="w-12 h-12 bg-white rounded-xl shadow-xs border border-slate-100 flex items-center justify-center">
                {getIcon(item.icon)}
              </div>
              <h3 className="text-sm font-bold text-slate-900">{item.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed font-normal">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
