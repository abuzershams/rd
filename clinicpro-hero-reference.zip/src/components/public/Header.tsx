import React, { useState } from 'react';
import { Stethoscope, Phone, Calendar, Menu, X, Shield, MessageCircle } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';

interface HeaderProps {
  onOpenAdmin: () => void;
  onBookClick: () => void;
}

export function Header({ onOpenAdmin, onBookClick }: HeaderProps) {
  const { content } = useClinic();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const clinicName = content?.clinicName || 'Dr. Chouhan Clinic';
  const phone = content?.phone || '+91 98260 12345';
  const whatsapp = content?.whatsapp || '+91 98260 12345';

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Top Notice Banner if enabled (scrolls away, not sticky) */}
      {content?.noticeBanner && content?.noticeBannerEnabled === 'true' && (
        <div className="bg-gradient-to-r from-sky-900 to-teal-900 text-white text-[11px] sm:text-xs py-1.5 px-4 text-center font-medium">
          <span>{content.noticeBanner}</span>
        </div>
      )}
    <header className="bg-white/95 backdrop-blur-md border-b border-slate-100 sticky top-0 z-40">

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="h-16 sm:h-18 flex items-center justify-between gap-2 sm:gap-4">
          {/* Logo & Doctor Title */}
          <a href="#hero" className="flex items-center gap-2.5 sm:gap-3 min-w-0 lg:shrink-0 group">
            <div className="w-10 h-10 shrink-0 rounded-xl bg-gradient-to-br from-sky-800 to-teal-700 flex items-center justify-center text-white shadow-sm group-hover:scale-105 transition-transform">
              <Stethoscope className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="text-[15px] sm:text-base truncate font-extrabold text-slate-900 tracking-tight leading-tight group-hover:text-sky-800 transition-colors">
                {clinicName}
              </div>
              <div className="hidden sm:block truncate text-[11px] text-slate-500 font-medium">
                {content?.doctorName || 'Dr. R. K. Chouhan'} · {content?.doctorQualifications || 'MBBS, MD'}
              </div>
            </div>
          </a>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-6 text-xs font-semibold text-slate-600">
            <button onClick={() => scrollTo('about')} className="hover:text-sky-800 transition-colors">
              About Doctor
            </button>
            <button onClick={() => scrollTo('services')} className="hover:text-sky-800 transition-colors">
              Treatments & Services
            </button>
            <button onClick={() => scrollTo('gallery')} className="hover:text-sky-800 transition-colors">
              Clinic Gallery
            </button>
            <button onClick={() => scrollTo('schedule')} className="hover:text-sky-800 transition-colors">
              Timings
            </button>
            <button onClick={() => scrollTo('testimonials')} className="hover:text-sky-800 transition-colors">
              Patient Reviews
            </button>
            <button onClick={() => scrollTo('contact')} className="hover:text-sky-800 transition-colors">
              Contact & Location
            </button>
          </nav>

          {/* Right Header CTAs & Discreet Admin Button */}
          <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
            {/* Quick Call Button (Desktop) */}
            <a
              href={`tel:${phone}`}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 bg-slate-50 hover:bg-slate-100 text-slate-800 text-xs font-semibold rounded-xl border border-slate-200 transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-600" />
              <span>Call Clinic</span>
            </a>

            {/* Book Now Button */}
            <button
              type="button"
              onClick={onBookClick}
              className="hidden sm:flex px-4 py-2.5 bg-sky-900 hover:bg-sky-800 active:bg-sky-950 text-white text-xs font-bold rounded-xl items-center gap-1.5 shadow-sm transition-all hover:shadow"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Book Appointment</span>
            </button>

            {/* Discreet Admin Entry Button in top-right header per Requirement */}
            <button
              type="button"
              onClick={onOpenAdmin}
              className="inline-flex items-center gap-1 p-2 sm:px-2.5 sm:py-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors text-[11px] font-semibold border border-transparent hover:border-slate-200"
              title="Clinic Owner / Admin Login"
              aria-label="Admin Portal"
            >
              <Shield className="w-3.5 h-3.5 text-sky-800" />
              <span className="hidden sm:inline">Admin</span>
            </button>

            {/* Mobile Hamburger */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-600 hover:text-slate-900 lg:hidden rounded-xl"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-6 space-y-3">
          <div className="flex flex-col space-y-2 text-sm font-semibold text-slate-700">
            <button onClick={() => scrollTo('about')} className="text-left py-2 border-b border-slate-100">
              About Dr. Chouhan
            </button>
            <button onClick={() => scrollTo('services')} className="text-left py-2 border-b border-slate-100">
              Services & Checkups
            </button>
            <button onClick={() => scrollTo('gallery')} className="text-left py-2 border-b border-slate-100">
              Photo & Video Gallery
            </button>
            <button onClick={() => scrollTo('schedule')} className="text-left py-2 border-b border-slate-100">
              Working Hours
            </button>
            <button onClick={() => scrollTo('testimonials')} className="text-left py-2 border-b border-slate-100">
              Patient Testimonials
            </button>
            <button onClick={() => scrollTo('contact')} className="text-left py-2 border-b border-slate-100">
              Location & Map
            </button>
          </div>

          <div className="pt-2 flex flex-col gap-2">
            <a
              href={`tel:${phone}`}
              className="w-full py-2.5 px-3 bg-slate-100 text-slate-800 text-xs font-semibold rounded-xl flex items-center justify-center gap-2"
            >
              <Phone className="w-4 h-4 text-emerald-600" />
              <span>Call Reception ({phone})</span>
            </a>
            <a
              href={`https://wa.me/91${whatsapp.replace(/\D/g, '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-3 bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold rounded-xl flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4 text-emerald-600" />
              <span>WhatsApp Us</span>
            </a>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAdmin();
              }}
              className="w-full py-2 text-slate-400 hover:text-slate-700 text-xs font-medium flex items-center justify-center gap-1.5"
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Admin Access</span>
            </button>
          </div>
        </div>
      )}
    </header>
    </>
  );
}
