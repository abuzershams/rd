import React, { useState } from 'react';
import { Header } from './Header';
import { Hero } from './Hero';
import { Stats } from './Stats';
import { About } from './About';
import { Services } from './Services';
import { WhyChooseUs } from './WhyChooseUs';
import { Gallery } from './Gallery';
import { Testimonials } from './Testimonials';
import { BookingSection } from './BookingSection';
import { WorkingHours } from './WorkingHours';
import { Faqs } from './Faqs';
import { Contact } from './Contact';
import { Footer } from './Footer';
import { MobileActionBar } from './MobileActionBar';
import { useClinic } from '../../context/ClinicContext';

interface PublicWebsiteProps {
  onOpenAdmin: () => void;
}

export function PublicWebsite({ onOpenAdmin }: PublicWebsiteProps) {
  const { content, isLoadingContent } = useClinic();
  const [selectedService, setSelectedService] = useState<{ name: string; id: string } | undefined>(undefined);

  const handleSelectService = (name: string, id: string) => {
    setSelectedService({ name, id });
    const el = document.getElementById('booking');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleBookClick = () => {
    const el = document.getElementById('booking');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Section visibility checks
  let visibility: Record<string, boolean> = {
    hero: true,
    stats: true,
    about: true,
    services: true,
    whyChooseUs: true,
    gallery: true,
    testimonials: true,
    booking: true,
    workingHours: true,
    faqs: true,
    contact: true
  };

  if (content?.sectionVisibilityJson) {
    try {
      visibility = { ...visibility, ...JSON.parse(content.sectionVisibilityJson) };
    } catch {
      // fallback
    }
  }

  if (isLoadingContent && !content) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-4 border-sky-800 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-semibold text-slate-600">Loading Dr. Chouhan Clinic...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white text-slate-900 selection:bg-sky-100 selection:text-sky-900">
      <Header onOpenAdmin={onOpenAdmin} onBookClick={handleBookClick} />

      <main>
        {visibility.hero !== false && <Hero onBookClick={handleBookClick} />}
        {visibility.stats !== false && <Stats />}
        {visibility.about !== false && <About />}
        {visibility.services !== false && <Services onSelectService={handleSelectService} />}
        {visibility.whyChooseUs !== false && <WhyChooseUs />}
        {visibility.gallery !== false && <Gallery />}
        {visibility.testimonials !== false && <Testimonials />}
        {visibility.booking !== false && (
          <BookingSection
            selectedServiceName={selectedService?.name}
            selectedServiceId={selectedService?.id}
          />
        )}
        {visibility.workingHours !== false && <WorkingHours />}
        {visibility.faqs !== false && <Faqs />}
        {visibility.contact !== false && <Contact />}
      </main>

      <Footer onOpenAdmin={onOpenAdmin} />
      <MobileActionBar onBookClick={handleBookClick} />
    </div>
  );
}
