import React, { useState, useRef } from 'react';
import {
  Upload,
  Image as ImageIcon,
  Video,
  Trash2,
  RefreshCw,
  Search,
  CheckCircle2,
  X,
  Play,
  ArrowUp,
  ArrowDown,
  Sparkles,
  Link,
  Film,
  HardDrive
} from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';
import { MediaItem } from '../../types';
import * as api from '../../services/api';
import {
  processImage,
  processImageFile,
  generateVideoPoster,
  uploadToFirebaseStorage,
  deleteFromFirebaseStorage,
  requestWakeLock,
  releaseWakeLock,
  parseExternalVideoUrl,
  formatBytes
} from '../../utils/mediaProcessor';

interface UploadQueueItem {
  id: string;
  file: File;
  name: string;
  sizeFormatted: string;
  type: 'photo' | 'video';
  progress: number;
  status: 'pending' | 'processing' | 'uploading' | 'saved' | 'failed' | 'cancelled';
  errorMessage?: string;
  cancelFn?: () => void;
}

export function MediaManager() {
  const { mediaList, refreshMedia, showToast } = useClinic();

  // Active category tab
  const [activeTab, setActiveTab] = useState<'all' | 'photo' | 'video' | 'gallery' | 'hero' | 'services'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Upload queue
  const [queue, setQueue] = useState<UploadQueueItem[]>([]);
  const [isProcessingQueue, setIsProcessingQueue] = useState(false);

  // Hidden file inputs
  const photoInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const allMediaInputRef = useRef<HTMLInputElement>(null);
  const replaceInputRef = useRef<HTMLInputElement>(null);

  // Replace State
  const [replacingMedia, setReplacingMedia] = useState<MediaItem | null>(null);

  // External URL Modal
  const [showExternalModal, setShowExternalModal] = useState(false);
  const [externalUrl, setExternalUrl] = useState('');
  const [externalCaption, setExternalCaption] = useState('');
  const [isSavingExternal, setIsSavingExternal] = useState(false);

  // Selection & Bulk delete
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [itemToDelete, setItemToDelete] = useState<MediaItem | null>(null);
  const [showBulkDeleteConfirm, setShowBulkDeleteConfirm] = useState(false);

  // Active video preview in modal
  const [previewVideoUrl, setPreviewVideoUrl] = useState<string | null>(null);

  // Format bytes
  const formatBytes = (bytes: number) => {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
  };

  // Handle files selected from inputs
  const handleFilesSelected = (files: FileList | null, forceType?: 'photo' | 'video') => {
    if (!files || files.length === 0) return;

    const newItems: UploadQueueItem[] = [];

    Array.from(files).forEach((file) => {
      const isVideo = forceType === 'video' || file.type.startsWith('video/');
      const itemType = isVideo ? 'video' : 'photo';

      // 150MB limit check
      if (file.size > 150 * 1024 * 1024) {
        showToast(`File "${file.name}" exceeds 150 MB maximum size limit.`, 'error');
        return;
      }

      newItems.push({
        id: `upload-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        file,
        name: file.name,
        sizeFormatted: formatBytes(file.size),
        type: itemType,
        progress: 0,
        status: 'pending'
      });
    });

    if (newItems.length > 0) {
      setQueue((prev) => [...prev, ...newItems]);
      processUploadQueue([...queue, ...newItems]);
    }
  };

  // Sequential Queue Processor
  const processUploadQueue = async (currentQueue: UploadQueueItem[]) => {
    if (isProcessingQueue) return;
    setIsProcessingQueue(true);
    await requestWakeLock();

    try {
      for (const item of currentQueue) {
        if (item.status !== 'pending') continue;

        // Mark processing
        setQueue((prev) =>
          prev.map((q) => (q.id === item.id ? { ...q, status: 'processing', progress: 10 } : q))
        );

        try {
          if (item.type === 'photo') {
            // Process photo with robust fallback chain (Requirement 1, 2, 3, 4, 5, 6, 7)
            const imageResult = await processImage(item.file);

            if (imageResult.warning) {
              showToast(imageResult.warning, 'info', imageResult.details);
            }

            // Upload Full Photo
            setQueue((prev) =>
              prev.map((q) => (q.id === item.id ? { ...q, status: 'uploading', progress: 30 } : q))
            );

            const timestamp = Date.now();
            const storageBasePath = `media/photos/${timestamp}_${item.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;

            const fullUpload = uploadToFirebaseStorage(
              storageBasePath,
              imageResult.fullBlob,
              (p) => {
                setQueue((prev) =>
                  prev.map((q) => (q.id === item.id ? { ...q, progress: 30 + Math.round(p * 0.4) } : q))
                );
              },
              { contentType: imageResult.contentType }
            );

            // Set cancel handle
            setQueue((prev) =>
              prev.map((q) => (q.id === item.id ? { ...q, cancelFn: fullUpload.cancel } : q))
            );

            const downloadUrl = await fullUpload.promise;

            // Thumbnail handling: failure must never fail the main upload (Requirement 5)
            let thumbUrl = downloadUrl;
            let thumbStoragePath = '';

            if (imageResult.thumbBlob) {
              try {
                const thumbPath = `media/photos/thumb_${timestamp}_${item.name.replace(/[^a-zA-Z0-9._-]/g, '_')}.jpg`;
                const thumbUpload = uploadToFirebaseStorage(
                  thumbPath,
                  imageResult.thumbBlob,
                  undefined,
                  { contentType: 'image/jpeg' }
                );
                thumbUrl = await thumbUpload.promise;
                thumbStoragePath = thumbPath;
              } catch (thumbErr: any) {
                console.warn('[MediaManager] Thumbnail upload failed, fallback to main URL:', thumbErr);
                thumbUrl = downloadUrl;
                thumbStoragePath = '';
              }
            }

            // Save metadata document
            await api.saveMediaItem({
              url: downloadUrl,
              storagePath: storageBasePath,
              thumbnailUrl: thumbUrl,
              thumbnailStoragePath: thumbStoragePath || undefined,
              mediaType: 'photo',
              filename: item.name,
              sizeBytes: item.file.size,
              caption: item.name.replace(/\.[^/.]+$/, '').replace(/_/g, ' '),
              altText: `Dr. Chouhan Clinic - ${item.name}`,
              category: 'gallery',
              slot: 'gallery'
            });

            setQueue((prev) =>
              prev.map((q) => (q.id === item.id ? { ...q, status: 'saved', progress: 100 } : q))
            );
          } else {
            // Video processing
            const posterBlob = await generateVideoPoster(item.file);
            let posterUrl = '';
            let posterStoragePath = '';

            const timestamp = Date.now();
            const videoStoragePath = `media/videos/${timestamp}_${item.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;

            if (posterBlob) {
              posterStoragePath = `media/videos/poster_${timestamp}.jpg`;
              const posterUpload = uploadToFirebaseStorage(posterStoragePath, posterBlob, undefined, { contentType: 'image/jpeg' });
              posterUrl = await posterUpload.promise;
            }

            // Upload Video File
            setQueue((prev) =>
              prev.map((q) => (q.id === item.id ? { ...q, status: 'uploading', progress: 20 } : q))
            );

            const videoUpload = uploadToFirebaseStorage(
              videoStoragePath,
              item.file,
              (p) => {
                setQueue((prev) =>
                  prev.map((q) => (q.id === item.id ? { ...q, progress: 20 + Math.round(p * 0.75) } : q))
                );
              },
              { contentType: item.file.type || 'video/mp4' }
            );

            setQueue((prev) =>
              prev.map((q) => (q.id === item.id ? { ...q, cancelFn: videoUpload.cancel } : q))
            );

            const videoDownloadUrl = await videoUpload.promise;

            // Save video metadata
            await api.saveMediaItem({
              url: videoDownloadUrl,
              storagePath: videoStoragePath,
              posterUrl: posterUrl || undefined,
              posterStoragePath: posterStoragePath || undefined,
              thumbnailUrl: posterUrl || undefined,
              mediaType: 'video',
              filename: item.name,
              sizeBytes: item.file.size,
              caption: item.name.replace(/\.[^/.]+$/, '').replace(/_/g, ' '),
              altText: `Dr. Chouhan Clinic Video - ${item.name}`,
              category: 'clinic',
              slot: 'video-gallery'
            });

            setQueue((prev) =>
              prev.map((q) => (q.id === item.id ? { ...q, status: 'saved', progress: 100 } : q))
            );
          }

          await refreshMedia();
        } catch (err: any) {
          const isCancel = err.message?.includes('cancelled');
          const errorName = err?.name || 'UploadError';
          const errorMessage = err?.message || 'Upload failed';
          const details = `${item.name} (${item.file.type || 'unknown'}, ${formatBytes(item.file.size)}): ${errorName} - ${errorMessage}`;

          console.error('[MediaManager] Upload error:', {
            fileName: item.name,
            type: item.file.type,
            size: item.file.size,
            errorName,
            errorMessage,
            error: err
          });

          if (!isCancel) {
            showToast(errorMessage, 'error', details);
          }

          setQueue((prev) =>
            prev.map((q) =>
              q.id === item.id
                ? {
                    ...q,
                    status: isCancel ? 'cancelled' : 'failed',
                    errorMessage: errorMessage
                  }
                : q
            )
          );
        }
      }
    } finally {
      setIsProcessingQueue(false);
      releaseWakeLock();
    }
  };

  // Safe Replace flow
  const handleReplaceFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !replacingMedia) return;

    try {
      showToast(`Uploading replacement for "${replacingMedia.filename}"...`, 'info');
      const isVideo = file.type.startsWith('video/') || replacingMedia.mediaType === 'video';
      const timestamp = Date.now();

      let newUrl = '';
      let newStoragePath = '';
      let newThumbUrl = '';
      let newPosterUrl = '';

      if (!isVideo) {
        const imageResult = await processImage(file);
        if (imageResult.warning) {
          showToast(imageResult.warning, 'info', imageResult.details);
        }

        newStoragePath = `media/photos/${timestamp}_${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
        const fullUpload = uploadToFirebaseStorage(
          newStoragePath,
          imageResult.fullBlob,
          undefined,
          { contentType: imageResult.contentType }
        );
        newUrl = await fullUpload.promise;

        if (imageResult.thumbBlob) {
          try {
            const thumbStoragePath = `media/photos/thumb_${timestamp}.jpg`;
            const thumbUpload = uploadToFirebaseStorage(
              thumbStoragePath,
              imageResult.thumbBlob,
              undefined,
              { contentType: 'image/jpeg' }
            );
            newThumbUrl = await thumbUpload.promise;
          } catch (thumbErr) {
            console.warn('[MediaManager] Replace thumbnail upload failed, fallback to main URL:', thumbErr);
            newThumbUrl = newUrl;
          }
        } else {
          newThumbUrl = newUrl;
        }
      } else {
        newStoragePath = `media/videos/${timestamp}_${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
        const videoUpload = uploadToFirebaseStorage(
          newStoragePath,
          file,
          undefined,
          { contentType: file.type || 'video/mp4' }
        );
        newUrl = await videoUpload.promise;

        const posterBlob = await generateVideoPoster(file);
        if (posterBlob) {
          const posterUpload = uploadToFirebaseStorage(`media/videos/poster_${timestamp}.jpg`, posterBlob, undefined, { contentType: 'image/jpeg' });
          newPosterUrl = await posterUpload.promise;
        }
      }

      // Step 3 & 4: Update Firestore metadata document first
      await api.replaceMediaItem(replacingMedia.id, {
        url: newUrl,
        storagePath: newStoragePath,
        thumbnailUrl: newThumbUrl || newPosterUrl || newUrl,
        posterUrl: newPosterUrl || undefined,
        filename: file.name,
        sizeBytes: file.size
      });

      // Step 5: Clean up old storage objects
      if (replacingMedia.storagePath) {
        deleteFromFirebaseStorage(replacingMedia.storagePath).catch(() => {});
      }

      showToast(`"${replacingMedia.filename}" replaced safely without broken links.`, 'success');
      await refreshMedia();
    } catch (err: any) {
      const errorName = err?.name || 'ReplaceError';
      const errorMessage = err?.message || 'Failed to replace media asset';
      const details = `${file.name} (${file.type || 'unknown'}, ${formatBytes(file.size)}): ${errorName} - ${errorMessage}`;

      console.error('[MediaManager] Replace error:', {
        fileName: file.name,
        type: file.type,
        size: file.size,
        errorName,
        errorMessage,
        error: err
      });

      showToast(errorMessage, 'error', details);
    } finally {
      setReplacingMedia(null);
      if (replaceInputRef.current) replaceInputRef.current.value = '';
    }
  };

  // Delete single media
  const handleConfirmDelete = async () => {
    if (!itemToDelete) return;
    try {
      await api.deleteMediaItem(itemToDelete.id);
      if (itemToDelete.storagePath) {
        deleteFromFirebaseStorage(itemToDelete.storagePath).catch(() => {});
      }
      showToast(`Deleted "${itemToDelete.filename}".`, 'success');
      await refreshMedia();
    } catch (err: any) {
      showToast(err.message || 'Failed to delete media item', 'error');
    } finally {
      setItemToDelete(null);
    }
  };

  // Bulk Delete
  const handleBulkDelete = async () => {
    try {
      for (const id of selectedIds) {
        const item = mediaList.find((m) => m.id === id);
        await api.deleteMediaItem(id);
        if (item?.storagePath) {
          deleteFromFirebaseStorage(item.storagePath).catch(() => {});
        }
      }
      showToast(`Deleted ${selectedIds.length} media items.`, 'success');
      setSelectedIds([]);
      await refreshMedia();
    } catch (err: any) {
      showToast(err.message || 'Bulk delete encountered an issue', 'error');
    } finally {
      setShowBulkDeleteConfirm(false);
    }
  };

  // External Video link addition
  const handleAddExternalVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseExternalVideoUrl(externalUrl);
    if (!parsed) {
      showToast('Please enter a valid YouTube, Google Drive, or MP4 video URL.', 'error');
      return;
    }

    try {
      setIsSavingExternal(true);
      await api.saveMediaItem({
        url: parsed.embedUrl,
        mediaType: parsed.type === 'direct' ? 'video' : parsed.type,
        filename: parsed.type === 'youtube' ? 'YouTube Video' : 'Video Link',
        sizeBytes: 0,
        caption: externalCaption.trim() || 'Clinical Overview Video',
        altText: externalCaption.trim() || 'Dr. Chouhan Clinic Video',
        category: 'clinic',
        slot: 'video-gallery'
      });
      showToast('Video added to clinic media library!', 'success');
      setShowExternalModal(false);
      setExternalUrl('');
      setExternalCaption('');
      await refreshMedia();
    } catch (err: any) {
      showToast(err.message || 'Failed to add video link', 'error');
    } finally {
      setIsSavingExternal(false);
    }
  };

  // Reorder items
  const handleMoveOrder = async (index: number, direction: 'up' | 'down') => {
    const newItems = [...mediaList];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= newItems.length) return;

    const temp = newItems[index];
    newItems[index] = newItems[targetIndex];
    newItems[targetIndex] = temp;

    const orderedIds = newItems.map((m) => m.id);
    await api.reorderMedia(orderedIds);
    await refreshMedia();
  };

  // Filter items
  const filteredItems = mediaList.filter((m) => {
    if (activeTab === 'photo' && m.mediaType !== 'photo') return false;
    if (activeTab === 'video' && m.mediaType !== 'video' && m.mediaType !== 'youtube' && m.mediaType !== 'drive') return false;
    if (activeTab === 'gallery' && m.slot !== 'gallery') return false;
    if (activeTab === 'hero' && m.slot !== 'hero') return false;
    if (activeTab === 'services' && m.category !== 'services') return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        m.filename.toLowerCase().includes(q) ||
        m.caption.toLowerCase().includes(q) ||
        m.altText.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // Calculate storage metrics
  const totalSizeBytes = mediaList.reduce((acc, m) => acc + (m.sizeBytes || 0), 0);
  const photoCount = mediaList.filter((m) => m.mediaType === 'photo').length;
  const videoCount = mediaList.filter((m) => m.mediaType !== 'photo').length;

  return (
    <div className="space-y-6">
      {/* Hidden real HTML file inputs for native phone picker */}
      <input
        ref={photoInputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={(e) => handleFilesSelected(e.target.files, 'photo')}
      />
      <input
        ref={videoInputRef}
        type="file"
        accept="video/*"
        multiple
        className="hidden"
        onChange={(e) => handleFilesSelected(e.target.files, 'video')}
      />
      <input
        ref={allMediaInputRef}
        type="file"
        accept="image/*,video/*"
        multiple
        className="hidden"
        onChange={(e) => handleFilesSelected(e.target.files)}
      />
      <input
        ref={replaceInputRef}
        type="file"
        accept="image/*,video/*"
        className="hidden"
        onChange={handleReplaceFileSelected}
      />

      {/* Top Banner & Upload Triggers */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <ImageIcon className="w-5 h-5 text-sky-700" />
            Clinic Photos & Videos Manager
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Mobile-optimized direct uploads. Photos auto-resized up to 1920px with 400px thumbnails. Videos up to 150 MB.
          </p>
          <div className="flex items-center gap-4 mt-2 text-xs text-slate-500">
            <span className="flex items-center gap-1 font-medium text-slate-700">
              <HardDrive className="w-3.5 h-3.5 text-slate-400" />
              {formatBytes(totalSizeBytes)} storage
            </span>
            <span>·</span>
            <span>{photoCount} Photos</span>
            <span>·</span>
            <span>{videoCount} Videos</span>
          </div>
        </div>

        {/* 3 Native Mobile File Input Buttons */}
        <div className="flex flex-wrap gap-2 w-full md:w-auto">
          <button
            type="button"
            onClick={() => photoInputRef.current?.click()}
            className="flex-1 md:flex-none px-3.5 py-2 bg-sky-900 hover:bg-sky-800 active:bg-sky-950 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors shadow-sm"
          >
            <ImageIcon className="w-4 h-4" />
            <span>Choose Photos</span>
          </button>
          <button
            type="button"
            onClick={() => videoInputRef.current?.click()}
            className="flex-1 md:flex-none px-3.5 py-2 bg-slate-900 hover:bg-slate-800 active:bg-black text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors shadow-sm"
          >
            <Video className="w-4 h-4" />
            <span>Choose Videos</span>
          </button>
          <button
            type="button"
            onClick={() => allMediaInputRef.current?.click()}
            className="flex-1 md:flex-none px-3.5 py-2 border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
          >
            <Upload className="w-4 h-4 text-slate-500" />
            <span>Photos & Videos</span>
          </button>
          <button
            type="button"
            onClick={() => setShowExternalModal(true)}
            className="flex-1 md:flex-none px-3 py-2 border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-medium rounded-xl flex items-center justify-center gap-1.5"
          >
            <Link className="w-3.5 h-3.5 text-slate-500" />
            <span>Link Video</span>
          </button>
        </div>
      </div>

      {/* Upload Progress Queue */}
      {queue.length > 0 && (
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
            <span>Upload & Processing Queue ({queue.length})</span>
            <button
              onClick={() => setQueue((prev) => prev.filter((q) => q.status === 'uploading' || q.status === 'processing'))}
              className="text-slate-400 hover:text-slate-600 text-[11px]"
            >
              Clear Completed
            </button>
          </div>
          <div className="space-y-2 max-h-56 overflow-y-auto">
            {queue.map((item) => (
              <div key={item.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 truncate pr-2">
                    {item.type === 'photo' ? (
                      <ImageIcon className="w-4 h-4 text-sky-600 shrink-0" />
                    ) : (
                      <Video className="w-4 h-4 text-emerald-600 shrink-0" />
                    )}
                    <span className="font-medium text-slate-800 truncate">{item.name}</span>
                    <span className="text-slate-400 text-[10px]">({item.sizeFormatted})</span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {item.status === 'uploading' && (
                      <span className="text-sky-700 font-bold">{item.progress}%</span>
                    )}
                    {item.status === 'processing' && (
                      <span className="text-amber-700 font-medium">Processing...</span>
                    )}
                    {item.status === 'saved' && (
                      <span className="text-emerald-700 font-semibold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Saved Live
                      </span>
                    )}
                    {item.status === 'failed' && (
                      <span className="text-rose-600 font-medium">{item.errorMessage || 'Failed'}</span>
                    )}
                    {item.status === 'uploading' && item.cancelFn && (
                      <button
                        onClick={item.cancelFn}
                        className="p-1 hover:bg-slate-200 rounded text-slate-500"
                        title="Cancel upload"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
                {/* Progress bar */}
                {(item.status === 'uploading' || item.status === 'processing') && (
                  <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-sky-600 h-1.5 transition-all duration-200 rounded-full"
                      style={{ width: `${item.progress}%` }}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filter Tabs & Search */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Segmented Controls (Buttons, not static pills) */}
        <div className="flex items-center p-1 bg-slate-100 rounded-xl overflow-x-auto">
          {[
            { id: 'all', label: 'All' },
            { id: 'photo', label: 'Photos' },
            { id: 'video', label: 'Videos' },
            { id: 'gallery', label: 'Gallery' },
            { id: 'hero', label: 'Hero' },
            { id: 'services', label: 'Services' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors ${
                activeTab === tab.id
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search bar */}
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search media..."
            className="w-full pl-9 pr-3.5 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-600"
          />
        </div>
      </div>

      {/* Bulk actions bar if items are selected */}
      {selectedIds.length > 0 && (
        <div className="p-3 bg-sky-50 border border-sky-200 rounded-xl flex items-center justify-between text-xs text-sky-900">
          <span className="font-semibold">{selectedIds.length} items selected</span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedIds([])}
              className="px-2.5 py-1 text-slate-600 hover:text-slate-900"
            >
              Deselect All
            </button>
            <button
              onClick={() => setShowBulkDeleteConfirm(true)}
              className="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white font-medium rounded-lg"
            >
              Delete Selected
            </button>
          </div>
        </div>
      )}

      {/* Media Grid */}
      {filteredItems.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center text-slate-400">
          <ImageIcon className="w-10 h-10 mx-auto text-slate-300 mb-2" />
          <p className="text-sm font-medium text-slate-700">No media found</p>
          <p className="text-xs text-slate-400 mt-1">Tap Choose Photos or Choose Videos above to upload.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredItems.map((item, index) => {
            const isSelected = selectedIds.includes(item.id);
            const isVideo = item.mediaType === 'video' || item.mediaType === 'youtube' || item.mediaType === 'drive';

            return (
              <div
                key={item.id}
                className={`bg-white border rounded-2xl overflow-hidden shadow-sm flex flex-col transition-all ${
                  isSelected ? 'border-sky-500 ring-2 ring-sky-500/20' : 'border-slate-200'
                }`}
              >
                {/* Media Preview Box */}
                <div className="relative aspect-video bg-slate-900 flex items-center justify-center overflow-hidden group">
                  {isVideo ? (
                    item.mediaType === 'youtube' || item.mediaType === 'drive' ? (
                      <div className="relative w-full h-full bg-slate-950 flex flex-col items-center justify-center text-slate-300">
                        <Film className="w-10 h-10 text-rose-500 mb-2" />
                        <span className="text-xs font-semibold">{item.mediaType.toUpperCase()} Video</span>
                      </div>
                    ) : (
                      <>
                        <video
                          src={item.url}
                          poster={item.posterUrl || item.thumbnailUrl}
                          playsInline
                          muted
                          preload="metadata"
                          className="w-full h-full object-cover"
                        />
                        <button
                          type="button"
                          onClick={() => setPreviewVideoUrl(item.url)}
                          className="absolute inset-0 m-auto w-10 h-10 bg-black/60 hover:bg-black/80 text-white rounded-full flex items-center justify-center transition-transform group-hover:scale-110"
                        >
                          <Play className="w-5 h-5 ml-0.5" />
                        </button>
                      </>
                    )
                  ) : (
                    <img
                      src={item.thumbnailUrl || item.url}
                      alt={item.altText || item.filename}
                      loading="lazy"
                      className="w-full h-full object-cover"
                    />
                  )}

                  {/* Demo Indicator */}
                  {item.isDemo && (
                    <span className="absolute top-2 left-2 bg-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow">
                      DEMO
                    </span>
                  )}

                  {/* Multi-select checkbox */}
                  <input
                    type="checkbox"
                    checked={isSelected}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedIds((prev) => [...prev, item.id]);
                      } else {
                        setSelectedIds((prev) => prev.filter((id) => id !== item.id));
                      }
                    }}
                    className="absolute top-2 right-2 w-4 h-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500 cursor-pointer"
                  />
                </div>

                {/* Content details */}
                <div className="p-3.5 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 truncate" title={item.caption || item.filename}>
                      {item.caption || item.filename}
                    </h3>
                    <p className="text-[11px] text-slate-400 truncate mt-0.5">
                      {item.filename} {item.sizeBytes > 0 && `· ${formatBytes(item.sizeBytes)}`}
                    </p>
                  </div>

                  {/* Actions Bar */}
                  <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs">
                    {/* Reorder Up/Down buttons (Mobile friendly fallback) */}
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleMoveOrder(index, 'up')}
                        disabled={index === 0}
                        className="p-1 hover:bg-slate-100 text-slate-500 disabled:opacity-30 rounded"
                        title="Move Up"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleMoveOrder(index, 'down')}
                        disabled={index === mediaList.length - 1}
                        className="p-1 hover:bg-slate-100 text-slate-500 disabled:opacity-30 rounded"
                        title="Move Down"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex items-center gap-2">
                      {/* Replace */}
                      <button
                        type="button"
                        onClick={() => {
                          setReplacingMedia(item);
                          replaceInputRef.current?.click();
                        }}
                        className="px-2 py-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded text-[11px] font-medium flex items-center gap-1"
                        title="Replace media preserving links"
                      >
                        <RefreshCw className="w-3 h-3 text-slate-400" />
                        <span>Replace</span>
                      </button>

                      {/* Delete */}
                      <button
                        type="button"
                        onClick={() => setItemToDelete(item)}
                        className="p-1 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded"
                        title="Delete media"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {itemToDelete && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-xl">
            <h3 className="text-base font-bold text-slate-900">Confirm Media Deletion</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Are you sure you want to permanently delete <span className="font-semibold">"{itemToDelete.filename}"</span>? This will safely remove the media and its thumbnail from storage.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setItemToDelete(null)}
                className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:text-slate-900"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-xl"
              >
                Delete Media
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Delete Confirmation Modal */}
      {showBulkDeleteConfirm && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-xl">
            <h3 className="text-base font-bold text-slate-900">Delete {selectedIds.length} Items?</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              This action cannot be undone. All {selectedIds.length} selected photos/videos will be deleted.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowBulkDeleteConfirm(false)}
                className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:text-slate-900"
              >
                Cancel
              </button>
              <button
                onClick={handleBulkDelete}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-xl"
              >
                Confirm Bulk Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* External Link Video Modal */}
      {showExternalModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Link className="w-4 h-4 text-sky-700" />
                Add External Video Link
              </h3>
              <button
                onClick={() => setShowExternalModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddExternalVideo} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Video URL (YouTube, Google Drive, or MP4)
                </label>
                <input
                  type="url"
                  value={externalUrl}
                  onChange={(e) => setExternalUrl(e.target.value)}
                  placeholder="https://youtube.com/watch?v=... or https://drive.google.com/..."
                  required
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-600"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Caption / Video Title
                </label>
                <input
                  type="text"
                  value={externalCaption}
                  onChange={(e) => setExternalCaption(e.target.value)}
                  placeholder="e.g. Clinic Overview & Patient Consultation Tour"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-sky-600"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowExternalModal(false)}
                  className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingExternal}
                  className="px-4 py-2 bg-sky-900 hover:bg-sky-800 text-white text-xs font-semibold rounded-xl disabled:opacity-60"
                >
                  {isSavingExternal ? 'Adding...' : 'Add Video to Library'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Video Preview Modal */}
      {previewVideoUrl && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-black rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl relative">
            <button
              onClick={() => setPreviewVideoUrl(null)}
              className="absolute top-3 right-3 z-10 w-8 h-8 bg-black/60 text-white rounded-full flex items-center justify-center hover:bg-black"
            >
              <X className="w-4 h-4" />
            </button>
            <video
              src={previewVideoUrl}
              controls
              autoPlay
              playsInline
              className="w-full max-h-[70vh]"
            />
          </div>
        </div>
      )}
    </div>
  );
}
