import React, { useState } from 'react';
import {
  LayoutDashboard,
  Calendar,
  Image as ImageIcon,
  Edit,
  Clock,
  Shield,
  Download,
  Activity,
  LogOut,
  ExternalLink,
  ChevronRight,
  Menu,
  X,
  Stethoscope,
  Globe,
  UserCheck,
  CheckCircle
} from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';
import { BookingsManager } from './BookingsManager';
import { MediaManager } from './MediaManager';
import { LiveEditor } from './LiveEditor';
import { BookingSettingsPanel } from './BookingSettingsPanel';
import { SecurityPanel } from './SecurityPanel';
import { BackupRestorePanel } from './BackupRestorePanel';
import { ActivityLogsPanel } from './ActivityLogsPanel';

interface AdminPanelProps {
  onBackToWebsite: () => void;
}

export function AdminPanel({ onBackToWebsite }: AdminPanelProps) {
  const { adminUser, logout, bookings, mediaList, content, draft } = useClinic();
  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'bookings' | 'media' | 'editor' | 'settings' | 'security' | 'backup' | 'logs'
  >('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'bookings', label: 'Appointments', icon: Calendar, badge: bookings.filter(b => b.status === 'pending').length },
    { id: 'media', label: 'Photos & Videos', icon: ImageIcon, count: mediaList.length },
    { id: 'editor', label: 'Live Website Editor', icon: Edit },
    { id: 'settings', label: 'Schedule Settings', icon: Clock },
    { id: 'security', label: 'Admin Security', icon: Shield },
    { id: 'backup', label: 'Backup & Restore', icon: Download },
    { id: 'logs', label: 'Activity Logs', icon: Activity }
  ];

  const todayStr = new Date().toISOString().split('T')[0];
  const todayCount = bookings.filter(b => b.preferredDate === todayStr).length;
  const pendingCount = bookings.filter(b => b.status === 'pending').length;

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      {/* Top Admin Header */}
      <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 text-slate-400 hover:text-white lg:hidden rounded-lg hover:bg-slate-800"
              aria-label="Toggle Navigation"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-sky-600 flex items-center justify-center font-bold text-white shadow-sm">
                <Stethoscope className="w-4 h-4" />
              </div>
              <div>
                <h1 className="text-sm font-bold text-white leading-tight">
                  Dr. Chouhan Clinic
                </h1>
                <span className="text-[10px] text-sky-400 font-semibold tracking-wider uppercase">
                  Owner Admin Portal
                </span>
              </div>
            </div>
          </div>

          {/* Right Header Actions */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBackToWebsite}
              className="text-xs text-slate-300 hover:text-white flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-slate-800 transition-colors"
            >
              <Globe className="w-3.5 h-3.5 text-sky-400" />
              <span className="hidden sm:inline">View Public Website</span>
            </button>
            <button
              type="button"
              onClick={logout}
              className="text-xs text-rose-300 hover:text-rose-100 flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-rose-950/60 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Layout Container */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col lg:flex-row gap-6">
        {/* Sidebar Navigation (Desktop) / Slide-over (Mobile) */}
        <aside
          className={`lg:w-64 shrink-0 ${
            isMobileMenuOpen
              ? 'fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm lg:relative lg:inset-auto'
              : 'hidden lg:block'
          }`}
        >
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-3 space-y-1 h-auto lg:sticky lg:top-24 max-h-[85vh] overflow-y-auto">
            {isMobileMenuOpen && (
              <div className="flex items-center justify-between p-2 pb-3 border-b lg:hidden">
                <span className="text-xs font-bold text-slate-800">Admin Navigation</span>
                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-1 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setActiveTab(item.id as any);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors text-left ${
                    isActive
                      ? 'bg-sky-900 text-white shadow-sm'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-sky-300' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && item.badge > 0 && (
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${
                        isActive ? 'bg-amber-400 text-slate-900' : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                  {item.count !== undefined && (
                    <span className={`text-[10px] ${isActive ? 'text-sky-200' : 'text-slate-400'}`}>
                      {item.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 min-w-0">
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              {/* Welcome Banner */}
              <div className="bg-gradient-to-r from-sky-900 via-sky-800 to-slate-900 text-white p-6 rounded-2xl shadow-sm relative overflow-hidden">
                <div className="relative z-10 space-y-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-sky-300">
                    Clinic Management Suite
                  </span>
                  <h2 className="text-xl sm:text-2xl font-bold">
                    Welcome back, {content?.doctorName || 'Dr. Chouhan'}
                  </h2>
                  <p className="text-xs text-sky-100 max-w-xl leading-relaxed">
                    All website sections, doctor qualifications, consultation bookings, and gallery photos/videos are synchronized live.
                  </p>
                </div>
              </div>

              {/* Quick Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <button
                  type="button"
                  onClick={() => setActiveTab('bookings')}
                  className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm text-left hover:border-sky-400 transition-colors"
                >
                  <span className="text-[11px] font-semibold text-slate-500 uppercase">Today's Visits</span>
                  <p className="text-2xl font-bold text-slate-900 mt-1">{todayCount}</p>
                  <span className="text-[10px] text-sky-700 font-medium flex items-center gap-0.5 mt-2">
                    View list <ChevronRight className="w-3 h-3" />
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('bookings')}
                  className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm text-left hover:border-amber-400 transition-colors"
                >
                  <span className="text-[11px] font-semibold text-amber-600 uppercase">Pending Review</span>
                  <p className="text-2xl font-bold text-amber-600 mt-1">{pendingCount}</p>
                  <span className="text-[10px] text-amber-700 font-medium flex items-center gap-0.5 mt-2">
                    Take action <ChevronRight className="w-3 h-3" />
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('media')}
                  className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm text-left hover:border-sky-400 transition-colors"
                >
                  <span className="text-[11px] font-semibold text-slate-500 uppercase">Gallery Items</span>
                  <p className="text-2xl font-bold text-slate-900 mt-1">{mediaList.length}</p>
                  <span className="text-[10px] text-sky-700 font-medium flex items-center gap-0.5 mt-2">
                    Upload & manage <ChevronRight className="w-3 h-3" />
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('editor')}
                  className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm text-left hover:border-emerald-400 transition-colors"
                >
                  <span className="text-[11px] font-semibold text-emerald-600 uppercase">Live Website</span>
                  <p className="text-sm font-bold text-emerald-700 mt-2 flex items-center gap-1">
                    <CheckCircle className="w-4 h-4" /> Published
                  </p>
                  <span className="text-[10px] text-emerald-700 font-medium flex items-center gap-0.5 mt-2">
                    Open Live Editor <ChevronRight className="w-3 h-3" />
                  </span>
                </button>
              </div>

              {/* Quick Actions Shortcuts */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Quick Administration Shortcuts
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <button
                    onClick={() => setActiveTab('editor')}
                    className="p-3 bg-slate-50 hover:bg-sky-50 border border-slate-200 hover:border-sky-300 rounded-xl text-left transition-colors flex items-center gap-3"
                  >
                    <Edit className="w-5 h-5 text-sky-700 shrink-0" />
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">Edit Website Content</h4>
                      <p className="text-[10px] text-slate-500">Edit doctor bio, services, notice</p>
                    </div>
                  </button>

                  <button
                    onClick={() => setActiveTab('media')}
                    className="p-3 bg-slate-50 hover:bg-sky-50 border border-slate-200 hover:border-sky-300 rounded-xl text-left transition-colors flex items-center gap-3"
                  >
                    <ImageIcon className="w-5 h-5 text-sky-700 shrink-0" />
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">Upload Clinic Photos</h4>
                      <p className="text-[10px] text-slate-500">Direct phone gallery upload</p>
                    </div>
                  </button>

                  <button
                    onClick={() => setActiveTab('settings')}
                    className="p-3 bg-slate-50 hover:bg-sky-50 border border-slate-200 hover:border-sky-300 rounded-xl text-left transition-colors flex items-center gap-3"
                  >
                    <Clock className="w-5 h-5 text-sky-700 shrink-0" />
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">Consultation Timings</h4>
                      <p className="text-[10px] text-slate-500">Adjust morning & evening slots</p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Recent Bookings Snapshot */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b pb-3">
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Recent Patient Appointments
                  </h3>
                  <button
                    onClick={() => setActiveTab('bookings')}
                    className="text-xs text-sky-700 hover:underline font-semibold"
                  >
                    View All ({bookings.length})
                  </button>
                </div>
                {bookings.slice(0, 5).map((b) => (
                  <div
                    key={b.id}
                    className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl flex items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">{b.patientName}</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded font-bold bg-white border border-slate-200">
                          {b.status.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {b.serviceName} · {b.preferredDate} at {b.timeSlot}
                      </p>
                    </div>
                    <span className="font-mono text-[11px] text-slate-500">{b.patientPhone}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'bookings' && <BookingsManager />}
          {activeTab === 'media' && <MediaManager />}
          {activeTab === 'editor' && <LiveEditor />}
          {activeTab === 'settings' && <BookingSettingsPanel />}
          {activeTab === 'security' && <SecurityPanel />}
          {activeTab === 'backup' && <BackupRestorePanel />}
          {activeTab === 'logs' && <ActivityLogsPanel />}
        </main>
      </div>
    </div>
  );
}
