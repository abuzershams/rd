import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  Phone,
  MessageCircle,
  Search,
  CheckCircle,
  XCircle,
  UserCheck,
  AlertCircle,
  Download,
  Plus,
  Trash2,
  Edit3,
  Filter
} from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';
import { Booking } from '../../types';
import * as api from '../../services/api';

export function BookingsManager() {
  const { bookings, refreshBookings, showToast } = useClinic();
  const [filter, setFilter] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [showManualModal, setShowManualModal] = useState(false);
  const [editNotesId, setEditNotesId] = useState<string | null>(null);
  const [noteText, setNoteText] = useState('');

  // Manual booking form state
  const [manualForm, setManualForm] = useState({
    patientName: '',
    patientPhone: '',
    patientEmail: '',
    serviceName: 'General Consultation',
    preferredDate: new Date().toISOString().split('T')[0],
    timeSlot: '10:00 AM - 10:30 AM',
    adminNotes: ''
  });

  const handleStatusChange = async (id: string, newStatus: Booking['status']) => {
    try {
      await api.updateBooking(id, { status: newStatus });
      showToast(`Appointment status updated to ${newStatus}.`, 'success');
      await refreshBookings(filter !== 'all' ? filter : undefined, search);
    } catch (err: any) {
      showToast(err.message || 'Failed to update booking status', 'error');
    }
  };

  const handleSaveNotes = async (id: string) => {
    try {
      await api.updateBooking(id, { adminNotes: noteText });
      showToast('Clinical notes updated.', 'success');
      setEditNotesId(null);
      await refreshBookings(filter !== 'all' ? filter : undefined, search);
    } catch (err: any) {
      showToast(err.message || 'Failed to save notes', 'error');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this booking record?')) return;
    try {
      await api.deleteBooking(id);
      showToast('Booking deleted.', 'info');
      await refreshBookings(filter !== 'all' ? filter : undefined, search);
    } catch (err: any) {
      showToast(err.message || 'Failed to delete booking', 'error');
    }
  };

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createManualBooking(manualForm);
      showToast('Walk-in booking created successfully!', 'success');
      setShowManualModal(false);
      setManualForm({
        patientName: '',
        patientPhone: '',
        patientEmail: '',
        serviceName: 'General Consultation',
        preferredDate: new Date().toISOString().split('T')[0],
        timeSlot: '10:00 AM - 10:30 AM',
        adminNotes: ''
      });
      await refreshBookings();
    } catch (err: any) {
      showToast(err.message || 'Failed to create manual booking', 'error');
    }
  };

  // Export CSV
  const handleExportCSV = () => {
    if (bookings.length === 0) {
      showToast('No bookings to export.', 'info');
      return;
    }
    const headers = ['Booking Number', 'Patient Name', 'Phone', 'Email', 'Service', 'Date', 'Time Slot', 'Status', 'Notes', 'Created At'];
    const rows = bookings.map(b => [
      b.bookingNumber,
      `"${b.patientName}"`,
      b.patientPhone,
      b.patientEmail || '',
      `"${b.serviceName}"`,
      b.preferredDate,
      `"${b.timeSlot}"`,
      b.status,
      `"${(b.adminNotes || '').replace(/"/g, '""')}"`,
      b.createdAt
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `clinic-bookings-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Bookings CSV exported successfully.', 'success');
  };

  // Quick stats
  const todayStr = new Date().toISOString().split('T')[0];
  const todayBookingsCount = bookings.filter(b => b.preferredDate === todayStr).length;
  const pendingCount = bookings.filter(b => b.status === 'pending').length;
  const confirmedCount = bookings.filter(b => b.status === 'confirmed').length;

  return (
    <div className="space-y-6">
      {/* Top Header & Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Today's Patients</span>
          <p className="text-2xl font-bold text-slate-900 mt-1">{todayBookingsCount}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-[11px] font-semibold text-amber-600 uppercase tracking-wider">Pending Action</span>
          <p className="text-2xl font-bold text-amber-600 mt-1">{pendingCount}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-[11px] font-semibold text-emerald-600 uppercase tracking-wider">Confirmed</span>
          <p className="text-2xl font-bold text-emerald-700 mt-1">{confirmedCount}</p>
        </div>
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Total Bookings</span>
          <p className="text-2xl font-bold text-slate-900 mt-1">{bookings.length}</p>
        </div>
      </div>

      {/* Controls Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              refreshBookings(filter !== 'all' ? filter : undefined, e.target.value);
            }}
            placeholder="Search patient name, phone, ID..."
            className="w-full pl-9 pr-3.5 py-2 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-sky-600 focus:outline-none"
          />
        </div>

        {/* Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setShowManualModal(true)}
            className="px-3.5 py-2 bg-sky-900 hover:bg-sky-800 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>New Walk-in / Phone</span>
          </button>
          <button
            type="button"
            onClick={handleExportCSV}
            className="px-3.5 py-2 border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-medium rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Filter Segmented Buttons */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl overflow-x-auto">
        {[
          { id: 'all', label: 'All Bookings' },
          { id: 'today', label: 'Today' },
          { id: 'tomorrow', label: 'Tomorrow' },
          { id: 'pending', label: 'Pending' },
          { id: 'confirmed', label: 'Confirmed' },
          { id: 'completed', label: 'Completed' },
          { id: 'cancelled', label: 'Cancelled' },
          { id: 'noshow', label: 'No-show' }
        ].map((btn) => (
          <button
            key={btn.id}
            onClick={() => {
              setFilter(btn.id);
              refreshBookings(btn.id !== 'all' ? btn.id : undefined, search);
            }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors ${
              filter === btn.id
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {btn.label}
          </button>
        ))}
      </div>

      {/* Bookings List */}
      {bookings.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center text-slate-400">
          <Calendar className="w-10 h-10 mx-auto text-slate-300 mb-2" />
          <p className="text-sm font-medium text-slate-700">No appointments found</p>
          <p className="text-xs text-slate-400 mt-1">Appointments booked online or manually will appear here.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {bookings.map((booking) => {
            const isToday = booking.preferredDate === todayStr;
            const statusColors = {
              pending: 'bg-amber-100 text-amber-800 border-amber-200',
              confirmed: 'bg-emerald-100 text-emerald-800 border-emerald-200',
              completed: 'bg-blue-100 text-blue-800 border-blue-200',
              cancelled: 'bg-slate-100 text-slate-600 border-slate-200',
              noshow: 'bg-rose-100 text-rose-800 border-rose-200'
            };

            return (
              <div
                key={booking.id}
                className={`bg-white border rounded-2xl p-4 shadow-sm transition-all ${
                  isToday ? 'border-sky-300 bg-sky-50/20' : 'border-slate-200'
                }`}
              >
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
                  {/* Left: Patient Details */}
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-slate-900">{booking.patientName}</h4>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${statusColors[booking.status]}`}>
                        {booking.status.toUpperCase()}
                      </span>
                      {booking.isWalkIn && (
                        <span className="text-[10px] bg-purple-100 text-purple-700 px-1.5 py-0.5 rounded font-semibold">
                          WALK-IN
                        </span>
                      )}
                    </div>
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500">
                      <span className="font-mono text-slate-700 font-semibold">{booking.bookingNumber}</span>
                      <span>·</span>
                      <span className="text-slate-800 font-medium">{booking.serviceName}</span>
                      <span>·</span>
                      <span className="flex items-center gap-1 font-medium text-slate-900">
                        <Calendar className="w-3.5 h-3.5 text-sky-700" />
                        {booking.preferredDate}
                      </span>
                      <span>·</span>
                      <span className="flex items-center gap-1 font-medium text-slate-900">
                        <Clock className="w-3.5 h-3.5 text-sky-700" />
                        {booking.timeSlot}
                      </span>
                    </div>
                    {booking.message && (
                      <p className="text-xs text-slate-600 bg-slate-50 p-2 rounded-lg border border-slate-100 mt-2">
                        <span className="font-semibold text-slate-700">Patient Note: </span>
                        {booking.message}
                      </p>
                    )}
                    {booking.adminNotes && editNotesId !== booking.id && (
                      <p className="text-xs text-sky-800 bg-sky-50 p-2 rounded-lg border border-sky-100 mt-1">
                        <span className="font-semibold">Clinic Note: </span>
                        {booking.adminNotes}
                      </p>
                    )}
                  </div>

                  {/* Right: Quick Action Buttons */}
                  <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
                    {/* Call Direct */}
                    <a
                      href={`tel:${booking.patientPhone}`}
                      className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-xl flex items-center gap-1"
                    >
                      <Phone className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Call</span>
                    </a>

                    {/* WhatsApp Direct */}
                    <a
                      href={`https://wa.me/91${booking.patientPhone}?text=${encodeURIComponent(
                        `Hello ${booking.patientName}, regarding your appointment (${booking.bookingNumber}) with Dr. R. K. Chouhan on ${booking.preferredDate} at ${booking.timeSlot}.`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold rounded-xl flex items-center gap-1 border border-emerald-200"
                    >
                      <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                      <span>WhatsApp</span>
                    </a>

                    {/* Status Triggers */}
                    {booking.status === 'pending' && (
                      <button
                        onClick={() => handleStatusChange(booking.id, 'confirmed')}
                        className="px-2.5 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold rounded-xl"
                      >
                        Confirm
                      </button>
                    )}

                    {booking.status === 'confirmed' && (
                      <button
                        onClick={() => handleStatusChange(booking.id, 'completed')}
                        className="px-2.5 py-1.5 bg-blue-700 hover:bg-blue-600 text-white text-xs font-semibold rounded-xl"
                      >
                        Complete
                      </button>
                    )}

                    {booking.status !== 'cancelled' && (
                      <button
                        onClick={() => handleStatusChange(booking.id, 'cancelled')}
                        className="px-2 py-1.5 text-rose-600 hover:bg-rose-50 text-xs font-medium rounded-xl"
                      >
                        Cancel
                      </button>
                    )}

                    {/* Notes Trigger */}
                    <button
                      onClick={() => {
                        setEditNotesId(booking.id);
                        setNoteText(booking.adminNotes || '');
                      }}
                      className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
                      title="Edit internal clinical note"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>

                    {/* Delete */}
                    <button
                      onClick={() => handleDelete(booking.id)}
                      className="p-1.5 text-slate-300 hover:text-rose-600 rounded-lg"
                      title="Delete record"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Inline Notes Editor */}
                {editNotesId === booking.id && (
                  <div className="mt-3 pt-3 border-t border-slate-100 flex gap-2">
                    <input
                      type="text"
                      value={noteText}
                      onChange={(e) => setNoteText(e.target.value)}
                      placeholder="Add internal clinic note or prescription remarks..."
                      className="flex-1 px-3 py-1.5 text-xs border border-slate-300 rounded-xl"
                    />
                    <button
                      onClick={() => handleSaveNotes(booking.id)}
                      className="px-3 py-1.5 bg-sky-900 text-white text-xs font-semibold rounded-xl"
                    >
                      Save Note
                    </button>
                    <button
                      onClick={() => setEditNotesId(null)}
                      className="px-2 py-1.5 text-xs text-slate-500 hover:text-slate-700"
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Manual / Walk-in Booking Modal */}
      {showManualModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-xl">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-sky-700" />
              New Walk-in / Phone Appointment
            </h3>
            <form onSubmit={handleManualSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Patient Name *</label>
                <input
                  type="text"
                  required
                  value={manualForm.patientName}
                  onChange={(e) => setManualForm({ ...manualForm, patientName: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">10-Digit Mobile Number *</label>
                <input
                  type="tel"
                  required
                  value={manualForm.patientPhone}
                  onChange={(e) => setManualForm({ ...manualForm, patientPhone: e.target.value })}
                  placeholder="e.g. 9829012345"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Date *</label>
                  <input
                    type="date"
                    required
                    value={manualForm.preferredDate}
                    onChange={(e) => setManualForm({ ...manualForm, preferredDate: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Time Slot *</label>
                  <input
                    type="text"
                    required
                    value={manualForm.timeSlot}
                    onChange={(e) => setManualForm({ ...manualForm, timeSlot: e.target.value })}
                    placeholder="e.g. 11:00 AM - 11:30 AM"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Consultation Category</label>
                <input
                  type="text"
                  value={manualForm.serviceName}
                  onChange={(e) => setManualForm({ ...manualForm, serviceName: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Internal Note (Optional)</label>
                <textarea
                  rows={2}
                  value={manualForm.adminNotes}
                  onChange={(e) => setManualForm({ ...manualForm, adminNotes: e.target.value })}
                  placeholder="Symptoms or receptionist notes..."
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowManualModal(false)}
                  className="px-3.5 py-2 text-xs text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-sky-900 hover:bg-sky-800 text-white text-xs font-bold rounded-xl"
                >
                  Confirm Booking
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
