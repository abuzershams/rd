import React, { useState } from 'react';
import { Clock, Calendar, Check, Save } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';
import * as api from '../../services/api';

export function BookingSettingsPanel() {
  const { settings, refreshSettings, showToast } = useClinic();
  const [formData, setFormData] = useState(
    settings || {
      slotDurationMinutes: 30,
      morningStart: '09:30',
      morningEnd: '13:30',
      eveningStart: '17:00',
      eveningEnd: '21:00',
      workingDays: [1, 2, 3, 4, 5, 6, 0],
      holidays: [],
      maxAdvanceBookingDays: 30,
      autoConfirm: false,
      consultationFee: 600,
      whatsappAlertsEnabled: true
    }
  );
  const [holidayInput, setHolidayInput] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  const toggleDay = (dayIndex: number) => {
    const current = formData.workingDays || [];
    const exists = current.includes(dayIndex);
    const updated = exists ? current.filter((d) => d !== dayIndex) : [...current, dayIndex];
    setFormData({ ...formData, workingDays: updated });
  };

  const handleAddHoliday = () => {
    if (!holidayInput) return;
    const current = formData.holidays || [];
    if (current.includes(holidayInput)) {
      showToast('Date already in holiday list', 'info');
      return;
    }
    setFormData({ ...formData, holidays: [...current, holidayInput] });
    setHolidayInput('');
  };

  const handleRemoveHoliday = (dateStr: string) => {
    setFormData({ ...formData, holidays: (formData.holidays || []).filter((h) => h !== dateStr) });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setIsSaving(true);
      await api.saveBookingSettings(formData);
      await refreshSettings();
      showToast('Appointment schedule settings saved successfully.', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to save booking settings', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <form onSubmit={handleSave} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
      <div className="flex items-center justify-between border-b pb-3">
        <div>
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Clock className="w-5 h-5 text-sky-700" />
            Clinic Consultation Timings & Slot Rules
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure consultation shifts, duration per patient, active days and holiday calendar.
          </p>
        </div>
        <button
          type="submit"
          disabled={isSaving}
          className="px-4 py-2 bg-sky-900 hover:bg-sky-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm transition-colors"
        >
          <Save className="w-4 h-4" />
          <span>{isSaving ? 'Saving...' : 'Save Settings'}</span>
        </button>
      </div>

      {/* Shifts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Morning Shift */}
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
          <span className="text-xs font-bold text-slate-800">Morning Shift</span>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">Start Time</label>
              <input
                type="time"
                value={formData.morningStart}
                onChange={(e) => setFormData({ ...formData, morningStart: e.target.value })}
                className="w-full px-3 py-2 bg-white text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">End Time</label>
              <input
                type="time"
                value={formData.morningEnd}
                onChange={(e) => setFormData({ ...formData, morningEnd: e.target.value })}
                className="w-full px-3 py-2 bg-white text-xs border border-slate-300 rounded-lg"
              />
            </div>
          </div>
        </div>

        {/* Evening Shift */}
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
          <span className="text-xs font-bold text-slate-800">Evening Shift</span>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">Start Time</label>
              <input
                type="time"
                value={formData.eveningStart}
                onChange={(e) => setFormData({ ...formData, eveningStart: e.target.value })}
                className="w-full px-3 py-2 bg-white text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">End Time</label>
              <input
                type="time"
                value={formData.eveningEnd}
                onChange={(e) => setFormData({ ...formData, eveningEnd: e.target.value })}
                className="w-full px-3 py-2 bg-white text-xs border border-slate-300 rounded-lg"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Slot duration & fees */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Slot Duration (Minutes)</label>
          <select
            value={formData.slotDurationMinutes}
            onChange={(e) => setFormData({ ...formData, slotDurationMinutes: Number(e.target.value) })}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white"
          >
            <option value={15}>15 Minutes</option>
            <option value={20}>20 Minutes</option>
            <option value={25}>25 Minutes</option>
            <option value={30}>30 Minutes (Recommended)</option>
            <option value={45}>45 Minutes</option>
            <option value={60}>60 Minutes</option>
          </select>
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Standard Consultation Fee (₹)</label>
          <input
            type="number"
            value={formData.consultationFee}
            onChange={(e) => setFormData({ ...formData, consultationFee: Number(e.target.value) })}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Max Advance Days to Book</label>
          <input
            type="number"
            value={formData.maxAdvanceBookingDays}
            onChange={(e) => setFormData({ ...formData, maxAdvanceBookingDays: Number(e.target.value) })}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
          />
        </div>
      </div>

      {/* Working Days */}
      <div>
        <label className="block text-xs font-semibold text-slate-700 mb-2">Clinic Working Days</label>
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2">
          {dayNames.map((name, idx) => {
            const active = (formData.workingDays || []).includes(idx);
            return (
              <button
                key={name}
                type="button"
                onClick={() => toggleDay(idx)}
                className={`p-2.5 rounded-xl border text-center text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 ${
                  active
                    ? 'bg-sky-50 border-sky-400 text-sky-900'
                    : 'bg-slate-50 border-slate-200 text-slate-400'
                }`}
              >
                {active && <Check className="w-3.5 h-3.5 text-sky-600" />}
                <span>{name.slice(0, 3)}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Closed Holidays */}
      <div>
        <label className="block text-xs font-semibold text-slate-700 mb-2">Holidays & Closed Clinic Dates</label>
        <div className="flex gap-2 max-w-sm mb-3">
          <input
            type="date"
            value={holidayInput}
            onChange={(e) => setHolidayInput(e.target.value)}
            className="px-3 py-1.5 text-xs border border-slate-300 rounded-xl"
          />
          <button
            type="button"
            onClick={handleAddHoliday}
            className="px-3 py-1.5 bg-slate-800 text-white text-xs font-medium rounded-xl hover:bg-slate-900"
          >
            Add Holiday
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {(formData.holidays || []).length === 0 ? (
            <span className="text-xs text-slate-400 italic">No special holidays configured.</span>
          ) : (
            (formData.holidays || []).map((h) => (
              <span
                key={h}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium rounded-lg"
              >
                <span>{h}</span>
                <button
                  type="button"
                  onClick={() => handleRemoveHoliday(h)}
                  className="hover:text-rose-900 text-rose-500 font-bold"
                >
                  ✕
                </button>
              </span>
            ))
          )}
        </div>
      </div>
    </form>
  );
}
