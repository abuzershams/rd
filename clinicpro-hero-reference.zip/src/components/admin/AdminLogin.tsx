import React, { useState } from 'react';
import { Eye, EyeOff, Lock, User, ArrowLeft, ShieldCheck, AlertCircle } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';
import * as api from '../../services/api';

interface AdminLoginProps {
  onBackToWebsite: () => void;
  onSuccess: () => void;
}

export function AdminLogin({ onBackToWebsite, onSuccess }: AdminLoginProps) {
  const { login } = useClinic();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotUsername, setForgotUsername] = useState('');
  const [forgotMessage, setForgotMessage] = useState<string | null>(null);
  const [isForgotLoading, setIsForgotLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) {
      setError('Invalid username or password');
      return;
    }

    try {
      setIsLoading(true);
      setError(null);
      await login(username.trim(), password);
      onSuccess();
    } catch (err: any) {
      const msg = err.message || '';
      if (msg.includes('locked')) {
        setError(msg);
      } else {
        setError('Invalid username or password');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotUsername.trim()) {
      setForgotMessage('Please enter your administrator username.');
      return;
    }

    try {
      setIsForgotLoading(true);
      const res = await api.adminForgotPassword(forgotUsername.trim());
      setForgotMessage(res.message);
    } catch (err: any) {
      setForgotMessage('If the username is valid, instructions have been sent to the verified administrator contact.');
    } finally {
      setIsForgotLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md px-4">
        {/* Header Icon & Title */}
        <div className="text-center mb-6">
          <div className="mx-auto w-12 h-12 bg-sky-900 text-white rounded-xl flex items-center justify-center shadow-md">
            <ShieldCheck className="w-6 h-6 text-sky-400" />
          </div>
          <h2 className="mt-4 text-2xl font-bold tracking-tight text-slate-900">
            Clinic Administrator Portal
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            Secure Authorized Access Only · Dr. Chouhan Clinic
          </p>
        </div>

        {/* Login Card */}
        <div className="bg-white py-8 px-6 shadow-sm border border-slate-200 rounded-2xl sm:px-10">
          {!showForgotPassword ? (
            <form onSubmit={handleSubmit} className="space-y-5">
              {error && (
                <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3 text-rose-800 text-sm">
                  <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                  <span className="font-medium leading-snug">{error}</span>
                </div>
              )}

              {/* Username field */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
                  Username
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Enter owner username"
                    autoComplete="username"
                    required
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-600 focus:border-transparent transition-all"
                  />
                </div>
              </div>

              {/* Password field with show/hide */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter password"
                    autoComplete="current-password"
                    required
                    className="w-full pl-10 pr-11 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-600 focus:border-transparent transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Login Button */}
              <div>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2.5 px-4 bg-sky-900 hover:bg-sky-800 active:bg-sky-950 text-white font-medium rounded-xl text-sm shadow transition-colors flex items-center justify-center disabled:opacity-60"
                >
                  {isLoading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    'Login to Admin Panel'
                  )}
                </button>
              </div>

              {/* Forgot password link */}
              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setError(null);
                    setShowForgotPassword(true);
                  }}
                  className="text-xs text-sky-700 hover:text-sky-900 font-medium hover:underline"
                >
                  Forgot password?
                </button>
              </div>
            </form>
          ) : (
            /* Forgot Password Form */
            <form onSubmit={handleForgotPassword} className="space-y-4">
              <h3 className="text-base font-semibold text-slate-900">
                Password Recovery
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Enter your authorized username to verify identity and receive secure recovery access.
              </p>

              {forgotMessage && (
                <div className="p-3 bg-sky-50 border border-sky-200 rounded-xl text-sky-900 text-xs leading-relaxed">
                  {forgotMessage}
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-700 mb-1">
                  Username
                </label>
                <input
                  type="text"
                  value={forgotUsername}
                  onChange={(e) => setForgotUsername(e.target.value)}
                  placeholder="e.g. drchouhan"
                  required
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-600"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowForgotPassword(false);
                    setForgotMessage(null);
                  }}
                  className="w-1/2 py-2 px-3 border border-slate-300 text-slate-700 text-xs font-medium rounded-xl hover:bg-slate-50"
                >
                  Back to Login
                </button>
                <button
                  type="submit"
                  disabled={isForgotLoading}
                  className="w-1/2 py-2 px-3 bg-sky-900 text-white text-xs font-medium rounded-xl hover:bg-sky-800 disabled:opacity-60"
                >
                  {isForgotLoading ? 'Verifying...' : 'Send Recovery'}
                </button>
              </div>
            </form>
          )}

          {/* Back to website link */}
          <div className="mt-6 pt-5 border-t border-slate-100 text-center">
            <button
              type="button"
              onClick={onBackToWebsite}
              className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 font-medium transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Clinic Website</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
