import React, { useState, useRef } from 'react';
import {
  Save,
  Globe,
  RotateCcw,
  Eye,
  CheckCircle,
  AlertCircle,
  Smartphone,
  Tablet,
  Monitor,
  Plus,
  Trash2,
  ChevronDown,
  ChevronUp,
  Image as ImageIcon,
  Upload
} from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';
import { ServiceItem, TestimonialItem, FaqItem } from '../../types';
import { processImage, uploadToFirebaseStorage, formatBytes, generateVideoPoster } from '../../utils/mediaProcessor';

export function LiveEditor() {
  const {
    draft,
    isSavingDraft,
    hasUnsavedDraft,
    updateDraft,
    saveDraft,
    publishDraft,
    revertDraft,
    mediaList,
    showToast
  } = useClinic();

  const [activeTab, setActiveTab] = useState<
    'general' | 'doctor' | 'hero' | 'services' | 'about' | 'testimonials' | 'faqs' | 'schedule' | 'contact' | 'theme'
  >('general');

  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [showConfirmPublish, setShowConfirmPublish] = useState(false);
  const [showMediaPickerField, setShowMediaPickerField] = useState<string | null>(null);
  const [uploadingField, setUploadingField] = useState<string | null>(null);

  if (!draft) {
    return (
      <div className="p-8 text-center text-slate-500">
        Loading editor configuration...
      </div>
    );
  }

  // Parse JSON collections safely
  let services: ServiceItem[] = [];
  try {
    services = JSON.parse(draft.servicesJson || '[]');
  } catch {
    services = [];
  }

  let testimonials: TestimonialItem[] = [];
  try {
    testimonials = JSON.parse(draft.testimonialsJson || '[]');
  } catch {
    testimonials = [];
  }

  let faqs: FaqItem[] = [];
  try {
    faqs = JSON.parse(draft.faqsJson || '[]');
  } catch {
    faqs = [];
  }

  let sectionVisibility: Record<string, boolean> = {};
  try {
    sectionVisibility = JSON.parse(draft.sectionVisibilityJson || '{}');
  } catch {
    sectionVisibility = {};
  }

  // Helpers to update array collections
  const updateServices = (newServices: ServiceItem[]) => {
    updateDraft({ servicesJson: JSON.stringify(newServices) });
  };

  const updateTestimonials = (newTestimonials: TestimonialItem[]) => {
    updateDraft({ testimonialsJson: JSON.stringify(newTestimonials) });
  };

  const updateFaqs = (newFaqs: FaqItem[]) => {
    updateDraft({ faqsJson: JSON.stringify(newFaqs) });
  };

  const toggleSection = (key: string) => {
    const updated = { ...sectionVisibility, [key]: !sectionVisibility[key] };
    updateDraft({ sectionVisibilityJson: JSON.stringify(updated) });
  };

  // Shared single image processing handler (Requirement 1)
  const handleDirectImageUpload = async (file: File, fieldName: string) => {
    try {
      setUploadingField(fieldName);
      showToast(`Processing and uploading image for ${fieldName}...`, 'info');
      const imageResult = await processImage(file);
      if (imageResult.warning) {
        showToast(imageResult.warning, 'info', imageResult.details);
      }

      const timestamp = Date.now();
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
      const storagePath = `media/branding/${timestamp}_${safeName}`;
      const upload = uploadToFirebaseStorage(
        storagePath,
        imageResult.fullBlob,
        undefined,
        { contentType: imageResult.contentType }
      );
      const downloadUrl = await upload.promise;
      updateDraft({ [fieldName]: downloadUrl });
      showToast('Image uploaded successfully!', 'success');
    } catch (err: any) {
      const errorName = err?.name || 'ImageUploadError';
      const errorMessage = err?.message || 'Failed to upload image';
      const details = `${file.name} (${file.type || 'unknown'}, ${formatBytes(file.size)}): ${errorName} - ${errorMessage}`;
      console.error(`[LiveEditor] Image upload error for ${fieldName}:`, {
        fileName: file.name,
        type: file.type,
        size: file.size,
        errorName,
        errorMessage,
        error: err
      });
      showToast(errorMessage, 'error', details);
    } finally {
      setUploadingField(null);
    }
  };

  // Hero background upload (image or video)
  const handleBgUpload = async (file: File) => {
    const isVideo = file.type.startsWith('video/');
    if (isVideo && file.size > 60 * 1024 * 1024) {
      showToast('Background video 60 MB se chhota rakho (best: 5-15 MB, 10-20 sec).', 'error');
      return;
    }
    try {
      setUploadingField('heroBgUrl');
      const ts = Date.now();
      const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
      if (isVideo) {
        showToast('Video upload ho raha hai, thoda wait karo...', 'info');
        const up = uploadToFirebaseStorage(`media/branding/herobg_${ts}_${safe}`, file, undefined, {
          contentType: file.type || 'video/mp4'
        });
        const url = await up.promise;
        let posterUrl = '';
        try {
          const poster = await generateVideoPoster(file);
          if (poster) {
            posterUrl = await uploadToFirebaseStorage(`media/branding/herobg_poster_${ts}.jpg`, poster, undefined, {
              contentType: 'image/jpeg'
            }).promise;
          }
        } catch {
          // poster is optional
        }
        updateDraft({ heroBgType: 'video', heroBgUrl: url, heroBgPosterUrl: posterUrl });
      } else {
        showToast('Image upload ho rahi hai...', 'info');
        const img = await processImage(file);
        const url = await uploadToFirebaseStorage(`media/branding/herobg_${ts}_${safe}`, img.fullBlob, undefined, {
          contentType: img.contentType
        }).promise;
        updateDraft({ heroBgType: 'image', heroBgUrl: url, heroBgPosterUrl: '' });
      }
      showToast('Background set ho gaya! Save Draft / Publish karna mat bhoolna.', 'success');
    } catch (err: any) {
      showToast(err?.message || 'Background upload failed', 'error');
    } finally {
      setUploadingField(null);
    }
  };

  const bgType = draft.heroBgType || 'none';
  const bgOverlay = parseInt(draft.heroBgOverlay ?? '60', 10) || 0;
  const bgBlur = parseInt(draft.heroBgBlur ?? '0', 10) || 0;
  const bgTintRgb = draft.heroBgTint === 'brand' ? '8,47,73' : '2,6,23';

  return (
    <div className="space-y-6">
      {/* Draft & Publish Action Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4 sticky top-16 z-30">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs font-semibold">
            {isSavingDraft ? (
              <span className="text-amber-600 flex items-center gap-1">
                <div className="w-3.5 h-3.5 border-2 border-amber-600 border-t-transparent rounded-full animate-spin" />
                Saving Draft...
              </span>
            ) : hasUnsavedDraft ? (
              <span className="text-amber-700 flex items-center gap-1 bg-amber-50 px-2.5 py-1 rounded-md border border-amber-200">
                <AlertCircle className="w-3.5 h-3.5" />
                Unsaved Draft Changes
              </span>
            ) : (
              <span className="text-emerald-700 flex items-center gap-1 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                <CheckCircle className="w-3.5 h-3.5" />
                All Changes Saved
              </span>
            )}
          </div>
          {draft.lastPublishedAt && (
            <span className="text-[11px] text-slate-400 hidden sm:inline">
              Last published: {new Date(draft.lastPublishedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <button
            type="button"
            onClick={saveDraft}
            disabled={isSavingDraft || !hasUnsavedDraft}
            className="px-3.5 py-2 border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors disabled:opacity-40"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Draft</span>
          </button>

          <button
            type="button"
            onClick={revertDraft}
            className="px-3 py-2 border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-medium rounded-xl flex items-center gap-1.5"
            title="Revert draft to currently published version"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Revert to Live</span>
          </button>

          <button
            type="button"
            onClick={() => setShowConfirmPublish(true)}
            disabled={isSavingDraft}
            className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 active:bg-emerald-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm transition-colors"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Publish to Live Site</span>
          </button>
        </div>
      </div>

      {/* Editor Sub-Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl overflow-x-auto">
        {[
          { id: 'general', label: 'Clinic & Header' },
          { id: 'doctor', label: 'Doctor Profile' },
          { id: 'hero', label: 'Hero Banner' },
          { id: 'services', label: `Services (${services.length})` },
          { id: 'about', label: 'About & Highlights' },
          { id: 'testimonials', label: `Reviews (${testimonials.length})` },
          { id: 'faqs', label: `FAQs (${faqs.length})` },
          { id: 'schedule', label: 'Schedule & Notice' },
          { id: 'contact', label: 'Contact & Map' },
          { id: 'theme', label: 'Visibility & Theme' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors ${
              activeTab === tab.id
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Form Content */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
        {/* 1. General Clinic Information */}
        {activeTab === 'general' && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b pb-2">Clinic Information & Branding</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Clinic Name</label>
                <input
                  type="text"
                  value={draft.clinicName}
                  onChange={(e) => updateDraft({ clinicName: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Clinic Tagline</label>
                <input
                  type="text"
                  value={draft.tagline}
                  onChange={(e) => updateDraft({ tagline: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Primary Phone</label>
                <input
                  type="text"
                  value={draft.phone}
                  onChange={(e) => updateDraft({ phone: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">WhatsApp Number</label>
                <input
                  type="text"
                  value={draft.whatsapp}
                  onChange={(e) => updateDraft({ whatsapp: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Contact Email</label>
                <input
                  type="email"
                  value={draft.email}
                  onChange={(e) => updateDraft({ email: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Emergency Call Line</label>
                <input
                  type="text"
                  value={draft.emergencyPhone}
                  onChange={(e) => updateDraft({ emergencyPhone: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div className="md:col-span-2">
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-700">Clinic Logo URL</label>
                  <div className="flex items-center gap-3">
                    <label className="text-xs text-sky-700 hover:underline flex items-center gap-1 cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      <span>{uploadingField === 'clinicLogoUrl' ? 'Uploading...' : 'Upload Logo'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        disabled={uploadingField === 'clinicLogoUrl'}
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) handleDirectImageUpload(f, 'clinicLogoUrl');
                        }}
                      />
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowMediaPickerField('clinicLogoUrl')}
                      className="text-xs text-slate-500 hover:text-slate-700 flex items-center gap-1"
                    >
                      <ImageIcon className="w-3 h-3" /> Media Library
                    </button>
                  </div>
                </div>
                <input
                  type="text"
                  value={draft.clinicLogoUrl || ''}
                  onChange={(e) => updateDraft({ clinicLogoUrl: e.target.value })}
                  placeholder="https://... clinic logo image URL"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl font-mono text-[11px]"
                />
              </div>
            </div>
          </div>
        )}

        {/* 2. Doctor Profile */}
        {activeTab === 'doctor' && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b pb-2">Doctor Profile & Medical Credentials</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Doctor Name</label>
                <input
                  type="text"
                  value={draft.doctorName}
                  onChange={(e) => updateDraft({ doctorName: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl font-medium"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Medical Council Reg. Number</label>
                <input
                  type="text"
                  value={draft.doctorRegistrationNumber}
                  onChange={(e) => updateDraft({ doctorRegistrationNumber: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Degrees & Qualifications</label>
                <input
                  type="text"
                  value={draft.doctorQualifications}
                  onChange={(e) => updateDraft({ doctorQualifications: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Years of Experience</label>
                <input
                  type="number"
                  value={draft.doctorExperienceYears}
                  onChange={(e) => updateDraft({ doctorExperienceYears: Number(e.target.value) })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">Specialty & Clinical Focus</label>
                <input
                  type="text"
                  value={draft.doctorSpecialty}
                  onChange={(e) => updateDraft({ doctorSpecialty: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div className="md:col-span-2">
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-700">Doctor Profile Photo / Avatar URL</label>
                  <div className="flex items-center gap-3">
                    <label className="text-xs text-sky-700 hover:underline flex items-center gap-1 cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      <span>{uploadingField === 'doctorPhotoUrl' ? 'Uploading...' : 'Upload Avatar'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        disabled={uploadingField === 'doctorPhotoUrl'}
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) handleDirectImageUpload(f, 'doctorPhotoUrl');
                        }}
                      />
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowMediaPickerField('doctorPhotoUrl')}
                      className="text-xs text-slate-500 hover:text-slate-700 flex items-center gap-1"
                    >
                      <ImageIcon className="w-3 h-3" /> Media Library
                    </button>
                  </div>
                </div>
                <input
                  type="text"
                  value={draft.doctorPhotoUrl || ''}
                  onChange={(e) => updateDraft({ doctorPhotoUrl: e.target.value })}
                  placeholder="https://... doctor photo URL"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl font-mono text-[11px]"
                />
              </div>
            </div>
          </div>
        )}

        {/* 3. Hero Section */}
        {activeTab === 'hero' && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b pb-2">Homepage Hero Banner</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Hero Highlight Badge</label>
                <input
                  type="text"
                  value={draft.heroBadge}
                  onChange={(e) => updateDraft({ heroBadge: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Main Heading</label>
                <textarea
                  rows={2}
                  value={draft.heroHeading}
                  onChange={(e) => updateDraft({ heroHeading: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Subtitle</label>
                <textarea
                  rows={3}
                  value={draft.heroSubtitle}
                  onChange={(e) => updateDraft({ heroSubtitle: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
                />
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-700">Doctor Photo (side card)</label>
                  <div className="flex items-center gap-3">
                    <label className="text-xs text-sky-700 hover:underline flex items-center gap-1 cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      <span>{uploadingField === 'heroImageUrl' ? 'Uploading...' : 'Upload Hero'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        disabled={uploadingField === 'heroImageUrl'}
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) handleDirectImageUpload(f, 'heroImageUrl');
                        }}
                      />
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowMediaPickerField('heroImageUrl')}
                      className="text-xs text-slate-500 hover:text-slate-700 flex items-center gap-1"
                    >
                      <ImageIcon className="w-3 h-3" /> Media Library
                    </button>
                  </div>
                </div>
                <input
                  type="text"
                  value={draft.heroImageUrl}
                  onChange={(e) => updateDraft({ heroImageUrl: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl font-mono text-[11px]"
                />
              </div>
              {/* ---------- Hero Background (image / video) ---------- */}
              <div className="border border-slate-200 rounded-2xl p-3 space-y-3 bg-slate-50/60">
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Hero Background (Premium look)</h4>
                  <p className="text-[11px] text-slate-500">Text ke piche photo ya video lagao, aur darkness/blur khud control karo.</p>
                </div>

                <div className="grid grid-cols-3 gap-1.5">
                  {([
                    ['none', 'Off'],
                    ['image', 'Photo'],
                    ['video', 'Video']
                  ] as const).map(([val, label]) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => updateDraft({ heroBgType: val })}
                      className={`py-2 text-xs font-semibold rounded-xl border ${
                        bgType === val ? 'bg-sky-900 text-white border-sky-900' : 'bg-white text-slate-700 border-slate-300'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>

                {bgType !== 'none' && (
                  <>
                    <div className="flex items-center gap-3 flex-wrap">
                      <label className="text-xs text-sky-700 hover:underline flex items-center gap-1 cursor-pointer">
                        <Upload className="w-3.5 h-3.5" />
                        <span>{uploadingField === 'heroBgUrl' ? 'Uploading...' : bgType === 'video' ? 'Upload Video' : 'Upload Photo'}</span>
                        <input
                          type="file"
                          accept={bgType === 'video' ? 'video/*' : 'image/*'}
                          className="hidden"
                          disabled={uploadingField === 'heroBgUrl'}
                          onChange={(e) => {
                            const f = e.target.files?.[0];
                            if (f) handleBgUpload(f);
                            e.target.value = '';
                          }}
                        />
                      </label>
                      <button
                        type="button"
                        onClick={() => setShowMediaPickerField('heroBgUrl')}
                        className="text-xs text-slate-500 hover:text-slate-700 flex items-center gap-1"
                      >
                        <ImageIcon className="w-3 h-3" /> Media Library
                      </button>
                    </div>
                    <input
                      type="text"
                      value={draft.heroBgUrl || ''}
                      onChange={(e) => updateDraft({ heroBgUrl: e.target.value })}
                      placeholder={bgType === 'video' ? 'MP4 video link' : 'Image link'}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl font-mono text-[11px]"
                    />

                    <div>
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-semibold text-slate-700">Overlay darkness (text ke liye)</label>
                        <span className="text-xs font-bold text-sky-800">{bgOverlay}%</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={95}
                        step={5}
                        value={bgOverlay}
                        onChange={(e) => updateDraft({ heroBgOverlay: e.target.value })}
                        className="w-full accent-sky-800"
                      />
                      <p className="text-[11px] text-slate-400">0% = photo/video bilkul clear, 95% = bahut dark. Best: 45-65%.</p>
                    </div>

                    <div>
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-semibold text-slate-700">Background blur</label>
                        <span className="text-xs font-bold text-sky-800">{bgBlur}px</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={12}
                        step={1}
                        value={bgBlur}
                        onChange={(e) => updateDraft({ heroBgBlur: e.target.value })}
                        className="w-full accent-sky-800"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-1.5">
                      {([
                        ['dark', 'Dark (black)'],
                        ['brand', 'Brand (blue)']
                      ] as const).map(([val, label]) => (
                        <button
                          key={val}
                          type="button"
                          onClick={() => updateDraft({ heroBgTint: val })}
                          className={`py-2 text-xs font-semibold rounded-xl border ${
                            (draft.heroBgTint || 'dark') === val ? 'bg-sky-900 text-white border-sky-900' : 'bg-white text-slate-700 border-slate-300'
                          }`}
                        >
                          {label}
                        </button>
                      ))}
                    </div>

                    {/* Mini live preview */}
                    {draft.heroBgUrl && (
                      <div className="relative h-40 rounded-2xl overflow-hidden bg-slate-900">
                        {bgType === 'video' ? (
                          <video
                            key={draft.heroBgUrl}
                            src={draft.heroBgUrl}
                            poster={draft.heroBgPosterUrl || undefined}
                            autoPlay
                            muted
                            loop
                            playsInline
                            className="absolute inset-0 w-full h-full object-cover"
                            style={bgBlur ? { filter: `blur(${bgBlur}px)`, transform: 'scale(1.08)' } : undefined}
                          />
                        ) : (
                          <img
                            src={draft.heroBgUrl}
                            alt=""
                            className="absolute inset-0 w-full h-full object-cover"
                            style={bgBlur ? { filter: `blur(${bgBlur}px)`, transform: 'scale(1.08)' } : undefined}
                          />
                        )}
                        <div className="absolute inset-0" style={{ backgroundColor: `rgba(${bgTintRgb},${bgOverlay / 100})` }} />
                        <div className="relative h-full flex flex-col justify-center px-4 text-white">
                          <div className="text-[10px] font-semibold text-white/80">Live preview</div>
                          <div className="text-sm font-black leading-tight line-clamp-2">{draft.heroHeading}</div>
                        </div>
                      </div>
                    )}
                    <p className="text-[11px] text-slate-400">
                      Video tips: chhota (10-20 sec, 5-15 MB), bina awaaz ke chalega. Badi video phone par slow ho sakti hai.
                    </p>
                  </>
                )}
              </div>
            </div>
          </div>
        )}

        {/* 4. Services List */}
        {activeTab === 'services' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="text-sm font-bold text-slate-900">Clinic Consultation Services</h3>
              <button
                type="button"
                onClick={() => {
                  const newService: ServiceItem = {
                    id: `srv-${Date.now()}`,
                    title: 'New Clinical Consultation',
                    description: 'Specialist clinical diagnosis, medical evaluation, and treatment prescription.',
                    duration: '25 mins',
                    price: '₹600',
                    category: 'General',
                    iconName: 'Stethoscope',
                    imageUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=800&q=80'
                  };
                  updateServices([...services, newService]);
                }}
                className="px-3 py-1.5 bg-sky-900 text-white rounded-xl text-xs font-semibold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Add Service
              </button>
            </div>

            <div className="space-y-3">
              {services.map((srv, idx) => (
                <div key={srv.id} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800">Service #{idx + 1}</span>
                    <button
                      type="button"
                      onClick={() => updateServices(services.filter((_, i) => i !== idx))}
                      className="text-rose-500 hover:text-rose-700 p-1"
                      title="Remove service"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-1">Title</label>
                      <input
                        type="text"
                        value={srv.title}
                        onChange={(e) => {
                          const updated = [...services];
                          updated[idx].title = e.target.value;
                          updateServices(updated);
                        }}
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-1">Price</label>
                      <input
                        type="text"
                        value={srv.price}
                        onChange={(e) => {
                          const updated = [...services];
                          updated[idx].price = e.target.value;
                          updateServices(updated);
                        }}
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-1">Duration</label>
                      <input
                        type="text"
                        value={srv.duration}
                        onChange={(e) => {
                          const updated = [...services];
                          updated[idx].duration = e.target.value;
                          updateServices(updated);
                        }}
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 mb-1">Description</label>
                    <textarea
                      rows={2}
                      value={srv.description}
                      onChange={(e) => {
                        const updated = [...services];
                        updated[idx].description = e.target.value;
                        updateServices(updated);
                      }}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 5. About Section */}
        {activeTab === 'about' && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b pb-2">About Section & Clinical Bio</h3>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Section Heading</label>
              <input
                type="text"
                value={draft.aboutHeading}
                onChange={(e) => updateDraft({ aboutHeading: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Doctor Biography & Philosophy</label>
              <textarea
                rows={6}
                value={draft.aboutBio}
                onChange={(e) => updateDraft({ aboutBio: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl leading-relaxed"
              />
            </div>
          </div>
        )}

        {/* 6. Testimonials */}
        {activeTab === 'testimonials' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="text-sm font-bold text-slate-900">Patient Testimonials & Reviews</h3>
              <button
                type="button"
                onClick={() => {
                  const newT: TestimonialItem = {
                    id: `test-${Date.now()}`,
                    name: 'Patient Name',
                    city: 'Jaipur',
                    comment: 'Doctor Chouhan provided prompt and accurate treatment. Highly satisfied.',
                    rating: 5,
                    date: 'Recent Visit',
                    condition: 'General Consultation'
                  };
                  updateTestimonials([...testimonials, newT]);
                }}
                className="px-3 py-1.5 bg-sky-900 text-white rounded-xl text-xs font-semibold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Add Testimonial
              </button>
            </div>

            <div className="space-y-3">
              {testimonials.map((test, idx) => (
                <div key={test.id} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800">Review #{idx + 1}</span>
                    <button
                      type="button"
                      onClick={() => updateTestimonials(testimonials.filter((_, i) => i !== idx))}
                      className="text-rose-500 hover:text-rose-700 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-1">Patient Name</label>
                      <input
                        type="text"
                        value={test.name}
                        onChange={(e) => {
                          const updated = [...testimonials];
                          updated[idx].name = e.target.value;
                          updateTestimonials(updated);
                        }}
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-1">City / Location</label>
                      <input
                        type="text"
                        value={test.city || ''}
                        onChange={(e) => {
                          const updated = [...testimonials];
                          updated[idx].city = e.target.value;
                          updateTestimonials(updated);
                        }}
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-1">Clinical Condition</label>
                      <input
                        type="text"
                        value={test.condition || ''}
                        onChange={(e) => {
                          const updated = [...testimonials];
                          updated[idx].condition = e.target.value;
                          updateTestimonials(updated);
                        }}
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 mb-1">Review Comment</label>
                    <textarea
                      rows={2}
                      value={test.comment}
                      onChange={(e) => {
                        const updated = [...testimonials];
                        updated[idx].comment = e.target.value;
                        updateTestimonials(updated);
                      }}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 7. FAQs */}
        {activeTab === 'faqs' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="text-sm font-bold text-slate-900">Patient FAQs</h3>
              <button
                type="button"
                onClick={() => {
                  const newFaq: FaqItem = {
                    question: 'New Question?',
                    answer: 'Helpful clear answer for patients.'
                  };
                  updateFaqs([...faqs, newFaq]);
                }}
                className="px-3 py-1.5 bg-sky-900 text-white rounded-xl text-xs font-semibold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Add FAQ
              </button>
            </div>

            <div className="space-y-3">
              {faqs.map((faq, idx) => (
                <div key={idx} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800">FAQ #{idx + 1}</span>
                    <button
                      type="button"
                      onClick={() => updateFaqs(faqs.filter((_, i) => i !== idx))}
                      className="text-rose-500 hover:text-rose-700 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 mb-1">Question</label>
                    <input
                      type="text"
                      value={faq.question}
                      onChange={(e) => {
                        const updated = [...faqs];
                        updated[idx].question = e.target.value;
                        updateFaqs(updated);
                      }}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg font-medium"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 mb-1">Answer</label>
                    <textarea
                      rows={2}
                      value={faq.answer}
                      onChange={(e) => {
                        const updated = [...faqs];
                        updated[idx].answer = e.target.value;
                        updateFaqs(updated);
                      }}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 8. Schedule & Notice */}
        {activeTab === 'schedule' && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b pb-2">Clinic Schedule & Announcement Banner</h3>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Working Hours Text (Summary)</label>
              <textarea
                rows={2}
                value={draft.workingHoursText}
                onChange={(e) => updateDraft({ workingHoursText: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Consultation Fee Notice</label>
              <input
                type="text"
                value={draft.consultationFeeText}
                onChange={(e) => updateDraft({ consultationFeeText: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Notice / Camp Banner</label>
              <textarea
                rows={2}
                value={draft.noticeBanner}
                onChange={(e) => updateDraft({ noticeBanner: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
              />
            </div>
          </div>
        )}

        {/* 9. Contact & Map */}
        {activeTab === 'contact' && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b pb-2">Clinic Address & Google Map</h3>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Full Clinic Address</label>
              <textarea
                rows={2}
                value={draft.address}
                onChange={(e) => updateDraft({ address: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">City & State</label>
              <input
                type="text"
                value={draft.city}
                onChange={(e) => updateDraft({ city: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Google Maps Embed URL</label>
              <input
                type="text"
                value={draft.mapEmbedUrl}
                onChange={(e) => updateDraft({ mapEmbedUrl: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl font-mono text-[11px]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Google Review Link</label>
              <input
                type="text"
                value={draft.googleReviewUrl}
                onChange={(e) => updateDraft({ googleReviewUrl: e.target.value })}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl font-mono text-[11px]"
              />
            </div>
          </div>
        )}

        {/* 10. Visibility & Theme */}
        {activeTab === 'theme' && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b pb-2">Section Visibility Toggles</h3>
            <p className="text-xs text-slate-500">Enable or disable specific sections on the public homepage:</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {[
                { key: 'hero', label: 'Hero Section' },
                { key: 'stats', label: 'Statistics Bar' },
                { key: 'about', label: 'Doctor About' },
                { key: 'services', label: 'Services Grid' },
                { key: 'whyChooseUs', label: 'Why Choose Us' },
                { key: 'gallery', label: 'Photo Gallery' },
                { key: 'videoGallery', label: 'Video Showcase' },
                { key: 'testimonials', label: 'Patient Reviews' },
                { key: 'booking', label: 'Booking Form' },
                { key: 'workingHours', label: 'Working Hours' },
                { key: 'faqs', label: 'FAQs Accordion' },
                { key: 'contact', label: 'Contact & Map' }
              ].map(({ key, label }) => {
                const isVisible = sectionVisibility[key] !== false;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => toggleSection(key)}
                    className={`p-3 rounded-xl border text-left text-xs font-semibold flex items-center justify-between transition-colors ${
                      isVisible
                        ? 'bg-sky-50 border-sky-300 text-sky-900'
                        : 'bg-slate-50 border-slate-200 text-slate-400'
                    }`}
                  >
                    <span>{label}</span>
                    <span className={`w-2.5 h-2.5 rounded-full ${isVisible ? 'bg-sky-600' : 'bg-slate-300'}`} />
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Media Picker Modal */}
      {showMediaPickerField && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 space-y-4 shadow-2xl max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="text-base font-bold text-slate-900">Select from Media Library</h3>
              <button
                onClick={() => setShowMediaPickerField(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>
            {mediaList.length === 0 ? (
              <p className="text-xs text-slate-500 py-8 text-center">No media available. Upload photos first.</p>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {mediaList.map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => {
                      if (showMediaPickerField === 'heroBgUrl') {
                        const isVid = m.mediaType === 'video';
                        updateDraft({
                          heroBgUrl: m.url,
                          heroBgType: isVid ? 'video' : 'image',
                          heroBgPosterUrl: isVid ? m.posterUrl || '' : ''
                        });
                      } else {
                        updateDraft({ [showMediaPickerField]: m.url });
                      }
                      setShowMediaPickerField(null);
                    }}
                    className="group border border-slate-200 rounded-xl overflow-hidden hover:border-sky-500 text-left"
                  >
                    <div className="aspect-video bg-slate-100 overflow-hidden">
                      <img src={m.thumbnailUrl || m.url} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    </div>
                    <div className="p-2 text-[11px] font-medium text-slate-800 truncate">
                      {m.caption || m.filename}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Confirmation to Publish Modal */}
      {showConfirmPublish && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-xl">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Globe className="w-5 h-5 text-emerald-600" />
              Publish Live to Website?
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              This will update the live clinic website immediately. All patients and visitors will see the revised details.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowConfirmPublish(false)}
                className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:text-slate-900"
              >
                Cancel
              </button>
              <button
                onClick={async () => {
                  setShowConfirmPublish(false);
                  await publishDraft();
                }}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold rounded-xl"
              >
                Yes, Publish Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
