import React, { useState, useRef } from 'react';
import { Download, Upload, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';
import * as api from '../../services/api';

export function BackupRestorePanel() {
  const { showToast, refreshContent, refreshMedia, refreshSettings } = useClinic();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isRestoring, setIsRestoring] = useState(false);

  const handleExport = () => {
    window.location.href = '/api/backup/export';
    showToast('Clinic backup download initiated.', 'success');
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!window.confirm('Warning: Restoring from a backup will overwrite current draft and published clinic details with the imported file. Proceed?')) {
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    try {
      setIsRestoring(true);
      const text = await file.text();
      const parsed = JSON.parse(text);

      await api.importBackup(parsed);
      showToast('Clinic backup restored successfully!', 'success');
      await refreshContent();
      await refreshMedia();
      await refreshSettings();
    } catch (err: any) {
      showToast(err.message || 'Failed to parse or restore backup file', 'error');
    } finally {
      setIsRestoring(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6 max-w-xl">
      <div className="border-b pb-3">
        <h3 className="text-base font-bold text-slate-900">Clinic Data Backup & Disaster Recovery</h3>
        <p className="text-xs text-slate-500 mt-0.5">
          Safeguard website configurations, media documents, doctor profile, and services.
        </p>
      </div>

      <div className="space-y-4">
        {/* Export Card */}
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-4">
          <div>
            <h4 className="text-xs font-bold text-slate-800">Export Complete JSON Backup</h4>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Downloads a timestamped snapshot of published content, drafts, and schedule settings.
            </p>
          </div>
          <button
            type="button"
            onClick={handleExport}
            className="px-3.5 py-2 bg-sky-900 hover:bg-sky-800 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export</span>
          </button>
        </div>

        {/* Restore Card */}
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-4">
          <div>
            <h4 className="text-xs font-bold text-slate-800">Restore from JSON File</h4>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Select a previously exported Dr. Chouhan clinic backup to restore configurations.
            </p>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            className="hidden"
            onChange={handleFileChange}
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isRestoring}
            className="px-3.5 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-semibold rounded-xl flex items-center gap-1.5 shrink-0 disabled:opacity-50"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>{isRestoring ? 'Restoring...' : 'Restore'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
