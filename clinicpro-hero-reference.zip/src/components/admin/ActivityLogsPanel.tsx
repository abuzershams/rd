import React from 'react';
import { Activity, Shield, Calendar, Image as ImageIcon, Edit3, Key } from 'lucide-react';
import { useClinic } from '../../context/ClinicContext';

export function ActivityLogsPanel() {
  const { activityLogs } = useClinic();

  const getIcon = (category: string) => {
    switch (category) {
      case 'auth':
        return <Key className="w-3.5 h-3.5 text-amber-600" />;
      case 'booking':
        return <Calendar className="w-3.5 h-3.5 text-emerald-600" />;
      case 'media':
        return <ImageIcon className="w-3.5 h-3.5 text-sky-600" />;
      case 'editor':
        return <Edit3 className="w-3.5 h-3.5 text-purple-600" />;
      default:
        return <Activity className="w-3.5 h-3.5 text-slate-500" />;
    }
  };

  return (
    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
      <div className="border-b pb-3 flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Shield className="w-5 h-5 text-sky-700" />
            Security & Administrative Audit Trail
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Immutable log of logins, media operations, content publications, and bookings.
          </p>
        </div>
        <span className="text-xs font-semibold text-slate-400">
          {activityLogs.length} events logged
        </span>
      </div>

      {activityLogs.length === 0 ? (
        <p className="text-xs text-slate-400 py-8 text-center">No activity recorded yet.</p>
      ) : (
        <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
          {activityLogs.map((log) => (
            <div
              key={log.id}
              className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl flex items-start justify-between gap-3 text-xs"
            >
              <div className="flex items-start gap-2.5">
                <div className="p-1.5 bg-white rounded-lg border border-slate-200 shrink-0 mt-0.5">
                  {getIcon(log.category)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-800">{log.action.replace(/_/g, ' ').toUpperCase()}</span>
                    <span className="text-[10px] text-slate-400">by {log.actor}</span>
                  </div>
                  <p className="text-slate-600 mt-0.5 leading-relaxed">{log.details}</p>
                </div>
              </div>
              <span className="text-[10px] text-slate-400 whitespace-nowrap shrink-0">
                {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
