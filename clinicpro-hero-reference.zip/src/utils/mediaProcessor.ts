import { getStoredToken } from '../services/api';

export interface ProcessImageResult {
  fullBlob: Blob;
  thumbBlob: Blob | null;
  width?: number;
  height?: number;
  isOriginal: boolean;
  contentType: string;
  warning?: string;
  details?: string;
}

// Backward-compatible alias type
export type ProcessedImageResult = ProcessImageResult;

// Helper to format bytes cleanly
export function formatBytes(bytes: number): string {
  if (!bytes || bytes <= 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

// Keep screen awake during uploads on mobile devices (Screen Wake Lock API)
let wakeLockSentinel: any = null;

export async function requestWakeLock(): Promise<void> {
  if (typeof navigator !== 'undefined' && 'wakeLock' in navigator && (navigator as any).wakeLock) {
    try {
      wakeLockSentinel = await (navigator as any).wakeLock.request('screen');
    } catch {
      // Wake lock request failed or not permitted; non-fatal
    }
  }
}

export function releaseWakeLock(): void {
  if (wakeLockSentinel) {
    try {
      wakeLockSentinel.release();
    } catch {
      // ignore
    }
    wakeLockSentinel = null;
  }
}

interface DecodedSource {
  source: CanvasImageSource;
  width: number;
  height: number;
  close: () => void;
}

// 1. Decode attempt: createImageBitmap(file)
async function decodeWithCreateImageBitmap(file: File): Promise<DecodedSource> {
  if (typeof createImageBitmap !== 'function') {
    throw new Error('createImageBitmap is not supported in this environment');
  }
  // Modern browsers auto-orient image by default
  const bitmap = await createImageBitmap(file);
  return {
    source: bitmap,
    width: bitmap.width,
    height: bitmap.height,
    close: () => {
      try {
        bitmap.close();
      } catch {
        // ignore
      }
    }
  };
}

// 2. Decode attempt: HTMLImageElement with URL.createObjectURL(file)
function decodeWithCreateObjectURL(file: File): Promise<DecodedSource> {
  return new Promise((resolve, reject) => {
    let objectUrl: string | null = null;
    try {
      objectUrl = URL.createObjectURL(file);
    } catch (err) {
      reject(err);
      return;
    }

    const img = new Image();
    const urlToRevoke = objectUrl;

    img.onload = () => {
      // Requirement 8: Revoke object URLs after use
      URL.revokeObjectURL(urlToRevoke);
      resolve({
        source: img,
        width: img.naturalWidth || img.width,
        height: img.naturalHeight || img.height,
        close: () => {}
      });
    };

    img.onerror = (e) => {
      // Requirement 8: Revoke object URLs after use
      URL.revokeObjectURL(urlToRevoke);
      reject(new Error(`HTMLImageElement load error: ${e && typeof e === 'object' && 'message' in e ? (e as any).message : 'Image decode failed'}`));
    };

    img.src = urlToRevoke;
  });
}

// 3. Decode attempt: FileReader dataURL image
function decodeWithFileReader(file: File): Promise<DecodedSource> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => {
      if (!reader.result || typeof reader.result !== 'string') {
        reject(new Error('FileReader produced empty data'));
        return;
      }
      const img = new Image();
      img.onload = () => {
        resolve({
          source: img,
          width: img.naturalWidth || img.width,
          height: img.naturalHeight || img.height,
          close: () => {}
        });
      };
      img.onerror = () => {
        reject(new Error('HTMLImageElement failed to decode FileReader dataURL'));
      };
      img.src = reader.result;
    };

    reader.onerror = () => {
      reject(reader.error || new Error('FileReader failed to read file'));
    };

    reader.readAsDataURL(file);
  });
}

// Encode canvas to JPEG with retry if toBlob returns null (Requirement 3)
function encodeCanvasToJpeg(canvas: HTMLCanvasElement, quality: number = 0.82): Promise<Blob> {
  return new Promise((resolve, reject) => {
    try {
      canvas.toBlob(
        (blob) => {
          if (blob) {
            resolve(blob);
          } else {
            // Retry with image/jpeg without quality argument
            try {
              canvas.toBlob(
                (retryBlob) => {
                  if (retryBlob) {
                    resolve(retryBlob);
                  } else {
                    reject(new Error('canvas.toBlob returned null for image/jpeg'));
                  }
                },
                'image/jpeg'
              );
            } catch (err) {
              reject(err);
            }
          }
        },
        'image/jpeg',
        quality
      );
    } catch (err) {
      reject(err);
    }
  });
}

/**
 * Shared Image Processing Pipeline (Requirement 1)
 * Decodes image via fallback chain:
 *   createImageBitmap -> HTMLImageElement (ObjectURL) -> FileReader (dataURL)
 * Never allows decode failure to block the upload (Requirement 4).
 */
export async function processImage(file: File, maxDimension: number = 1920): Promise<ProcessImageResult> {
  const lowerName = file.name.toLowerCase();
  const isHeic =
    file.type === 'image/heic' ||
    file.type === 'image/heif' ||
    lowerName.endsWith('.heic') ||
    lowerName.endsWith('.heif');
  const isImageMime = file.type.startsWith('image/');
  const isImageExt = /\.(jpe?g|png|webp|gif|bmp|svg|avif|heic|heif|ico|tiff?)$/i.test(lowerName);

  // Reject only if the file is too large or not image/* (Requirement 4)
  if (!isImageMime && !isImageExt && !isHeic) {
    const errorMsg = `File "${file.name}" is not a recognized image format.`;
    console.error('[ImagePipeline] Non-image file rejected:', {
      fileName: file.name,
      type: file.type,
      size: file.size,
      errorName: 'InvalidImageFormatError',
      errorMessage: errorMsg
    });
    throw new Error(errorMsg);
  }

  const MAX_FILE_SIZE = 150 * 1024 * 1024; // 150 MB limit
  if (file.size > MAX_FILE_SIZE) {
    const errorMsg = `File "${file.name}" exceeds maximum allowed size of 150MB.`;
    console.error('[ImagePipeline] File size limit exceeded:', {
      fileName: file.name,
      type: file.type,
      size: file.size,
      errorName: 'FileSizeLimitError',
      errorMessage: errorMsg
    });
    throw new Error(errorMsg);
  }

  // Fallback decoding chain (Requirement 2)
  let decoded: DecodedSource | null = null;
  let lastError: any = null;

  try {
    decoded = await decodeWithCreateImageBitmap(file);
  } catch (err1: any) {
    lastError = err1;
    try {
      decoded = await decodeWithCreateObjectURL(file);
    } catch (err2: any) {
      lastError = err2;
      try {
        decoded = await decodeWithFileReader(file);
      } catch (err3: any) {
        lastError = err3;
        decoded = null;
      }
    }
  }

  // If ALL decode attempts fail (Requirement 4 & 6 & 7)
  if (!decoded) {
    const errorName = lastError?.name || 'ImageDecodeFailure';
    const errorMessage = lastError?.message || 'Could not decode image with createImageBitmap, ObjectURL, or FileReader';

    // Requirement 7: Log real error to console
    console.error('[ImagePipeline] All image decode attempts failed:', {
      fileName: file.name,
      type: file.type,
      size: file.size,
      errorName,
      errorMessage
    });

    const details = `${file.name} (${file.type || 'unknown'}, ${formatBytes(file.size)}): ${errorName} - ${errorMessage}`;

    // Requirement 6: For HEIC/HEIF: if browser cannot decode, upload original and show warning
    if (isHeic) {
      return {
        fullBlob: file,
        thumbBlob: null,
        width: 0,
        height: 0,
        isOriginal: true,
        contentType: file.type || 'image/heic',
        warning: 'This format may not display on every phone, prefer JPG/PNG',
        details
      };
    }

    // Requirement 4: Upload original file unchanged with its real contentType, skip thumbnail, show warning
    return {
      fullBlob: file,
      thumbBlob: null,
      width: 0,
      height: 0,
      isOriginal: true,
      contentType: file.type || 'image/jpeg',
      warning: 'Uploaded without optimization',
      details
    };
  }

  // Decode succeeded: Resize to max 1920px & encode with JPEG 0.82 (Requirement 3)
  const { source, width, height, close } = decoded;

  let targetW = width;
  let targetH = height;

  if (targetW > maxDimension || targetH > maxDimension) {
    if (targetW > targetH) {
      targetH = Math.round((targetH * maxDimension) / targetW);
      targetW = maxDimension;
    } else {
      targetW = Math.round((targetW * maxDimension) / targetH);
      targetH = maxDimension;
    }
  }

  const fullCanvas = document.createElement('canvas');
  fullCanvas.width = targetW;
  fullCanvas.height = targetH;
  const fullCtx = fullCanvas.getContext('2d');

  if (!fullCtx) {
    close();
    console.warn('[ImagePipeline] Unable to acquire canvas 2D context, falling back to original file');
    return {
      fullBlob: file,
      thumbBlob: null,
      width,
      height,
      isOriginal: true,
      contentType: file.type || 'image/jpeg',
      warning: 'Uploaded without optimization',
      details: `${file.name}: Canvas 2D context unavailable`
    };
  }

  // Draw full image
  fullCtx.drawImage(source, 0, 0, targetW, targetH);

  // Thumbnail creation (400px maximum dimension)
  let thumbW = targetW;
  let thumbH = targetH;
  const thumbMax = 400;
  if (thumbW > thumbMax || thumbH > thumbMax) {
    if (thumbW > thumbH) {
      thumbH = Math.round((thumbH * thumbMax) / thumbW);
      thumbW = thumbMax;
    } else {
      thumbW = Math.round((thumbW * thumbMax) / thumbH);
      thumbH = thumbMax;
    }
  }

  const thumbCanvas = document.createElement('canvas');
  thumbCanvas.width = thumbW;
  thumbCanvas.height = thumbH;
  const thumbCtx = thumbCanvas.getContext('2d');
  if (thumbCtx) {
    thumbCtx.drawImage(source, 0, 0, thumbW, thumbH);
  }

  // Release source bitmap/image memory
  close();

  // Encode full canvas as JPEG 0.82 with retry (Requirement 3)
  let fullBlob: Blob;
  try {
    fullBlob = await encodeCanvasToJpeg(fullCanvas, 0.82);
  } catch (encodeErr: any) {
    console.error('[ImagePipeline] Canvas encoding failed, falling back to original file:', {
      fileName: file.name,
      type: file.type,
      size: file.size,
      errorName: encodeErr?.name,
      errorMessage: encodeErr?.message
    });
    return {
      fullBlob: file,
      thumbBlob: null,
      width: targetW,
      height: targetH,
      isOriginal: true,
      contentType: file.type || 'image/jpeg',
      warning: 'Uploaded without optimization',
      details: `${file.name}: ${encodeErr?.message || 'Encoding failed'}`
    };
  }

  // Encode thumbnail canvas (Requirement 5: thumbnail failure must never fail main upload)
  let thumbBlob: Blob | null = null;
  if (thumbCtx) {
    try {
      thumbBlob = await encodeCanvasToJpeg(thumbCanvas, 0.82);
    } catch (thumbErr) {
      console.warn('[ImagePipeline] Thumbnail encoding failed, will use main image as thumbnail:', thumbErr);
      thumbBlob = null;
    }
  }

  return {
    fullBlob,
    thumbBlob,
    width: targetW,
    height: targetH,
    isOriginal: false,
    contentType: 'image/jpeg'
  };
}

// Backward-compatible alias
export const processImageFile = processImage;

// Generate poster frame from video file
export async function generateVideoPoster(videoFile: File): Promise<Blob | null> {
  return new Promise((resolve) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    video.playsInline = true;
    let objectUrl: string | null = null;
    try {
      objectUrl = URL.createObjectURL(videoFile);
    } catch {
      resolve(null);
      return;
    }

    const cleanup = () => {
      if (objectUrl) URL.revokeObjectURL(objectUrl);
      video.remove();
    };

    video.onloadedmetadata = () => {
      video.currentTime = Math.min(1.0, video.duration > 0 ? video.duration / 2 : 0.5);
    };

    video.onseeked = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth || 640;
        canvas.height = video.videoHeight || 360;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          canvas.toBlob(
            (blob) => {
              cleanup();
              resolve(blob);
            },
            'image/jpeg',
            0.8
          );
        } else {
          cleanup();
          resolve(null);
        }
      } catch {
        cleanup();
        resolve(null);
      }
    };

    video.onerror = () => {
      cleanup();
      resolve(null);
    };

    video.src = objectUrl;
  });
}

// Upload a file to the site's own storage (Netlify Blobs) in 4 MB chunks.
// Function name kept for compatibility with MediaManager.
const UPLOAD_CHUNK_SIZE = 4 * 1024 * 1024;

export const fileIdFromPath = (p: string) => p.replace(/[^a-zA-Z0-9._-]/g, '_');

export function uploadToFirebaseStorage(
  storagePath: string,
  blobOrFile: Blob | File,
  onProgress?: (percent: number) => void,
  metadata?: { contentType?: string }
): {
  promise: Promise<string>;
  cancel: () => void;
} {
  const id = fileIdFromPath(storagePath);
  const total = Math.max(1, Math.ceil(blobOrFile.size / UPLOAD_CHUNK_SIZE));
  const type = metadata?.contentType || blobOrFile.type || 'application/octet-stream';
  const controller = new AbortController();
  let isCancelled = false;

  const promise = (async () => {
    const token = getStoredToken();
    for (let i = 0; i < total; i++) {
      if (isCancelled) throw new Error('Upload cancelled by user');
      const chunk = blobOrFile.slice(i * UPLOAD_CHUNK_SIZE, (i + 1) * UPLOAD_CHUNK_SIZE);
      let attempt = 0;
      // retry each chunk up to 3 times (weak mobile networks)
      while (true) {
        try {
          const res = await fetch(
            `/api/files/${encodeURIComponent(id)}/chunk/${i}?total=${total}&size=${blobOrFile.size}&type=${encodeURIComponent(type)}`,
            {
              method: 'PUT',
              headers: {
                Authorization: `Bearer ${token || ''}`,
                'Content-Type': 'application/octet-stream'
              },
              body: chunk,
              signal: controller.signal
            }
          );
          if (!res.ok) {
            const d = await res.json().catch(() => ({}));
            const err: any = new Error(d.error || `Upload failed (HTTP ${res.status})`);
            err.status = res.status;
            throw err;
          }
          break;
        } catch (e: any) {
          if (isCancelled) throw new Error('Upload cancelled by user');
          attempt++;
          // do not retry auth/validation errors
          if (attempt >= 3 || (e.status && e.status < 500)) throw e;
          await new Promise((r) => setTimeout(r, 800 * attempt));
        }
      }
      if (onProgress) onProgress(Math.round(((i + 1) / total) * 100));
    }
    return `/api/files/${encodeURIComponent(id)}`;
  })();

  return {
    promise,
    cancel: () => {
      isCancelled = true;
      try {
        controller.abort();
      } catch {
        // ignore
      }
    }
  };
}

// Delete a stored file (server also cleans files itself when a media item is deleted)
export async function deleteFromFirebaseStorage(storagePath?: string): Promise<boolean> {
  if (!storagePath) return true;
  try {
    const res = await fetch(`/api/files/${encodeURIComponent(fileIdFromPath(storagePath))}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${getStoredToken() || ''}` }
    });
    return res.ok;
  } catch (err: any) {
    console.warn('Storage cleanup notice:', err?.message);
    return false;
  }
}

// Validate and parse YouTube or Google Drive video links
export function parseExternalVideoUrl(rawUrl: string): { type: 'youtube' | 'drive' | 'direct'; embedUrl: string; originalUrl: string } | null {
  const trimmed = rawUrl.trim();
  if (!trimmed) return null;

  // YouTube match
  const ytMatch = trimmed.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/);
  if (ytMatch && ytMatch[1]) {
    return {
      type: 'youtube',
      embedUrl: `https://www.youtube.com/embed/${ytMatch[1]}`,
      originalUrl: trimmed
    };
  }

  // Google Drive match
  const driveMatch = trimmed.match(/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (driveMatch && driveMatch[1]) {
    return {
      type: 'drive',
      embedUrl: `https://drive.google.com/file/d/${driveMatch[1]}/preview`,
      originalUrl: trimmed
    };
  }

  // Direct MP4 / WebM / MOV
  if (trimmed.endsWith('.mp4') || trimmed.endsWith('.webm') || trimmed.endsWith('.mov')) {
    return {
      type: 'direct',
      embedUrl: trimmed,
      originalUrl: trimmed
    };
  }

  return null;
}
