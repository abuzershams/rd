import {
  ClinicContent,
  MediaItem,
  Booking,
  BookingSettings,
  ActivityLog,
  AdminUser
} from '../types';

const TOKEN_KEY = 'drchouhan_admin_token';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearStoredToken(): void {
  localStorage.removeItem(TOKEN_KEY);
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {})
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(endpoint, {
    ...options,
    headers
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || `HTTP ${res.status}: ${res.statusText}`);
  }

  return data as T;
}

// -------------------------------------------------------------
// Authentication
// -------------------------------------------------------------
export async function adminLogin(username: string, password: string): Promise<{ token: string; user: AdminUser }> {
  const res = await request<{ success: boolean; token: string; user: AdminUser }>('/api/admin/login', {
    method: 'POST',
    body: JSON.stringify({ username, password })
  });
  setStoredToken(res.token);
  return res;
}

export async function adminGetMe(): Promise<{ authenticated: boolean; user: AdminUser }> {
  return request<{ authenticated: boolean; user: AdminUser }>('/api/admin/me');
}

export async function adminLogout(): Promise<void> {
  try {
    await request('/api/admin/logout', { method: 'POST' });
  } finally {
    clearStoredToken();
  }
}

export async function adminChangeCredentials(currentPassword: string, newUsername?: string, newPassword?: string) {
  const res = await request<{ success: boolean; token: string; message: string }>('/api/admin/change-credentials', {
    method: 'POST',
    body: JSON.stringify({ currentPassword, newUsername, newPassword })
  });
  if (res.token) {
    setStoredToken(res.token);
  }
  return res;
}

export async function adminForgotPassword(username: string) {
  return request<{ success: boolean; maskedEmail?: string; message: string }>('/api/admin/forgot-password', {
    method: 'POST',
    body: JSON.stringify({ username })
  });
}

// -------------------------------------------------------------
// Website Content (Published & Draft)
// -------------------------------------------------------------
export async function getPublishedContent(): Promise<ClinicContent> {
  return request<ClinicContent>('/api/content/published');
}

export async function getDraftContent(): Promise<ClinicContent> {
  return request<ClinicContent>('/api/content/draft');
}

export async function saveDraftContent(updates: Partial<ClinicContent>): Promise<{ success: boolean; draft: ClinicContent }> {
  return request('/api/content/draft', {
    method: 'POST',
    body: JSON.stringify(updates)
  });
}

export async function publishContent(): Promise<{ success: boolean; published: ClinicContent; message: string }> {
  return request('/api/content/publish', {
    method: 'POST'
  });
}

export async function revertDraftContent(): Promise<{ success: boolean; draft: ClinicContent; message: string }> {
  return request('/api/content/revert', {
    method: 'POST'
  });
}

// -------------------------------------------------------------
// Bookings & Slots
// -------------------------------------------------------------
export async function getAvailableSlots(date: string): Promise<{ available: boolean; reason?: string; slots: Array<{ timeSlot: string; isBooked: boolean }> }> {
  return request(`/api/bookings/slots?date=${encodeURIComponent(date)}`);
}

export async function createBooking(payload: {
  patientName: string;
  patientPhone: string;
  patientEmail?: string;
  serviceId?: string;
  serviceName?: string;
  preferredDate: string;
  timeSlot: string;
  message?: string;
  honeypot?: string;
}): Promise<{ success: boolean; booking: Booking; message: string }> {
  return request('/api/bookings/create', {
    method: 'POST',
    body: JSON.stringify(payload)
  });
}

export async function getBookingsList(filter?: string, search?: string): Promise<Booking[]> {
  const params = new URLSearchParams();
  if (filter) params.set('filter', filter);
  if (search) params.set('search', search);
  return request(`/api/bookings/list?${params.toString()}`);
}

export async function updateBooking(id: string, updates: Partial<Booking>): Promise<{ success: boolean; booking: Booking }> {
  return request(`/api/bookings/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(updates)
  });
}

export async function deleteBooking(id: string): Promise<{ success: boolean; message: string }> {
  return request(`/api/bookings/${id}`, {
    method: 'DELETE'
  });
}

export async function createManualBooking(payload: {
  patientName: string;
  patientPhone: string;
  patientEmail?: string;
  serviceName?: string;
  preferredDate: string;
  timeSlot: string;
  adminNotes?: string;
}): Promise<{ success: boolean; booking: Booking }> {
  return request('/api/bookings/manual', {
    method: 'POST',
    body: JSON.stringify(payload)
  });
}

// -------------------------------------------------------------
// Media Management
// -------------------------------------------------------------
export async function getMediaList(): Promise<MediaItem[]> {
  return request<MediaItem[]>('/api/media/list');
}

export async function saveMediaItem(payload: Partial<MediaItem>): Promise<{ success: boolean; media: MediaItem }> {
  return request('/api/media/save', {
    method: 'POST',
    body: JSON.stringify(payload)
  });
}

export async function replaceMediaItem(id: string, payload: Partial<MediaItem>): Promise<{ success: boolean; media: MediaItem }> {
  return request(`/api/media/replace/${id}`, {
    method: 'POST',
    body: JSON.stringify(payload)
  });
}

export async function deleteMediaItem(id: string): Promise<{ success: boolean; message: string }> {
  return request(`/api/media/${id}`, {
    method: 'DELETE'
  });
}

export async function reorderMedia(orderedIds: string[]): Promise<{ success: boolean; message: string }> {
  return request('/api/media/reorder', {
    method: 'POST',
    body: JSON.stringify({ orderedIds })
  });
}

// -------------------------------------------------------------
// Settings & Logs
// -------------------------------------------------------------
export async function getBookingSettings(): Promise<BookingSettings> {
  return request<BookingSettings>('/api/settings/booking');
}

export async function saveBookingSettings(settings: Partial<BookingSettings>): Promise<{ success: boolean; settings: BookingSettings }> {
  return request('/api/settings/booking', {
    method: 'POST',
    body: JSON.stringify(settings)
  });
}

export async function getActivityLogs(): Promise<ActivityLog[]> {
  return request<ActivityLog[]>('/api/activity/logs');
}

export async function importBackup(data: any): Promise<{ success: boolean; message: string }> {
  return request('/api/backup/import', {
    method: 'POST',
    body: JSON.stringify({ data })
  });
}
