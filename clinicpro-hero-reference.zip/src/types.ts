export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  duration: string;
  price: string;
  category: string;
  iconName: string;
  imageUrl?: string;
}

export interface WhyChooseUsItem {
  title: string;
  description: string;
  icon: string;
}

export interface TestimonialItem {
  id: string;
  name: string;
  age?: string;
  city?: string;
  comment: string;
  rating: number;
  date: string;
  condition?: string;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export interface ClinicStat {
  label: string;
  value: string;
  suffix?: string;
}

export interface SectionVisibility {
  hero: boolean;
  stats: boolean;
  about: boolean;
  services: boolean;
  whyChooseUs: boolean;
  gallery: boolean;
  videoGallery: boolean;
  testimonials: boolean;
  booking: boolean;
  workingHours: boolean;
  faqs: boolean;
  contact: boolean;
}

export interface ThemeSettings {
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  fontFamily: string;
  borderRadius: string;
}

export interface ClinicContent {
  clinicName: string;
  tagline: string;
  clinicLogoUrl?: string;
  doctorName: string;
  doctorPhotoUrl?: string;
  doctorQualifications: string;
  doctorRegistrationNumber: string;
  doctorExperienceYears: number;
  doctorSpecialty: string;
  heroHeading: string;
  heroSubtitle: string;
  heroImageUrl: string;
  heroVideoUrl: string;
  heroBgType?: 'none' | 'image' | 'video';
  heroBgUrl?: string;
  heroBgPosterUrl?: string;
  heroBgOverlay?: string; // 0-95 (% darkness)
  heroBgBlur?: string; // 0-12 (px)
  heroBgTint?: 'dark' | 'brand';
  heroBadge: string;
  aboutHeading: string;
  aboutBio: string;
  aboutHighlights: string; // JSON array of string
  phone: string;
  whatsapp: string;
  emergencyPhone: string;
  email: string;
  address: string;
  city: string;
  mapEmbedUrl: string;
  googleReviewUrl: string;
  socialLinks: string; // JSON object
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string;
  ogImageUrl: string;
  workingHoursText: string;
  consultationFeeText: string;
  noticeBanner: string;
  noticeBannerEnabled: string;
  servicesJson: string; // JSON array of ServiceItem
  whyChooseUsJson: string; // JSON array of WhyChooseUsItem
  testimonialsJson: string; // JSON array of TestimonialItem
  faqsJson: string; // JSON array of FaqItem
  statsJson: string; // JSON array of ClinicStat
  sectionVisibilityJson: string; // JSON object of SectionVisibility
  sectionOrderJson: string; // JSON array of string
  themeSettingsJson: string; // JSON object of ThemeSettings
  lastPublishedAt?: string;
  updatedAt?: string;
}

export interface MediaItem {
  id: string;
  url: string;
  storagePath?: string;
  thumbnailUrl?: string;
  thumbnailStoragePath?: string;
  posterUrl?: string;
  posterStoragePath?: string;
  mediaType: 'photo' | 'video' | 'youtube' | 'drive';
  filename: string;
  sizeBytes: number;
  caption: string;
  altText: string;
  category: string;
  slot: string;
  displayOrder: number;
  isDemo?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Booking {
  id: string;
  bookingNumber: string;
  patientName: string;
  patientPhone: string;
  patientEmail?: string;
  serviceId: string;
  serviceName: string;
  preferredDate: string;
  timeSlot: string;
  slotKey: string;
  message?: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled' | 'noshow';
  adminNotes?: string;
  isWalkIn?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface BookingSettings {
  slotDurationMinutes: number;
  morningStart: string;
  morningEnd: string;
  eveningStart: string;
  eveningEnd: string;
  workingDays: number[];
  holidays: string[];
  maxAdvanceBookingDays: number;
  autoConfirm: boolean;
  consultationFee: number;
  whatsappAlertsEnabled: boolean;
  updatedAt?: string;
}

export interface ActivityLog {
  id: string;
  action: string;
  category: string;
  details: string;
  actor: string;
  timestamp: string;
}

export interface AdminUser {
  username: string;
  role: string;
  permissions?: string[];
  recoveryEmailMasked?: string;
}
