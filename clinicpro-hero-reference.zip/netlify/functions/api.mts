// Netlify Function: full backend for the clinic site.
// - Site data (content, bookings, settings, logs) -> Netlify Blobs store "clinic"
// - Uploaded photos/videos (chunked)              -> Netlify Blobs store "files"
import { getStore } from '@netlify/blobs';
import crypto from 'node:crypto';
// @ts-ignore - JSON seed bundled at build time
import seedJson from '../../data/clinic-store.json' with { type: 'json' };

export const config = { path: '/api/*' };

const JWT_SECRET = process.env.ADMIN_JWT_SECRET || 'drchouhan-clinic-super-secure-token-secret-2026';
const CHUNK_SIZE = 4 * 1024 * 1024; // must match client
const MAX_FILE_BYTES = 150 * 1024 * 1024;

// ---------- helpers ----------
const json = (data: unknown, status = 200, headers: Record<string, string> = {}) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...headers }
  });

const hashPassword = (password: string, salt: string) =>
  crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
const generateSalt = () => crypto.randomBytes(16).toString('hex');
function verifyPassword(password: string, hash: string, salt: string) {
  try {
    return crypto.timingSafeEqual(Buffer.from(hashPassword(password, salt)), Buffer.from(hash));
  } catch {
    return false;
  }
}

function createToken(username: string) {
  const expiresAt = Date.now() + 24 * 60 * 60 * 1000;
  const payload = `${username}:${expiresAt}:${crypto.randomBytes(16).toString('hex')}`;
  const sig = crypto.createHmac('sha256', JWT_SECRET).update(payload).digest('hex');
  return `${Buffer.from(payload).toString('base64url')}.${sig}`;
}

function verifyToken(token?: string | null): { username: string } | null {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  try {
    const payload = Buffer.from(parts[0], 'base64url').toString('utf-8');
    const expected = crypto.createHmac('sha256', JWT_SECRET).update(payload).digest('hex');
    if (!crypto.timingSafeEqual(Buffer.from(parts[1]), Buffer.from(expected))) return null;
    const [username, exp] = payload.split(':');
    if (Date.now() > parseInt(exp, 10)) return null;
    return { username };
  } catch {
    return null;
  }
}

const fileIdFromPath = (p: string) => String(p || '').replace(/[^a-zA-Z0-9._-]/g, '_');

// ---------- storage ----------
const clinicDb = () => getStore({ name: 'clinic', consistency: 'strong' });
const filesDb = () => getStore({ name: 'files', consistency: 'strong' });

async function loadStore(): Promise<any> {
  const db = clinicDb();
  const existing = await db.get('store', { type: 'json' });
  if (existing) return existing;

  const seed: any = JSON.parse(JSON.stringify(seedJson));
  // Optional: set owner credentials from Netlify environment variables on first start
  const envUser = process.env.ADMIN_USERNAME;
  const envPass = process.env.ADMIN_PASSWORD || process.env.ADMIN_INITIAL_PASSWORD;
  if (envUser) seed.admin.username = envUser;
  if (envPass) {
    seed.admin.salt = generateSalt();
    seed.admin.passwordHash = hashPassword(envPass, seed.admin.salt);
  }
  seed.admin.failedAttempts = 0;
  seed.admin.lockedUntil = null;
  await db.setJSON('store', seed);
  return seed;
}
const saveStore = (store: any) => clinicDb().setJSON('store', store);

function addActivity(store: any, action: string, category: string, details: string, actor = 'drchouhan') {
  store.activityLogs.unshift({
    id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    action,
    category,
    details,
    actor,
    timestamp: new Date().toISOString()
  });
  if (store.activityLogs.length > 200) store.activityLogs = store.activityLogs.slice(0, 200);
}

async function deleteFile(id: string) {
  if (!id) return;
  const db = filesDb();
  const meta: any = await db.get(`${id}/meta`, { type: 'json' }).catch(() => null);
  const total = meta?.chunks ?? 0;
  for (let i = 0; i < total; i++) await db.delete(`${id}/${i}`).catch(() => {});
  await db.delete(`${id}/meta`).catch(() => {});
}

// ---------- file serving (range-aware, chunked) ----------
async function serveFile(req: Request, id: string): Promise<Response> {
  const db = filesDb();
  const meta: any = await db.get(`${id}/meta`, { type: 'json' });
  if (!meta) return json({ error: 'File not found' }, 404);

  const { size, chunks, type } = meta;
  const baseHeaders = {
    'Content-Type': type || 'application/octet-stream',
    'Accept-Ranges': 'bytes',
    'Cache-Control': 'public, max-age=31536000, immutable'
  };
  const readChunk = async (i: number) => {
    const buf = await db.get(`${id}/${i}`, { type: 'arrayBuffer' });
    return buf ? new Uint8Array(buf) : null;
  };

  const range = req.headers.get('range');
  if (!range) {
    // Whole file when it fits in one response (photos); otherwise first slice
    if (size <= 5 * 1024 * 1024) {
      const parts: Uint8Array[] = [];
      for (let i = 0; i < chunks; i++) {
        const c = await readChunk(i);
        if (!c) return json({ error: 'File data missing' }, 404);
        parts.push(c);
      }
      return new Response(Buffer.concat(parts), {
        status: 200,
        headers: { ...baseHeaders, 'Content-Length': String(size) }
      });
    }
  }

  let start = 0;
  let end = size - 1;
  const m = range?.match(/bytes=(\d*)-(\d*)/);
  if (m) {
    if (m[1] !== '') start = parseInt(m[1], 10);
    if (m[2] !== '') end = Math.min(parseInt(m[2], 10), size - 1);
    if (m[1] === '' && m[2] !== '') {
      start = Math.max(0, size - parseInt(m[2], 10));
      end = size - 1;
    }
  }
  if (isNaN(start) || start >= size || start > end) {
    return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${size}` } });
  }

  // Keep every response inside one chunk (stays under the 6 MB function limit)
  const idx = Math.floor(start / CHUNK_SIZE);
  const chunkEnd = Math.min((idx + 1) * CHUNK_SIZE - 1, size - 1);
  const realEnd = Math.min(end, chunkEnd);
  const chunk = await readChunk(idx);
  if (!chunk) return json({ error: 'File data missing' }, 404);
  const slice = chunk.slice(start - idx * CHUNK_SIZE, realEnd - idx * CHUNK_SIZE + 1);

  return new Response(slice, {
    status: 206,
    headers: {
      ...baseHeaders,
      'Content-Range': `bytes ${start}-${realEnd}/${size}`,
      'Content-Length': String(slice.byteLength)
    }
  });
}

// ---------- main handler ----------
export default async (req: Request): Promise<Response> => {
  const url = new URL(req.url);
  const path = url.pathname.replace(/\/+$/, '');
  const method = req.method;
  const seg = path.split('/').filter(Boolean); // ['api', ...]

  try {
    // ---- public file serving (no auth, no store load) ----
    if (seg[1] === 'files' && seg[2] && method === 'GET' && seg.length === 3) {
      return await serveFile(req, decodeURIComponent(seg[2]));
    }

    const store = await loadStore();
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : url.searchParams.get('token');
    const session = verifyToken(token);
    const isAdmin = !!session && session.username === store.admin.username;
    const unauthorized = () => json({ error: 'Unauthorized: Admin session expired or invalid' }, 401);
    const body = async () => (await req.json().catch(() => ({}))) as any;
    const route = `${method} /${seg.slice(1).join('/')}`;
    const admin = store.admin.username;

    // ===== AUTH =====
    if (route === 'POST /admin/login') {
      const { username, password } = await body();
      if (!username || !password) return json({ error: 'Username and password are required' }, 400);

      if (store.admin.lockedUntil && Date.now() < store.admin.lockedUntil) {
        const wait = Math.ceil((store.admin.lockedUntil - Date.now()) / 1000);
        return json({ error: `Account locked due to 5 consecutive failed attempts. Try again in ${wait} seconds.` }, 429);
      }
      if (store.admin.lockedUntil && Date.now() >= store.admin.lockedUntil) {
        store.admin.lockedUntil = null;
        store.admin.failedAttempts = 0;
      }
      const userMatch = String(username).trim().toLowerCase() === store.admin.username.toLowerCase();
      const passMatch = userMatch && verifyPassword(password, store.admin.passwordHash, store.admin.salt);
      if (!userMatch || !passMatch) {
        store.admin.failedAttempts = (store.admin.failedAttempts || 0) + 1;
        if (store.admin.failedAttempts >= 5) {
          store.admin.lockedUntil = Date.now() + 5 * 60 * 1000;
          addActivity(store, 'account_locked', 'auth', 'Account locked after 5 failed login attempts', 'Security');
        }
        await saveStore(store);
        return json({ error: 'Invalid username or password' }, 401);
      }
      store.admin.failedAttempts = 0;
      store.admin.lockedUntil = null;
      addActivity(store, 'admin_login', 'auth', 'Owner logged in', store.admin.username);
      await saveStore(store);
      return json({
        success: true,
        token: createToken(store.admin.username),
        user: { username: store.admin.username, role: 'owner', permissions: ['all'] }
      });
    }

    if (route === 'GET /admin/me') {
      if (!isAdmin) return unauthorized();
      return json({
        authenticated: true,
        user: {
          username: store.admin.username,
          role: 'owner',
          recoveryEmailMasked: store.admin.recoveryEmailMasked || 'd***@drchouhanclinic.com'
        }
      });
    }

    if (route === 'POST /admin/logout') {
      if (!isAdmin) return unauthorized();
      addActivity(store, 'admin_logout', 'auth', 'Administrator explicitly logged out', admin);
      await saveStore(store);
      return json({ success: true, message: 'Logged out successfully' });
    }

    if (route === 'POST /admin/change-credentials') {
      if (!isAdmin) return unauthorized();
      const { currentPassword, newUsername, newPassword } = await body();
      if (!currentPassword || (!newUsername && !newPassword))
        return json({ error: 'Current password and new credential values are required' }, 400);
      if (!verifyPassword(currentPassword, store.admin.passwordHash, store.admin.salt))
        return json({ error: 'Current password verification failed' }, 401);
      if (newUsername && String(newUsername).trim().length >= 3) store.admin.username = String(newUsername).trim();
      if (newPassword) {
        if (String(newPassword).length < 6) return json({ error: 'New password must be at least 6 characters' }, 400);
        store.admin.salt = generateSalt();
        store.admin.passwordHash = hashPassword(newPassword, store.admin.salt);
      }
      store.admin.updatedAt = new Date().toISOString();
      addActivity(store, 'change_credentials', 'auth', 'Admin username and/or password successfully updated', store.admin.username);
      await saveStore(store);
      return json({ success: true, token: createToken(store.admin.username), message: 'Credentials updated successfully' });
    }

    if (route === 'POST /admin/forgot-password') {
      const { username } = await body();
      if (!username || String(username).trim().toLowerCase() !== store.admin.username.toLowerCase()) {
        return json({
          success: true,
          message: 'If the username matches, recovery instructions have been sent to the verified administrator contact.'
        });
      }
      addActivity(store, 'password_recovery_requested', 'auth', 'Password recovery requested for owner account', 'Recovery');
      await saveStore(store);
      return json({
        success: true,
        maskedEmail: store.admin.recoveryEmailMasked || 'd***@drchouhanclinic.com',
        message: 'Password recovery verification instructions have been dispatched.'
      });
    }

    // ===== CONTENT =====
    if (route === 'GET /content/published') return json(store.published);

    if (route === 'GET /content/draft') {
      if (!isAdmin) return unauthorized();
      return json(store.draft);
    }
    if (route === 'POST /content/draft') {
      if (!isAdmin) return unauthorized();
      store.draft = { ...store.draft, ...(await body()), updatedAt: new Date().toISOString() };
      await saveStore(store);
      return json({ success: true, draft: store.draft, message: 'Draft saved' });
    }
    if (route === 'POST /content/publish') {
      if (!isAdmin) return unauthorized();
      const at = new Date().toISOString();
      store.published = { ...store.draft, lastPublishedAt: at, updatedAt: at };
      store.draft.lastPublishedAt = at;
      addActivity(store, 'publish_content', 'editor', 'Live website content published successfully', admin);
      await saveStore(store);
      return json({ success: true, published: store.published, message: 'Website published live successfully!' });
    }
    if (route === 'POST /content/revert') {
      if (!isAdmin) return unauthorized();
      store.draft = { ...store.published, updatedAt: new Date().toISOString() };
      addActivity(store, 'revert_draft', 'editor', 'Draft content reverted to last published version', admin);
      await saveStore(store);
      return json({ success: true, draft: store.draft, message: 'Draft reverted to last published version' });
    }

    // ===== BOOKINGS =====
    if (route === 'GET /bookings/slots') {
      const date = url.searchParams.get('date');
      if (!date) return json({ error: 'Date is required (YYYY-MM-DD)' }, 400);
      const dow = new Date(date).getDay();
      const bs = store.bookingSettings;
      if (!bs.workingDays.includes(dow)) return json({ available: false, reason: 'Clinic closed on this day', slots: [] });
      if (bs.holidays.includes(date)) return json({ available: false, reason: 'Clinic closed on holiday', slots: [] });

      const duration = bs.slotDurationMinutes || 30;
      const slots: string[] = [];
      const fmt = (h: number, m: number) => {
        const period = h >= 12 ? 'PM' : 'AM';
        const dh = h % 12 === 0 ? 12 : h % 12;
        return `${dh}:${m < 10 ? '0' + m : m} ${period}`;
      };
      const gen = (s: string, e: string) => {
        const [sh, sm] = s.split(':').map(Number);
        const [eh, em] = e.split(':').map(Number);
        let cur = sh * 60 + sm;
        const end = eh * 60 + em;
        while (cur + duration <= end) {
          const n = cur + duration;
          slots.push(`${fmt(Math.floor(cur / 60), cur % 60)} - ${fmt(Math.floor(n / 60), n % 60)}`);
          cur = n;
        }
      };
      gen(bs.morningStart, bs.morningEnd);
      gen(bs.eveningStart, bs.eveningEnd);
      const booked = store.bookings
        .filter((b: any) => b.preferredDate === date && b.status !== 'cancelled')
        .map((b: any) => b.timeSlot);
      return json({ available: true, date, slots: slots.map((s) => ({ timeSlot: s, isBooked: booked.includes(s) })) });
    }

    if (route === 'POST /bookings/create') {
      const b = await body();
      if (b.honeypot && String(b.honeypot).trim() !== '') return json({ error: 'Submission rejected' }, 400);
      if (!b.patientName || String(b.patientName).trim().length < 2)
        return json({ error: 'Please enter a valid patient name (min 2 characters)' }, 400);
      const cleanPhone = b.patientPhone ? String(b.patientPhone).replace(/\D/g, '') : '';
      const validPhone = cleanPhone.length === 10 || (cleanPhone.length === 12 && cleanPhone.startsWith('91'));
      if (!validPhone) return json({ error: 'Please enter a valid 10-digit Indian mobile number' }, 400);
      if (!b.preferredDate || !b.timeSlot) return json({ error: 'Please select preferred date and time slot' }, 400);
      if (b.preferredDate < new Date().toISOString().split('T')[0])
        return json({ error: 'Appointments cannot be booked for past dates' }, 400);

      const clash = store.bookings.find(
        (x: any) => x.preferredDate === b.preferredDate && x.timeSlot === b.timeSlot && x.status !== 'cancelled'
      );
      if (clash) return json({ error: 'This time slot was just booked by another patient. Please choose another slot.' }, 409);

      const bookingNumber = `CC-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
      const nb = {
        id: `book-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        bookingNumber,
        patientName: String(b.patientName).trim(),
        patientPhone: cleanPhone.length === 12 ? cleanPhone.slice(2) : cleanPhone,
        patientEmail: b.patientEmail ? String(b.patientEmail).trim() : undefined,
        serviceId: b.serviceId || 'srv-general-checkup',
        serviceName: b.serviceName || 'Comprehensive Health & Vitals Check',
        preferredDate: b.preferredDate,
        timeSlot: b.timeSlot,
        slotKey: `${b.preferredDate}_${String(b.timeSlot).replace(/[^a-zA-Z0-9]/g, '-')}`,
        message: b.message ? String(b.message).trim() : undefined,
        status: store.bookingSettings.autoConfirm ? 'confirmed' : 'pending',
        isWalkIn: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      store.bookings.unshift(nb);
      addActivity(store, 'new_booking', 'booking', `New appointment ${bookingNumber} booked for ${nb.patientName} (${nb.preferredDate} at ${nb.timeSlot})`, 'Public Patient');
      await saveStore(store);
      return json({ success: true, booking: nb, message: 'Appointment booked successfully' }, 201);
    }

    if (route === 'GET /bookings/list') {
      if (!isAdmin) return unauthorized();
      const filter = url.searchParams.get('filter');
      const search = url.searchParams.get('search');
      let list = [...store.bookings];
      const today = new Date().toISOString().split('T')[0];
      const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
      if (filter === 'today') list = list.filter((b) => b.preferredDate === today);
      else if (filter === 'tomorrow') list = list.filter((b) => b.preferredDate === tomorrow);
      else if (['pending', 'confirmed', 'completed', 'cancelled', 'noshow'].includes(filter || ''))
        list = list.filter((b) => b.status === filter);
      if (search) {
        const q = search.toLowerCase();
        list = list.filter(
          (b) => b.patientName.toLowerCase().includes(q) || b.patientPhone.includes(q) || b.bookingNumber.toLowerCase().includes(q)
        );
      }
      return json(list);
    }

    if (route === 'POST /bookings/manual') {
      if (!isAdmin) return unauthorized();
      const b = await body();
      if (!b.patientName || !b.patientPhone || !b.preferredDate || !b.timeSlot)
        return json({ error: 'Name, phone, date, and slot are required' }, 400);
      const mb = {
        id: `book-walkin-${Date.now()}`,
        bookingNumber: `CC-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
        patientName: String(b.patientName).trim(),
        patientPhone: String(b.patientPhone).replace(/\D/g, ''),
        patientEmail: b.patientEmail?.trim(),
        serviceId: 'srv-manual',
        serviceName: b.serviceName || 'Walk-in / Phone Consultation',
        preferredDate: b.preferredDate,
        timeSlot: b.timeSlot,
        slotKey: `${b.preferredDate}_${String(b.timeSlot).replace(/[^a-zA-Z0-9]/g, '-')}`,
        status: 'confirmed',
        adminNotes: b.adminNotes || 'Walk-in / In-clinic appointment',
        isWalkIn: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      store.bookings.unshift(mb);
      addActivity(store, 'manual_booking', 'booking', `Walk-in booking created for ${mb.patientName}`, admin);
      await saveStore(store);
      return json({ success: true, booking: mb }, 201);
    }

    if (seg[1] === 'bookings' && seg[2] && (method === 'PATCH' || method === 'DELETE')) {
      if (!isAdmin) return unauthorized();
      const id = seg[2];
      if (method === 'PATCH') {
        const booking = store.bookings.find((b: any) => b.id === id);
        if (!booking) return json({ error: 'Booking not found' }, 404);
        const { status, adminNotes, preferredDate, timeSlot } = await body();
        if (status) booking.status = status;
        if (adminNotes !== undefined) booking.adminNotes = adminNotes;
        if (preferredDate && timeSlot) {
          booking.preferredDate = preferredDate;
          booking.timeSlot = timeSlot;
          booking.slotKey = `${preferredDate}_${String(timeSlot).replace(/[^a-zA-Z0-9]/g, '-')}`;
        }
        booking.updatedAt = new Date().toISOString();
        addActivity(store, 'update_booking', 'booking', `Booking ${booking.bookingNumber} updated (status: ${booking.status})`, admin);
        await saveStore(store);
        return json({ success: true, booking });
      }
      const i = store.bookings.findIndex((b: any) => b.id === id);
      if (i === -1) return json({ error: 'Booking not found' }, 404);
      const [deleted] = store.bookings.splice(i, 1);
      addActivity(store, 'delete_booking', 'booking', `Deleted booking record ${deleted.bookingNumber}`, admin);
      await saveStore(store);
      return json({ success: true, message: 'Booking deleted' });
    }

    // ===== MEDIA: chunked file upload =====
    // PUT /api/files/:id/chunk/:n?total=&size=&type=
    if (method === 'PUT' && seg[1] === 'files' && seg[3] === 'chunk') {
      if (!isAdmin) return unauthorized();
      const id = decodeURIComponent(seg[2]);
      const n = parseInt(seg[4], 10);
      const total = parseInt(url.searchParams.get('total') || '1', 10);
      const size = parseInt(url.searchParams.get('size') || '0', 10);
      const type = url.searchParams.get('type') || 'application/octet-stream';
      if (!id || isNaN(n) || isNaN(total) || n < 0 || n >= total) return json({ error: 'Invalid chunk request' }, 400);
      if (size > MAX_FILE_BYTES) return json({ error: 'File exceeds 150 MB limit' }, 413);

      const data = await req.arrayBuffer();
      if (data.byteLength === 0 || data.byteLength > CHUNK_SIZE) return json({ error: 'Invalid chunk size' }, 400);
      await filesDb().set(`${id}/${n}`, data);
      if (n === total - 1) {
        await filesDb().setJSON(`${id}/meta`, { size, chunks: total, type, createdAt: new Date().toISOString() });
      }
      return json({ success: true, chunk: n, total });
    }

    if (method === 'DELETE' && seg[1] === 'files' && seg[2] && seg.length === 3) {
      if (!isAdmin) return unauthorized();
      await deleteFile(decodeURIComponent(seg[2]));
      return json({ success: true });
    }

    // ===== MEDIA: metadata =====
    if (route === 'GET /media/list') {
      return json([...store.media].sort((a: any, b: any) => a.displayOrder - b.displayOrder));
    }

    if (route === 'POST /media/save') {
      if (!isAdmin) return unauthorized();
      const b = await body();
      if (!b.url || !b.mediaType) return json({ error: 'Media URL and type are required' }, 400);
      const nm = {
        id: `media-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        url: b.url,
        storagePath: b.storagePath,
        thumbnailUrl: b.thumbnailUrl || b.url,
        thumbnailStoragePath: b.thumbnailStoragePath,
        posterUrl: b.posterUrl,
        posterStoragePath: b.posterStoragePath,
        mediaType: b.mediaType || 'photo',
        filename: b.filename || 'media_upload',
        sizeBytes: b.sizeBytes || 0,
        caption: b.caption || '',
        altText: b.altText || b.caption || 'Dr. Chouhan Clinic Media',
        category: b.category || 'gallery',
        slot: b.slot || 'gallery',
        displayOrder: store.media.length + 1,
        isDemo: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      store.media.push(nm);
      addActivity(store, 'upload_media', 'media', `Uploaded media item ${nm.filename} (${nm.mediaType})`, admin);
      await saveStore(store);
      return json({ success: true, media: nm }, 201);
    }

    if (method === 'POST' && seg[1] === 'media' && seg[2] === 'replace' && seg[3]) {
      if (!isAdmin) return unauthorized();
      const item = store.media.find((m: any) => m.id === seg[3]);
      if (!item) return json({ error: 'Media item not found' }, 404);
      const b = await body();
      const oldFiles = [item.storagePath, item.thumbnailStoragePath, item.posterStoragePath];
      item.url = b.url || item.url;
      item.storagePath = b.storagePath || item.storagePath;
      item.thumbnailUrl = b.thumbnailUrl || item.thumbnailUrl;
      item.posterUrl = b.posterUrl || item.posterUrl;
      item.filename = b.filename || item.filename;
      item.sizeBytes = b.sizeBytes || item.sizeBytes;
      item.isDemo = false;
      item.updatedAt = new Date().toISOString();
      addActivity(store, 'replace_media', 'media', `Replaced media asset for item ${item.id}`, admin);
      await saveStore(store);
      // clean up old files that are no longer referenced
      const keep = new Set([item.storagePath, item.thumbnailStoragePath, item.posterStoragePath].filter(Boolean).map(fileIdFromPath));
      for (const p of oldFiles) if (p && !keep.has(fileIdFromPath(p))) await deleteFile(fileIdFromPath(p));
      return json({ success: true, media: item, message: 'Media replaced successfully' });
    }

    if (method === 'DELETE' && seg[1] === 'media' && seg[2] && seg.length === 3) {
      if (!isAdmin) return unauthorized();
      const i = store.media.findIndex((m: any) => m.id === seg[2]);
      if (i === -1) return json({ error: 'Media item not found' }, 404);
      const [deleted] = store.media.splice(i, 1);
      addActivity(store, 'delete_media', 'media', `Deleted media ${deleted.filename}`, admin);
      await saveStore(store);
      for (const p of [deleted.storagePath, deleted.thumbnailStoragePath, deleted.posterStoragePath])
        if (p) await deleteFile(fileIdFromPath(p));
      return json({ success: true, message: 'Media deleted successfully' });
    }

    if (route === 'POST /media/reorder') {
      if (!isAdmin) return unauthorized();
      const { orderedIds } = await body();
      if (!Array.isArray(orderedIds)) return json({ error: 'orderedIds array required' }, 400);
      orderedIds.forEach((id: string, idx: number) => {
        const it = store.media.find((m: any) => m.id === id);
        if (it) it.displayOrder = idx + 1;
      });
      await saveStore(store);
      return json({ success: true, message: 'Media reordered successfully' });
    }

    // ===== SETTINGS / LOGS / BACKUP =====
    if (route === 'GET /settings/booking') return json(store.bookingSettings);
    if (route === 'POST /settings/booking') {
      if (!isAdmin) return unauthorized();
      store.bookingSettings = { ...store.bookingSettings, ...(await body()), updatedAt: new Date().toISOString() };
      addActivity(store, 'update_settings', 'settings', 'Clinic consultation schedule settings updated', admin);
      await saveStore(store);
      return json({ success: true, settings: store.bookingSettings });
    }
    if (route === 'GET /activity/logs') {
      if (!isAdmin) return unauthorized();
      return json(store.activityLogs);
    }
    if (route === 'GET /backup/export') {
      if (!isAdmin) return unauthorized();
      return new Response(
        JSON.stringify({ exportedAt: new Date().toISOString(), version: '1.0', published: store.published, draft: store.draft, media: store.media, bookingSettings: store.bookingSettings }, null, 2),
        { headers: { 'Content-Type': 'application/json', 'Content-Disposition': 'attachment; filename="drchouhan-clinic-backup.json"' } }
      );
    }
    if (route === 'POST /backup/import') {
      if (!isAdmin) return unauthorized();
      const { data } = await body();
      if (!data || !data.published) return json({ error: 'Invalid backup file structure' }, 400);
      if (data.published) store.published = data.published;
      if (data.draft) store.draft = data.draft;
      if (Array.isArray(data.media)) store.media = data.media;
      if (data.bookingSettings) store.bookingSettings = data.bookingSettings;
      addActivity(store, 'restore_backup', 'settings', 'Restored clinic configuration from backup', admin);
      await saveStore(store);
      return json({ success: true, message: 'Data restored successfully' });
    }

    return json({ error: 'Not found' }, 404);
  } catch (err: any) {
    console.error('[api] error', err);
    return json({ error: err?.message || 'Server error' }, 500);
  }
};
