# Dr. Chouhan Clinic — Production Medical Website & Admin System

Comprehensive, high-performance, and secure Doctor Clinic Web Application built with React 18, TypeScript, Vite, Firebase (Cloud Firestore & Storage), and an Express full-stack backend.

---

## 🏥 Quick Overview (English & Hinglish)

**Dr. Chouhan Clinic** ek full-featured, production-ready medical practice website hai jo patients ke liye online appointment booking aur clinic owner (Dr. R. K. Chouhan) ke liye mobile-first Admin Control Panel provide karta hai.

- **Patient Portal**: Mobile-responsive medical website, doctor profile, treatments & services, verified testimonials, photo & video clinic gallery, direct telephone/WhatsApp connectivity, aur live slot reservation system.
- **Admin Control Panel**: Owner-only login (`/#/admin`) with secure salted password authentication, rate-limiting, live website content editor, Android mobile photo/video media manager with sequential uploads, realtime appointment tracking, and CSV export.

---

## 🔐 Admin Login Credentials & Security

Admin portal strictly owner account ke liye reserved hai. No public signup or registration option exists.

- **Portal URL**: `/#/admin` (Accessible via discreet shield icon in top-right header, mobile drawer & footer)
- **Initial Username**: `drchouhan`
- **Initial Password**: `drchouhan123`
- **Security Protections**:
  - Salted PBKDF2 cryptographic password hashing on the server (never exposed to client).
  - 5 failed login attempts ke baad automatically **5-minute security lockout**.
  - Rate limiting & generic authentication error messages against brute force.
  - Re-authentication required to update owner username or password.
  - Password recovery verification without exposing private administrator emails.

---

## 🚀 Key Features Implemented

### 1. Photo & Video Media Manager (Priority 2)
- Real HTML file inputs triggered by user taps (`Choose Photos`, `Choose Videos`, `Choose Photos and Videos`) compatible with native Android gallery and file pickers.
- Sequential uploading pipeline with progress percentages, cancel & retry options.
- Mobile Screen Wake Lock API integration taaki uploads ke dauraan screen band na ho.
- Automatic client-side image resizing up to 1920px longest dimension with WebP/JPEG encoding and 400px fast thumbnail generation.
- Video support (MP4, WebM, MOV) up to 150 MB with automatic poster frame generation.
- Support for YouTube and Google Drive video links with embedding validation.
- Safe 5-step Replace workflow (Upload new -> Verify URL -> Update Firestore document -> Delete old Storage objects).
- Custom confirmation modal for deletions and multi-select bulk delete.

### 2. Live Website Editor (Priority 3)
- Real visual editing across 10 structured sections:
  - Clinic Information, Doctor Credentials, Hero Banner, Services, About Bio, Testimonials, FAQs, Schedule & Notice Banner, Contact & Maps, Section Visibility.
- Device preview toggle (Desktop, Tablet 768px, Mobile 360px).
- Saves working state to `siteContent/draft`.
- Atomic publication to `siteContent/published` via single-click "Publish to Live Site".
- Live instant update without rebuilding or redeploying code.

### 3. Real Appointment Booking (Priority 4)
- 10-digit Indian mobile number validation (`+91` / starting with 6, 7, 8, 9).
- Anti-spam hidden honeypot field.
- Past dates, closed days, and holiday blocking.
- Realtime slot generation based on clinic working hours (Morning & Evening shifts).
- Double-booking prevention via atomic slot key reservation locks.
- Booking confirmation with reference code (e.g. `CC-2026-1042`), Add to Calendar (`.ics`), and direct WhatsApp clinic notification.
- Admin booking management: Filter by Today, Tomorrow, Pending, Confirmed, Completed, Cancelled, No-show, search by patient name/phone, manual walk-in booking, call & WhatsApp quick buttons, and CSV export.

---

## 🛠️ Local Development & Deployment

### 1. Installation
```bash
npm install
```

### 2. Environment Variables (.env)
Create a `.env` file based on `.env.example`:
```env
PORT=3000
ADMIN_INITIAL_PASSWORD=drchouhan123
ADMIN_JWT_SECRET=your-secure-random-jwt-secret-key-2026
VITE_FIREBASE_PROJECT_ID=favorable-genius-k9brs
VITE_FIREBASE_STORAGE_BUCKET=favorable-genius-k9brs.firebasestorage.app
VITE_FIREBASE_FIRESTORE_DATABASE_ID=ai-studio-clinicpromasters-7f0414ba-fa6b-4b13-90c7-c18cd83d0ed4
```

### 3. Run Development Server
```bash
npm run dev
```
Access the application at `http://localhost:3000`.

### 4. Build for Production
```bash
npm run build
npm start
```

### 5. Firebase CLI Deployment Commands
```bash
# Login to Firebase
firebase login

# Deploy Firestore Security Rules
firebase deploy --only firestore:rules

# Deploy Firebase Storage Security Rules
firebase deploy --only storage

# Deploy Hosting
firebase deploy --only hosting
```

---

## 💾 Backup & Disaster Recovery

- **Export**: Navigate to Admin -> `Backup & Restore` -> Click `Export Complete JSON Backup`.
- **Restore**: Click `Restore from JSON File` and select your previously saved JSON file. Confirmation prompt protects against accidental overwrites.

---

## 📋 QA & Verification Checklist

| Feature | Status | Verification Details |
|---|---|---|
| **Admin Login** | ✅ PASSED | Owner `drchouhan` login works. Incorrect credentials reject with "Invalid username or password". 5 failed attempt lockout enforced. |
| **Credential Update** | ✅ PASSED | Current password verified before allowing username or password changes. |
| **Media Upload** | ✅ PASSED | Native file pickers trigger without `capture` attribute; sequential progress and cancel work reliably. |
| **Image Resizing** | ✅ PASSED | Images scaled to max 1920px with 400px thumbnail generated. |
| **Video Processing** | ✅ PASSED | Videos verified under 150 MB; poster frame extracted; inline playback supported. |
| **Safe Replace** | ✅ PASSED | Metadata updated before old storage cleanup; no broken links. |
| **Live Editor** | ✅ PASSED | Content edits saved to draft; atomic publish updates live website instantly. |
| **Slot Booking** | ✅ PASSED | Past dates and closed days disabled; slot collisions prevented; booking ID generated. |
| **Admin Bookings** | ✅ PASSED | Filters, CSV export, Walk-in appointment creation, and status updates verified. |
| **Security Rules** | ✅ PASSED | Deployed Firestore rules deny public reads on private bookings & drafts; published content readable. |
| **Mobile UX** | ✅ PASSED | Responsive on 360px Android devices; sticky call/WhatsApp/booking bar verified. |
