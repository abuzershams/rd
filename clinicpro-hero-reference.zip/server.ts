import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const DATA_DIR = path.resolve(process.cwd(), 'data');
const STORE_FILE = path.join(DATA_DIR, 'clinic-store.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Security secret for session tokens
const JWT_SECRET = process.env.ADMIN_JWT_SECRET || 'drchouhan-clinic-super-secure-token-secret-2026';

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// -------------------------------------------------------------
// Database Store Model
// -------------------------------------------------------------
interface AdminCredential {
  username: string;
  passwordHash: string;
  salt: string;
  failedAttempts: number;
  lockedUntil: number | null;
  recoveryEmailMasked?: string;
  updatedAt: string;
}

interface DefaultClinicContent {
  clinicName: string;
  tagline: string;
  doctorName: string;
  doctorQualifications: string;
  doctorRegistrationNumber: string;
  doctorExperienceYears: number;
  doctorSpecialty: string;
  heroHeading: string;
  heroSubtitle: string;
  heroImageUrl: string;
  heroVideoUrl: string;
  heroBadge: string;
  aboutHeading: string;
  aboutBio: string;
  aboutHighlights: string;
  phone: string;
  whatsapp: string;
  emergencyPhone: string;
  email: string;
  address: string;
  city: string;
  mapEmbedUrl: string;
  googleReviewUrl: string;
  socialLinks: string;
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string;
  ogImageUrl: string;
  workingHoursText: string;
  consultationFeeText: string;
  noticeBanner: string;
  noticeBannerEnabled: string;
  servicesJson: string;
  whyChooseUsJson: string;
  testimonialsJson: string;
  faqsJson: string;
  statsJson: string;
  sectionVisibilityJson: string;
  sectionOrderJson: string;
  themeSettingsJson: string;
  lastPublishedAt: string;
  updatedAt: string;
}

interface StoreData {
  admin: AdminCredential;
  published: DefaultClinicContent;
  draft: DefaultClinicContent;
  media: Array<{
    id: string;
    url: string;
    storagePath?: string;
    thumbnailUrl?: string;
    thumbnailStoragePath?: string;
    posterUrl?: string;
    posterStoragePath?: string;
    mediaType: 'photo' | 'video' | 'youtube' | 'drive';
    filename: string;
    sizeBytes: number;
    caption: string;
    altText: string;
    category: string;
    slot: string;
    displayOrder: number;
    isDemo: boolean;
    createdAt: string;
    updatedAt: string;
  }>;
  bookings: Array<{
    id: string;
    bookingNumber: string;
    patientName: string;
    patientPhone: string;
    patientEmail?: string;
    serviceId: string;
    serviceName: string;
    preferredDate: string;
    timeSlot: string;
    slotKey: string;
    message?: string;
    status: 'pending' | 'confirmed' | 'completed' | 'cancelled' | 'noshow';
    adminNotes?: string;
    isWalkIn: boolean;
    createdAt: string;
    updatedAt: string;
  }>;
  slotLocks: Record<string, { bookingId: string; date: string; timeSlot: string; expiresAt: number }>;
  bookingSettings: {
    slotDurationMinutes: number;
    morningStart: string;
    morningEnd: string;
    eveningStart: string;
    eveningEnd: string;
    workingDays: number[];
    holidays: string[];
    maxAdvanceBookingDays: number;
    autoConfirm: boolean;
    consultationFee: number;
    whatsappAlertsEnabled: boolean;
    updatedAt: string;
  };
  activityLogs: Array<{
    id: string;
    action: string;
    category: string;
    details: string;
    actor: string;
    timestamp: string;
  }>;
}

// Password hashing helpers
function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
}

function generateSalt(): string {
  return crypto.randomBytes(16).toString('hex');
}

function verifyPassword(password: string, hash: string, salt: string): boolean {
  const checkHash = hashPassword(password, salt);
  try {
    return crypto.timingSafeEqual(Buffer.from(checkHash), Buffer.from(hash));
  } catch {
    return false;
  }
}

// Initial default clinic content
const initialClinicContent: DefaultClinicContent = {
  clinicName: "Dr. Chouhan Clinic",
  tagline: "Specialist Care, Modern Diagnostics & Compassionate Healing",
  doctorName: "Dr. R. K. Chouhan",
  doctorQualifications: "MBBS, MD (General Medicine), FICP",
  doctorRegistrationNumber: "MCI-REG-48921-DEL",
  doctorExperienceYears: 16,
  doctorSpecialty: "Consultant Physician & Specialist in Internal Medicine & Lifestyle Disorders",
  heroHeading: "Your Health in Experienced Hands. Dedicated, Timely & Evidence-Based Care.",
  heroSubtitle: "Providing comprehensive medical consultations, chronic disease management, diabetes control, and preventive cardiology in a modern, caring environment.",
  heroImageUrl: "https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1920&q=80",
  heroVideoUrl: "",
  heroBadge: "16+ Years Clinical Excellence · Over 25,000+ Patients Treated",
  aboutHeading: "Committed to Clinical Excellence & Patient Wellness",
  aboutBio: "Dr. R. K. Chouhan is a highly distinguished Senior Consultant Physician with over 16 years of clinical practice. Having served at premier medical institutes, Dr. Chouhan specializes in early diagnosis, metabolic health, hypertension, diabetes mellitus, cardiovascular risk management, and acute infection therapies.\n\nOur clinic is built on the core principle of listening deeply to patients, explaining diagnoses clearly, and designing individualized, ethical treatment plans without unnecessary investigations.",
  aboutHighlights: JSON.stringify([
    "Member of Association of Physicians of India (API)",
    "Certified in Advanced Diabetes Management & Glycemic Control",
    "Specialized in Preventive Cardiology & Hypertension Protocol",
    "State-of-the-Art In-Clinic Vitals & Diagnostic Screening"
  ]),
  phone: "+91 98260 12345",
  whatsapp: "+91 98260 12345",
  emergencyPhone: "+91 98260 12349",
  email: "care@drchouhanclinic.com",
  address: "14-B, Medical Enclave, Opposite City Civil Hospital, Jaipur, Rajasthan - 302006",
  city: "Jaipur, Rajasthan",
  mapEmbedUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d113911.08479717144!2d75.71764654511674!3d26.91243364941913!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db479f976a161%3A0xb36b0c39f1c7d23a!2sJaipur%2C%20Rajasthan!5e0!3m2!1sen!2sin!4v1700000000000",
  googleReviewUrl: "https://g.page/r/drchouhanclinic/review",
  socialLinks: JSON.stringify({
    facebook: "https://facebook.com/drchouhanclinic",
    instagram: "https://instagram.com/drchouhanclinic",
    linkedin: "https://linkedin.com/in/drchouhan",
    youtube: "https://youtube.com/@drchouhanhealth"
  }),
  seoTitle: "Dr. Chouhan Clinic | Senior Consultant Physician in Jaipur",
  seoDescription: "Book consultation with Dr. R. K. Chouhan (MBBS, MD). Specialist in Internal Medicine, Diabetes, Hypertension & General Health in Jaipur. Call +91 98260 12345.",
  seoKeywords: "Dr Chouhan clinic, doctor consultation Jaipur, physician near me, diabetes specialist, general physician Jaipur, book doctor appointment",
  ogImageUrl: "https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1200&q=80",
  workingHoursText: "Mon to Sat: 9:30 AM – 1:30 PM & 5:00 PM – 9:00 PM | Sun: 10:00 AM – 1:00 PM (Prior Appointment)",
  consultationFeeText: "₹600 Consultation Fee (Follow-up valid for 7 days)",
  noticeBanner: "Clinic is open with regular timings. Walk-ins and online priority bookings welcome.",
  noticeBannerEnabled: "true",
  servicesJson: JSON.stringify([
    {
      id: "srv-general-checkup",
      title: "Comprehensive Health & Vitals Check",
      description: "Thorough clinical examination, symptom evaluation, blood pressure monitoring, systemic checkup, and personalized medical guidance.",
      duration: "20 mins",
      price: "₹600",
      category: "General Medicine",
      iconName: "Stethoscope",
      imageUrl: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "srv-diabetes-care",
      title: "Diabetes & Glycemic Management",
      description: "Individualized treatment for Type 1 & Type 2 Diabetes, HbA1c review, insulin adjustment, dietary counseling, and diabetic foot/kidney protection.",
      duration: "30 mins",
      price: "₹800",
      category: "Endocrinology",
      iconName: "Activity",
      imageUrl: "https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "srv-cardio-hypertension",
      title: "Hypertension & Preventive Cardiology",
      description: "Assessment of blood pressure anomalies, ECG evaluation, lipid profile analysis, and cardiovascular risk reduction therapies.",
      duration: "25 mins",
      price: "₹800",
      category: "Cardiovascular",
      iconName: "HeartPulse",
      imageUrl: "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "srv-respiratory-infections",
      title: "Respiratory Care & Chest Infections",
      description: "Treatment for acute & chronic bronchitis, allergic asthma, persistent cough, seasonal viral fevers, and post-viral recovery care.",
      duration: "20 mins",
      price: "₹600",
      category: "Pulmonology",
      iconName: "Wind",
      imageUrl: "https://images.unsplash.com/photo-1584515933487-779824d29309?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "srv-thyroid-metabolic",
      title: "Thyroid & Metabolic Health",
      description: "Diagnosis and regulation of Hypothyroidism, Hyperthyroidism, metabolic syndrome, fatty liver grade management, and weight concerns.",
      duration: "25 mins",
      price: "₹700",
      category: "Metabolism",
      iconName: "ShieldAlert",
      imageUrl: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "srv-geriatric-care",
      title: "Senior Citizen & Geriatric Consultation",
      description: "Comprehensive care for elderly patients managing multiple chronic ailments, medication reconciliation, and bone/joint wellness.",
      duration: "30 mins",
      price: "₹800",
      category: "Geriatrics",
      iconName: "Users",
      imageUrl: "https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&w=800&q=80"
    }
  ]),
  whyChooseUsJson: JSON.stringify([
    {
      title: "16+ Years Experience",
      description: "Decades of trusted diagnostic expertise solving complex and chronic ailments with patient-centric dedication.",
      icon: "Award"
    },
    {
      title: "Zero Unnecessary Tests",
      description: "Ethical medical practice prioritizing clinical assessment and only requesting essential, high-value laboratory investigations.",
      icon: "CheckCircle"
    },
    {
      title: "Minimal Waiting Time",
      description: "Organized appointment scheduling with reserved time slots to respect your valuable time and comfort.",
      icon: "Clock"
    },
    {
      title: "Continuous Patient Care",
      description: "Direct follow-up consultation window and instant WhatsApp communication for lab reports clarification.",
      icon: "HeartHandshake"
    }
  ]),
  testimonialsJson: JSON.stringify([
    {
      id: "test-1",
      name: "Rajendra Sharma",
      age: "54 yrs",
      city: "Jaipur",
      comment: "Dr. Chouhan accurately diagnosed my uncontrolled blood pressure after two other clinics failed to stabilize it. Within 3 weeks of his tailored plan, my readings are steady 120/80. His patience in explaining everything is rare.",
      rating: 5,
      date: "August 2026",
      condition: "Hypertension & Vitals Care"
    },
    {
      id: "test-2",
      name: "Sunita Verma",
      age: "42 yrs",
      city: "Jaipur",
      comment: "My HbA1c came down from 9.4 to 6.8 under Dr. Chouhan's guidance without burdensome heavy dosages. He emphasizes lifestyle corrections along with right medicines. The clinic atmosphere is very neat and calming.",
      rating: 5,
      date: "September 2026",
      condition: "Type 2 Diabetes Reversal"
    },
    {
      id: "test-3",
      name: "Deepak Meena",
      age: "31 yrs",
      city: "Jaipur",
      comment: "Had severe respiratory allergy and recurrent throat infections for months. Dr. Chouhan's targeted treatment cured it in 10 days. Online booking was very smooth and was attended to on time.",
      rating: 5,
      date: "October 2026",
      condition: "Chest Allergy & Infection"
    }
  ]),
  faqsJson: JSON.stringify([
    {
      question: "How do I book an appointment with Dr. Chouhan?",
      answer: "You can book directly via the online appointment form on this website by choosing your preferred date and slot. You can also call our reception desk at +91 98260 12345 or send a WhatsApp message."
    },
    {
      question: "What are the clinic's consultation timings?",
      answer: "The clinic operates Monday through Saturday in two shifts: Morning 9:30 AM – 1:30 PM and Evening 5:00 PM – 9:00 PM. Sundays are open from 10:00 AM – 1:00 PM for pre-booked cases."
    },
    {
      question: "What is the consultation fee and follow-up validity?",
      answer: "The standard consultation fee is ₹600. A free follow-up review for the same condition is valid within 7 days of the initial visit."
    },
    {
      question: "Can I show previous medical reports during the consultation?",
      answer: "Yes, absolutely. Please bring any recent blood test reports, ECGs, prescriptions, or imaging files to your appointment so Dr. Chouhan can review your full medical history."
    },
    {
      question: "Is walk-in consultation allowed without prior booking?",
      answer: "Walk-ins are accommodated between scheduled slots; however, patients with prior online appointments receive first priority to avoid prolonged waiting."
    }
  ]),
  statsJson: JSON.stringify([
    { label: "Years Experience", value: "16+", suffix: "Years" },
    { label: "Patients Treated", value: "25,000+", suffix: "Happy Patients" },
    { label: "Google Rating", value: "4.9", suffix: "★ Stars" },
    { label: "Clinical Accuracy", value: "99%", suffix: "Satisfaction" }
  ]),
  sectionVisibilityJson: JSON.stringify({
    hero: true,
    stats: true,
    about: true,
    services: true,
    whyChooseUs: true,
    gallery: true,
    videoGallery: true,
    testimonials: true,
    booking: true,
    workingHours: true,
    faqs: true,
    contact: true
  }),
  sectionOrderJson: JSON.stringify([
    "hero",
    "stats",
    "about",
    "services",
    "whyChooseUs",
    "gallery",
    "videoGallery",
    "testimonials",
    "booking",
    "workingHours",
    "faqs",
    "contact"
  ]),
  themeSettingsJson: JSON.stringify({
    primaryColor: "#0284c7",
    secondaryColor: "#0f766e",
    accentColor: "#f59e0b",
    fontFamily: "Inter, sans-serif",
    borderRadius: "rounded-xl"
  }),
  lastPublishedAt: new Date().toISOString(),
  updatedAt: new Date().toISOString()
};

// Initial demo media items
const initialMediaItems = [
  {
    id: "media-demo-1",
    url: "https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1920&q=80",
    thumbnailUrl: "https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=400&q=80",
    mediaType: "photo" as const,
    filename: "clinic_exterior_reception.jpg",
    sizeBytes: 420000,
    caption: "Modern Reception & Patient Waiting Lounge [DEMO]",
    altText: "Dr. Chouhan Clinic reception and comfortable waiting area",
    category: "clinic",
    slot: "gallery",
    displayOrder: 1,
    isDemo: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "media-demo-2",
    url: "https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=1920&q=80",
    thumbnailUrl: "https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=400&q=80",
    mediaType: "photo" as const,
    filename: "doctor_consultation_desk.jpg",
    sizeBytes: 380000,
    caption: "Private Consultation Chamber [DEMO]",
    altText: "Doctor examination room with medical diagnostics",
    category: "doctor",
    slot: "gallery",
    displayOrder: 2,
    isDemo: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "media-demo-3",
    url: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&w=1920&q=80",
    thumbnailUrl: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&w=400&q=80",
    mediaType: "photo" as const,
    filename: "diagnostic_equipment_ecg.jpg",
    sizeBytes: 310000,
    caption: "In-House Diagnostic Equipment & Vitals Check [DEMO]",
    altText: "Diagnostic medical instruments in clean clinical setup",
    category: "equipment",
    slot: "gallery",
    displayOrder: 3,
    isDemo: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "media-demo-4",
    url: "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?auto=format&fit=crop&w=1920&q=80",
    thumbnailUrl: "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?auto=format&fit=crop&w=400&q=80",
    mediaType: "photo" as const,
    filename: "patient_wellness_stethoscope.jpg",
    sizeBytes: 450000,
    caption: "Preventive Health Screening Desk [DEMO]",
    altText: "Medical stethoscope and health check instruments",
    category: "services",
    slot: "gallery",
    displayOrder: 4,
    isDemo: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: "media-demo-5",
    url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    posterUrl: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=800&q=80",
    thumbnailUrl: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=400&q=80",
    mediaType: "video" as const,
    filename: "clinic_tour_intro.mp4",
    sizeBytes: 15400000,
    caption: "Dr. Chouhan Clinic Walkthrough & Overview [DEMO]",
    altText: "Clinic facility walkthrough video tour",
    category: "clinic",
    slot: "video-gallery",
    displayOrder: 5,
    isDemo: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

// Initialize database file if not present
function initializeStore(): StoreData {
  const initialSalt = generateSalt();
  const initialPasswordHash = hashPassword(
    process.env.ADMIN_INITIAL_PASSWORD || 'drchouhan123',
    initialSalt
  );

  const defaultStore: StoreData = {
    admin: {
      username: 'drchouhan',
      passwordHash: initialPasswordHash,
      salt: initialSalt,
      failedAttempts: 0,
      lockedUntil: null,
      recoveryEmailMasked: 'd***@drchouhanclinic.com',
      updatedAt: new Date().toISOString()
    },
    published: { ...initialClinicContent },
    draft: { ...initialClinicContent },
    media: [...initialMediaItems],
    bookings: [
      {
        id: "book-demo-1",
        bookingNumber: "CC-2026-101",
        patientName: "Vikram Rathore",
        patientPhone: "9829012345",
        patientEmail: "vikram.rathore@example.com",
        serviceId: "srv-general-checkup",
        serviceName: "Comprehensive Health & Vitals Check",
        preferredDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
        timeSlot: "10:30 AM - 11:00 AM",
        slotKey: `${new Date(Date.now() + 86400000).toISOString().split('T')[0]}_10-30-AM`,
        message: "Routine checkup and blood pressure monitoring review.",
        status: "confirmed",
        adminNotes: "Patient requested ECG review if needed.",
        isWalkIn: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: "book-demo-2",
        bookingNumber: "CC-2026-102",
        patientName: "Pooja Singhal",
        patientPhone: "9414098765",
        serviceId: "srv-diabetes-care",
        serviceName: "Diabetes & Glycemic Management",
        preferredDate: new Date(Date.now() + 172800000).toISOString().split('T')[0],
        timeSlot: "06:00 PM - 06:30 PM",
        slotKey: `${new Date(Date.now() + 172800000).toISOString().split('T')[0]}_06-00-PM`,
        message: "Fasting blood sugar 160. Need medicine adjustment.",
        status: "pending",
        isWalkIn: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ],
    slotLocks: {},
    bookingSettings: {
      slotDurationMinutes: 30,
      morningStart: "09:30",
      morningEnd: "13:30",
      eveningStart: "17:00",
      eveningEnd: "21:00",
      workingDays: [1, 2, 3, 4, 5, 6, 0], // Monday to Sunday (0=Sun)
      holidays: [],
      maxAdvanceBookingDays: 30,
      autoConfirm: false,
      consultationFee: 600,
      whatsappAlertsEnabled: true,
      updatedAt: new Date().toISOString()
    },
    activityLogs: [
      {
        id: "act-init",
        action: "system_bootstrap",
        category: "auth",
        details: "Secure clinic system initialized with verified owner drchouhan credentials.",
        actor: "System",
        timestamp: new Date().toISOString()
      }
    ]
  };

  if (!fs.existsSync(STORE_FILE)) {
    fs.writeFileSync(STORE_FILE, JSON.stringify(defaultStore, null, 2), 'utf-8');
    return defaultStore;
  }

  try {
    const raw = fs.readFileSync(STORE_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    return parsed;
  } catch (err) {
    console.error('Error reading store file, creating default:', err);
    fs.writeFileSync(STORE_FILE, JSON.stringify(defaultStore, null, 2), 'utf-8');
    return defaultStore;
  }
}

let store: StoreData = initializeStore();

function saveStore(): void {
  try {
    fs.writeFileSync(STORE_FILE, JSON.stringify(store, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to write store to disk:', err);
  }
}

// -------------------------------------------------------------
// Authentication Tokens & Middleware
// -------------------------------------------------------------
const activeSessions: Map<string, { username: string; expiresAt: number }> = new Map();

function createToken(username: string): string {
  const nonce = crypto.randomBytes(24).toString('hex');
  const expiresAt = Date.now() + 24 * 60 * 60 * 1000; // 24 hours
  const payload = `${username}:${expiresAt}:${nonce}`;
  const signature = crypto.createHmac('sha256', JWT_SECRET).update(payload).digest('hex');
  const token = `${Buffer.from(payload).toString('base64url')}.${signature}`;
  activeSessions.set(token, { username, expiresAt });
  return token;
}

function verifyToken(token: string | undefined): { username: string } | null {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;

  try {
    const payload = Buffer.from(parts[0], 'base64url').toString('utf-8');
    const signature = parts[1];
    const expectedSignature = crypto.createHmac('sha256', JWT_SECRET).update(payload).digest('hex');

    if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature))) {
      return null;
    }

    const [username, expiresAtStr] = payload.split(':');
    const expiresAt = parseInt(expiresAtStr, 10);

    if (Date.now() > expiresAt) {
      activeSessions.delete(token);
      return null;
    }

    return { username };
  } catch {
    return null;
  }
}

// Auth Middleware for protected admin routes
function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : (req.query.token as string);

  const session = verifyToken(token);
  if (!session || session.username !== store.admin.username) {
    res.status(401).json({ error: 'Unauthorized: Admin session expired or invalid' });
    return;
  }
  (req as any).adminUser = session.username;
  next();
}

function addActivity(action: string, category: string, details: string, actor: string = 'drchouhan'): void {
  const logItem = {
    id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    action,
    category,
    details,
    actor,
    timestamp: new Date().toISOString()
  };
  store.activityLogs.unshift(logItem);
  if (store.activityLogs.length > 200) {
    store.activityLogs = store.activityLogs.slice(0, 200);
  }
  saveStore();
}

// -------------------------------------------------------------
// API Endpoints
// -------------------------------------------------------------

// 1. ADMIN AUTHENTICATION
app.post('/api/admin/login', (req: Request, res: Response): void => {
  const { username, password } = req.body;

  if (!username || !password) {
    res.status(400).json({ error: 'Username and password are required' });
    return;
  }

  // Lockout check
  if (store.admin.lockedUntil && Date.now() < store.admin.lockedUntil) {
    const waitSeconds = Math.ceil((store.admin.lockedUntil - Date.now()) / 1000);
    res.status(429).json({
      error: `Account locked due to 5 consecutive failed attempts. Try again in ${waitSeconds} seconds.`
    });
    return;
  }

  // Clear lock if expired
  if (store.admin.lockedUntil && Date.now() >= store.admin.lockedUntil) {
    store.admin.lockedUntil = null;
    store.admin.failedAttempts = 0;
    saveStore();
  }

  const userMatch = username.trim().toLowerCase() === store.admin.username.toLowerCase();
  const passMatch = userMatch && verifyPassword(password, store.admin.passwordHash, store.admin.salt);

  if (!userMatch || !passMatch) {
    store.admin.failedAttempts = (store.admin.failedAttempts || 0) + 1;
    if (store.admin.failedAttempts >= 5) {
      store.admin.lockedUntil = Date.now() + 5 * 60 * 1000; // 5 min lockout
      addActivity('account_locked', 'auth', 'Account locked after 5 failed login attempts', 'Security');
    }
    saveStore();
    res.status(401).json({ error: 'Invalid username or password' });
    return;
  }

  // Login success
  store.admin.failedAttempts = 0;
  store.admin.lockedUntil = null;
  saveStore();

  const token = createToken(store.admin.username);
  addActivity('admin_login', 'auth', `Owner logged in from ${req.ip || 'client'}`, store.admin.username);

  res.json({
    success: true,
    token,
    user: {
      username: store.admin.username,
      role: 'owner',
      permissions: ['all']
    }
  });
});

app.get('/api/admin/me', requireAdmin, (req: Request, res: Response): void => {
  res.json({
    authenticated: true,
    user: {
      username: store.admin.username,
      role: 'owner',
      recoveryEmailMasked: store.admin.recoveryEmailMasked || 'd***@drchouhanclinic.com'
    }
  });
});

app.post('/api/admin/logout', requireAdmin, (req: Request, res: Response): void => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.slice(7);
  if (token) activeSessions.delete(token);
  addActivity('admin_logout', 'auth', 'Administrator explicitly logged out', store.admin.username);
  res.json({ success: true, message: 'Logged out successfully' });
});

app.post('/api/admin/change-credentials', requireAdmin, (req: Request, res: Response): void => {
  const { currentPassword, newUsername, newPassword } = req.body;

  if (!currentPassword || (!newUsername && !newPassword)) {
    res.status(400).json({ error: 'Current password and new credential values are required' });
    return;
  }

  // Verify current password
  if (!verifyPassword(currentPassword, store.admin.passwordHash, store.admin.salt)) {
    res.status(401).json({ error: 'Current password verification failed' });
    return;
  }

  if (newUsername && newUsername.trim().length >= 3) {
    store.admin.username = newUsername.trim();
  }

  if (newPassword) {
    if (newPassword.length < 6) {
      res.status(400).json({ error: 'New password must be at least 6 characters' });
      return;
    }
    const newSalt = generateSalt();
    store.admin.salt = newSalt;
    store.admin.passwordHash = hashPassword(newPassword, newSalt);
  }

  store.admin.updatedAt = new Date().toISOString();
  saveStore();

  // Invalidate previous sessions
  activeSessions.clear();
  const freshToken = createToken(store.admin.username);

  addActivity('change_credentials', 'auth', 'Admin username and/or password successfully updated', store.admin.username);

  res.json({
    success: true,
    token: freshToken,
    message: 'Credentials updated successfully'
  });
});

app.post('/api/admin/forgot-password', (req: Request, res: Response): void => {
  const { username } = req.body;
  if (!username || username.trim().toLowerCase() !== store.admin.username.toLowerCase()) {
    // Generic response for security
    res.json({
      success: true,
      message: 'If the username matches, recovery instructions have been sent to the verified administrator contact.'
    });
    return;
  }

  addActivity('password_recovery_requested', 'auth', 'Password recovery requested for owner account', 'Recovery');
  res.json({
    success: true,
    maskedEmail: store.admin.recoveryEmailMasked || 'd***@drchouhanclinic.com',
    message: 'Password recovery verification instructions have been dispatched.'
  });
});

// 2. PUBLIC & DRAFT CLINIC CONTENT
app.get('/api/content/published', (_req: Request, res: Response): void => {
  res.json(store.published);
});

app.get('/api/content/draft', requireAdmin, (_req: Request, res: Response): void => {
  res.json(store.draft);
});

app.post('/api/content/draft', requireAdmin, (req: Request, res: Response): void => {
  const updates = req.body;
  store.draft = {
    ...store.draft,
    ...updates,
    updatedAt: new Date().toISOString()
  };
  saveStore();
  res.json({ success: true, draft: store.draft, message: 'Draft saved' });
});

app.post('/api/content/publish', requireAdmin, (_req: Request, res: Response): void => {
  const publishedAt = new Date().toISOString();
  store.published = {
    ...store.draft,
    lastPublishedAt: publishedAt,
    updatedAt: publishedAt
  };
  store.draft.lastPublishedAt = publishedAt;
  saveStore();

  addActivity('publish_content', 'editor', 'Live website content published successfully', store.admin.username);

  res.json({
    success: true,
    published: store.published,
    message: 'Website published live successfully!'
  });
});

app.post('/api/content/revert', requireAdmin, (_req: Request, res: Response): void => {
  store.draft = {
    ...store.published,
    updatedAt: new Date().toISOString()
  };
  saveStore();
  addActivity('revert_draft', 'editor', 'Draft content reverted to last published version', store.admin.username);
  res.json({ success: true, draft: store.draft, message: 'Draft reverted to last published version' });
});

// 3. APPOINTMENTS & BOOKINGS
app.get('/api/bookings/slots', (req: Request, res: Response): void => {
  const { date } = req.query;
  if (!date || typeof date !== 'string') {
    res.status(400).json({ error: 'Date is required (YYYY-MM-DD)' });
    return;
  }

  const selectedDate = new Date(date);
  const dayOfWeek = selectedDate.getDay();

  // Check if clinic is open on this day
  if (!store.bookingSettings.workingDays.includes(dayOfWeek)) {
    res.json({ available: false, reason: 'Clinic closed on this day', slots: [] });
    return;
  }

  // Check if holiday
  if (store.bookingSettings.holidays.includes(date)) {
    res.json({ available: false, reason: 'Clinic closed on holiday', slots: [] });
    return;
  }

  // Generate slots for morning and evening
  const duration = store.bookingSettings.slotDurationMinutes || 30;
  const slots: string[] = [];

  function generateRange(startStr: string, endStr: string) {
    const [startH, startM] = startStr.split(':').map(Number);
    const [endH, endM] = endStr.split(':').map(Number);

    let curr = startH * 60 + startM;
    const end = endH * 60 + endM;

    while (curr + duration <= end) {
      const h1 = Math.floor(curr / 60);
      const m1 = curr % 60;
      const h2 = Math.floor((curr + duration) / 60);
      const m2 = (curr + duration) % 60;

      const formatTime = (h: number, m: number) => {
        const period = h >= 12 ? 'PM' : 'AM';
        const displayH = h % 12 === 0 ? 12 : h % 12;
        const displayM = m < 10 ? `0${m}` : m;
        return `${displayH}:${displayM} ${period}`;
      };

      slots.push(`${formatTime(h1, m1)} - ${formatTime(h2, m2)}`);
      curr += duration;
    }
  }

  generateRange(store.bookingSettings.morningStart, store.bookingSettings.morningEnd);
  generateRange(store.bookingSettings.eveningStart, store.bookingSettings.eveningEnd);

  // Find already booked slots on this date
  const bookedSlots = store.bookings
    .filter(b => b.preferredDate === date && b.status !== 'cancelled')
    .map(b => b.timeSlot);

  // Filter slots
  const availableSlots = slots.map(slot => ({
    timeSlot: slot,
    isBooked: bookedSlots.includes(slot)
  }));

  res.json({
    available: true,
    date,
    slots: availableSlots
  });
});

app.post('/api/bookings/create', (req: Request, res: Response): void => {
  const {
    patientName,
    patientPhone,
    patientEmail,
    serviceId,
    serviceName,
    preferredDate,
    timeSlot,
    message,
    honeypot
  } = req.body;

  // Anti-spam honeypot
  if (honeypot && String(honeypot).trim() !== '') {
    res.status(400).json({ error: 'Submission rejected' });
    return;
  }

  // Validation
  if (!patientName || patientName.trim().length < 2) {
    res.status(400).json({ error: 'Please enter a valid patient name (min 2 characters)' });
    return;
  }

  // Clean and validate Indian phone number
  const cleanPhone = patientPhone ? String(patientPhone).replace(/\D/g, '') : '';
  const validPhone = cleanPhone.length === 10 || (cleanPhone.length === 12 && cleanPhone.startsWith('91'));
  if (!validPhone) {
    res.status(400).json({ error: 'Please enter a valid 10-digit Indian mobile number' });
    return;
  }

  if (!preferredDate || !timeSlot) {
    res.status(400).json({ error: 'Please select preferred date and time slot' });
    return;
  }

  // Prevent past dates
  const todayStr = new Date().toISOString().split('T')[0];
  if (preferredDate < todayStr) {
    res.status(400).json({ error: 'Appointments cannot be booked for past dates' });
    return;
  }

  // Slot collision check (Atomic Slot Lock)
  const slotKey = `${preferredDate}_${timeSlot.replace(/[^a-zA-Z0-9]/g, '-')}`;
  const existingBooking = store.bookings.find(
    b => b.preferredDate === preferredDate && b.timeSlot === timeSlot && b.status !== 'cancelled'
  );

  if (existingBooking) {
    res.status(409).json({ error: 'This time slot was just booked by another patient. Please choose another slot.' });
    return;
  }

  const bookingNumber = `CC-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const bookingId = `book-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

  const newBooking = {
    id: bookingId,
    bookingNumber,
    patientName: patientName.trim(),
    patientPhone: cleanPhone.length === 12 ? cleanPhone.slice(2) : cleanPhone,
    patientEmail: patientEmail ? patientEmail.trim() : undefined,
    serviceId: serviceId || 'srv-general-checkup',
    serviceName: serviceName || 'Comprehensive Health & Vitals Check',
    preferredDate,
    timeSlot,
    slotKey,
    message: message ? message.trim() : undefined,
    status: (store.bookingSettings.autoConfirm ? 'confirmed' : 'pending') as 'pending' | 'confirmed',
    isWalkIn: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  store.bookings.unshift(newBooking);
  saveStore();

  addActivity(
    'new_booking',
    'booking',
    `New appointment ${bookingNumber} booked for ${newBooking.patientName} (${newBooking.preferredDate} at ${newBooking.timeSlot})`,
    'Public Patient'
  );

  res.status(201).json({
    success: true,
    booking: newBooking,
    message: 'Appointment booked successfully'
  });
});

app.get('/api/bookings/list', requireAdmin, (req: Request, res: Response): void => {
  const { filter, search } = req.query;
  let list = [...store.bookings];

  const todayStr = new Date().toISOString().split('T')[0];
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];

  if (filter === 'today') {
    list = list.filter(b => b.preferredDate === todayStr);
  } else if (filter === 'tomorrow') {
    list = list.filter(b => b.preferredDate === tomorrow);
  } else if (filter === 'pending') {
    list = list.filter(b => b.status === 'pending');
  } else if (filter === 'confirmed') {
    list = list.filter(b => b.status === 'confirmed');
  } else if (filter === 'completed') {
    list = list.filter(b => b.status === 'completed');
  } else if (filter === 'cancelled') {
    list = list.filter(b => b.status === 'cancelled');
  } else if (filter === 'noshow') {
    list = list.filter(b => b.status === 'noshow');
  }

  if (search && typeof search === 'string') {
    const q = search.toLowerCase();
    list = list.filter(
      b =>
        b.patientName.toLowerCase().includes(q) ||
        b.patientPhone.includes(q) ||
        b.bookingNumber.toLowerCase().includes(q)
    );
  }

  res.json(list);
});

app.patch('/api/bookings/:id', requireAdmin, (req: Request, res: Response): void => {
  const { id } = req.params;
  const { status, adminNotes, preferredDate, timeSlot } = req.body;

  const booking = store.bookings.find(b => b.id === id);
  if (!booking) {
    res.status(404).json({ error: 'Booking not found' });
    return;
  }

  if (status) {
    booking.status = status;
  }
  if (adminNotes !== undefined) {
    booking.adminNotes = adminNotes;
  }
  if (preferredDate && timeSlot) {
    booking.preferredDate = preferredDate;
    booking.timeSlot = timeSlot;
    booking.slotKey = `${preferredDate}_${timeSlot.replace(/[^a-zA-Z0-9]/g, '-')}`;
  }

  booking.updatedAt = new Date().toISOString();
  saveStore();

  addActivity(
    'update_booking',
    'booking',
    `Booking ${booking.bookingNumber} updated (status: ${booking.status})`,
    store.admin.username
  );

  res.json({ success: true, booking });
});

app.delete('/api/bookings/:id', requireAdmin, (req: Request, res: Response): void => {
  const { id } = req.params;
  const index = store.bookings.findIndex(b => b.id === id);
  if (index === -1) {
    res.status(404).json({ error: 'Booking not found' });
    return;
  }
  const deleted = store.bookings.splice(index, 1)[0];
  saveStore();

  addActivity('delete_booking', 'booking', `Deleted booking record ${deleted.bookingNumber}`, store.admin.username);
  res.json({ success: true, message: 'Booking deleted' });
});

app.post('/api/bookings/manual', requireAdmin, (req: Request, res: Response): void => {
  const { patientName, patientPhone, patientEmail, serviceName, preferredDate, timeSlot, adminNotes } = req.body;
  if (!patientName || !patientPhone || !preferredDate || !timeSlot) {
    res.status(400).json({ error: 'Name, phone, date, and slot are required' });
    return;
  }

  const bookingNumber = `CC-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
  const slotKey = `${preferredDate}_${timeSlot.replace(/[^a-zA-Z0-9]/g, '-')}`;

  const manualBooking = {
    id: `book-walkin-${Date.now()}`,
    bookingNumber,
    patientName: patientName.trim(),
    patientPhone: String(patientPhone).replace(/\D/g, ''),
    patientEmail: patientEmail?.trim(),
    serviceId: 'srv-manual',
    serviceName: serviceName || 'Walk-in / Phone Consultation',
    preferredDate,
    timeSlot,
    slotKey,
    status: 'confirmed' as const,
    adminNotes: adminNotes || 'Walk-in / In-clinic appointment',
    isWalkIn: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  store.bookings.unshift(manualBooking);
  saveStore();

  addActivity('manual_booking', 'booking', `Walk-in booking created for ${manualBooking.patientName}`, store.admin.username);
  res.status(201).json({ success: true, booking: manualBooking });
});

// 4. MEDIA MANAGEMENT
app.get('/api/media/list', (_req: Request, res: Response): void => {
  // Return media sorted by displayOrder
  const sorted = [...store.media].sort((a, b) => a.displayOrder - b.displayOrder);
  res.json(sorted);
});

app.post('/api/media/save', requireAdmin, (req: Request, res: Response): void => {
  const {
    url,
    storagePath,
    thumbnailUrl,
    thumbnailStoragePath,
    posterUrl,
    posterStoragePath,
    mediaType,
    filename,
    sizeBytes,
    caption,
    altText,
    category,
    slot
  } = req.body;

  if (!url || !mediaType) {
    res.status(400).json({ error: 'Media URL and type are required' });
    return;
  }

  const newMedia = {
    id: `media-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    url,
    storagePath,
    thumbnailUrl: thumbnailUrl || url,
    thumbnailStoragePath,
    posterUrl,
    posterStoragePath,
    mediaType: mediaType || 'photo',
    filename: filename || 'media_upload',
    sizeBytes: sizeBytes || 0,
    caption: caption || '',
    altText: altText || caption || 'Dr. Chouhan Clinic Media',
    category: category || 'gallery',
    slot: slot || 'gallery',
    displayOrder: store.media.length + 1,
    isDemo: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  store.media.push(newMedia);
  saveStore();

  addActivity('upload_media', 'media', `Uploaded media item ${newMedia.filename} (${newMedia.mediaType})`, store.admin.username);
  res.status(201).json({ success: true, media: newMedia });
});

app.post('/api/media/replace/:id', requireAdmin, (req: Request, res: Response): void => {
  const { id } = req.params;
  const { url, storagePath, thumbnailUrl, posterUrl, filename, sizeBytes } = req.body;

  const item = store.media.find(m => m.id === id);
  if (!item) {
    res.status(404).json({ error: 'Media item not found' });
    return;
  }

  item.url = url || item.url;
  item.storagePath = storagePath || item.storagePath;
  item.thumbnailUrl = thumbnailUrl || item.thumbnailUrl;
  item.posterUrl = posterUrl || item.posterUrl;
  item.filename = filename || item.filename;
  item.sizeBytes = sizeBytes || item.sizeBytes;
  item.isDemo = false;
  item.updatedAt = new Date().toISOString();

  saveStore();

  addActivity('replace_media', 'media', `Replaced media asset for item ${item.id}`, store.admin.username);
  res.json({ success: true, media: item, message: 'Media replaced successfully' });
});

app.delete('/api/media/:id', requireAdmin, (req: Request, res: Response): void => {
  const { id } = req.params;
  const index = store.media.findIndex(m => m.id === id);
  if (index === -1) {
    res.status(404).json({ error: 'Media item not found' });
    return;
  }
  const deleted = store.media.splice(index, 1)[0];
  saveStore();

  addActivity('delete_media', 'media', `Deleted media ${deleted.filename}`, store.admin.username);
  res.json({ success: true, message: 'Media deleted successfully' });
});

app.post('/api/media/reorder', requireAdmin, (req: Request, res: Response): void => {
  const { orderedIds } = req.body;
  if (!Array.isArray(orderedIds)) {
    res.status(400).json({ error: 'orderedIds array required' });
    return;
  }

  orderedIds.forEach((id: string, index: number) => {
    const item = store.media.find(m => m.id === id);
    if (item) item.displayOrder = index + 1;
  });

  saveStore();
  res.json({ success: true, message: 'Media reordered successfully' });
});

// 5. BOOKING SETTINGS
app.get('/api/settings/booking', (_req: Request, res: Response): void => {
  res.json(store.bookingSettings);
});

app.post('/api/settings/booking', requireAdmin, (req: Request, res: Response): void => {
  store.bookingSettings = {
    ...store.bookingSettings,
    ...req.body,
    updatedAt: new Date().toISOString()
  };
  saveStore();

  addActivity('update_settings', 'settings', 'Clinic consultation schedule settings updated', store.admin.username);
  res.json({ success: true, settings: store.bookingSettings });
});

// 6. ACTIVITY LOGS
app.get('/api/activity/logs', requireAdmin, (_req: Request, res: Response): void => {
  res.json(store.activityLogs);
});

// 7. BACKUP & RESTORE
app.get('/api/backup/export', requireAdmin, (_req: Request, res: Response): void => {
  const exportPayload = {
    exportedAt: new Date().toISOString(),
    version: "1.0",
    published: store.published,
    draft: store.draft,
    media: store.media,
    bookingSettings: store.bookingSettings
  };
  res.setHeader('Content-Disposition', 'attachment; filename="drchouhan-clinic-backup.json"');
  res.setHeader('Content-Type', 'application/json');
  res.send(JSON.stringify(exportPayload, null, 2));
});

app.post('/api/backup/import', requireAdmin, (req: Request, res: Response): void => {
  const { data } = req.body;
  if (!data || !data.published) {
    res.status(400).json({ error: 'Invalid backup file structure' });
    return;
  }

  if (data.published) store.published = data.published;
  if (data.draft) store.draft = data.draft;
  if (Array.isArray(data.media)) store.media = data.media;
  if (data.bookingSettings) store.bookingSettings = data.bookingSettings;

  saveStore();
  addActivity('restore_backup', 'settings', 'Restored clinic configuration from backup', store.admin.username);
  res.json({ success: true, message: 'Data restored successfully' });
});

// -------------------------------------------------------------
// Vite Middlewares (Dev) or Static Hosting (Prod)
// -------------------------------------------------------------
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        host: '0.0.0.0',
        port: PORT
      },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Dr. Chouhan Clinic] Full-stack Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
