# Netlify deploy (images/videos upload fix)

1. Is folder ko GitHub repo me daalo aur Netlify me "Import from Git" se connect karo
   (ya terminal se: `npm i -g netlify-cli && npm i && netlify deploy --build --prod`).
   NOTE: sirf `dist` folder drag-drop karoge to /api functions deploy NAHI hote.
2. Netlify > Site settings > Environment variables:
   - ADMIN_JWT_SECRET = koi lamba random text
   - ADMIN_USERNAME   = aapka admin username  (sirf pehli baar use hota hai)
   - ADMIN_PASSWORD   = aapka admin password  (sirf pehli baar use hota hai)
3. Deploy. Admin: /#/admin
