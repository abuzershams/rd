const { app, BrowserWindow, shell } = require('electron');
const cfg = require('./config.json');

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    autoHideMenuBar: true,
    title: 'Dr. Chouhan Clinic',
    webPreferences: { contextIsolation: true, nodeIntegration: false }
  });

  win.loadURL(cfg.url);

  win.webContents.on('did-fail-load', (_e, code) => {
    if (code === -3) return;
    win.loadURL(
      'data:text/html;charset=utf-8,' +
        encodeURIComponent(
          '<body style="font-family:sans-serif;text-align:center;padding-top:20vh"><h2>Internet connection nahi mil raha</h2><p>Connection check karke app dobara kholein.</p></body>'
        )
    );
  });

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith(cfg.url)) {
      shell.openExternal(url);
      return { action: 'deny' };
    }
    return { action: 'allow' };
  });
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
